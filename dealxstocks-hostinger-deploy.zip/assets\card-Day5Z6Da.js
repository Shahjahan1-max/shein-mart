import{b as c,j as e}from"./vendor-react-LLKFCwzd.js";import{p as i}from"./index-CX4q7i0i.js";const p=c.forwardRef(({className:s,variant:r="primary",size:t="md",loading:a=!1,leftIcon:n,rightIcon:d,fullWidth:o=!1,disabled:l,children:b,...x},g)=>{const m=`
      inline-flex items-center justify-center font-semibold transition-all duration-200 ease-in-out
      focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2
      disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none
      whitespace-nowrap
    `,f={primary:`
        bg-brand-600 text-white hover:bg-brand-700 active:bg-brand-800
        focus-visible:ring-brand-500
        shadow-sm hover:shadow-md
      `,secondary:`
        bg-neutral-100 text-neutral-900 hover:bg-neutral-200 active:bg-neutral-300
        dark:bg-neutral-800 dark:text-neutral-50 dark:hover:bg-neutral-700 dark:active:bg-neutral-600
        focus-visible:ring-neutral-500
        border border-neutral-200 dark:border-neutral-700
      `,outline:`
        border-2 border-brand-600 text-brand-600 hover:bg-brand-50 active:bg-brand-100
        dark:border-brand-400 dark:text-brand-400 dark:hover:bg-brand-950 dark:active:bg-brand-900
        focus-visible:ring-brand-500
      `,ghost:`
        text-neutral-700 hover:bg-neutral-100 active:bg-neutral-200
        dark:text-neutral-300 dark:hover:bg-neutral-800 dark:active:bg-neutral-700
        focus-visible:ring-neutral-500
      `,destructive:`
        bg-error-600 text-white hover:bg-error-700 active:bg-error-800
        focus-visible:ring-error-500
        shadow-sm hover:shadow-md
      `,success:`
        bg-success-600 text-white hover:bg-success-700 active:bg-success-800
        focus-visible:ring-success-500
        shadow-sm hover:shadow-md
      `,link:`
        text-brand-600 hover:text-brand-700 active:text-brand-800 underline-offset-2 hover:underline
        dark:text-brand-400 dark:hover:text-brand-300
        focus-visible:ring-brand-500
      `,default:`
        bg-brand-600 text-white hover:bg-brand-700 active:bg-brand-800
        focus-visible:ring-brand-500
        shadow-sm hover:shadow-md
      `},y={default:"h-10 px-4 text-sm gap-2",sm:"h-8 px-3 text-xs gap-1.5",md:"h-10 px-4 text-sm gap-2",lg:"h-12 px-6 text-base gap-2.5",xl:"h-14 px-8 text-lg gap-3",icon:"h-10 w-10 p-0 flex items-center justify-center"},v=o?"w-full":"";return e.jsxs("button",{ref:g,className:i(m,f[r],y[t],v,s),disabled:l||a,"aria-busy":a,"aria-disabled":l||a,...x,children:[a&&e.jsxs("svg",{className:"animate-spin h-4 w-4",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24","aria-hidden":"true",children:[e.jsx("circle",{className:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor",strokeWidth:"4"}),e.jsx("path",{className:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"})]}),!a&&n&&e.jsx("span",{"aria-hidden":"true",className:"flex-shrink-0",children:n}),e.jsx("span",{className:a?"sr-only":"",children:b}),!a&&d&&e.jsx("span",{"aria-hidden":"true",className:"flex-shrink-0",children:d})]})});p.displayName="Button";const w=c.forwardRef(({className:s,children:r,"aria-label":t,size:a="md",variant:n="ghost",...d},o)=>{const l={sm:"h-8 w-8",md:"h-10 w-10",lg:"h-12 w-12"};return e.jsx(p,{ref:o,variant:n,size:a,className:i(l[a],"p-0",s),"aria-label":t,...d,children:r})});w.displayName="IconButton";const k=c.forwardRef(({className:s,pressed:r,onToggle:t,children:a,...n},d)=>{const o=l=>{t?.(!r),n.onClick?.(l)};return e.jsx(p,{ref:d,variant:r?"primary":"outline",className:i("transition-all duration-200",r&&"bg-brand-600 text-white border-brand-600",s),"aria-pressed":r,onClick:o,...n,children:a})});k.displayName="ToggleButton";const u=c.forwardRef(({className:s,variant:r="default",padding:t="md",hover:a=!1,border:n=!0,children:d,...o},l)=>{const b={default:"bg-white dark:bg-gray-900",elevated:"bg-white dark:bg-gray-900 shadow-lg",outlined:"bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700",filled:"bg-gray-50 dark:bg-gray-800/50",gradient:"bg-gradient-to-br from-purple-600 via-purple-700 to-indigo-700 text-white"},x={none:"",sm:"p-3",md:"p-4 sm:p-5",lg:"p-5 sm:p-6",xl:"p-6 sm:p-8"},g=a?"hover:-translate-y-0.5 hover:shadow-lg transition-all duration-200":"",m=n?"border border-gray-200 dark:border-gray-700":"";return e.jsx("div",{ref:l,className:i("rounded-2xl",b[r],x[t],g,m,s),...o,children:d})});u.displayName="Card";const N=c.forwardRef(({className:s,children:r,...t},a)=>e.jsx("div",{ref:a,className:i("mb-4",s),...t,children:r}));N.displayName="CardHeader";const j=c.forwardRef(({className:s,children:r,...t},a)=>e.jsx("h3",{ref:a,className:i("text-lg font-semibold text-gray-900 dark:text-white",s),...t,children:r}));j.displayName="CardTitle";const C=c.forwardRef(({className:s,children:r,...t},a)=>e.jsx("p",{ref:a,className:i("text-sm text-gray-500 dark:text-gray-400 mt-1",s),...t,children:r}));C.displayName="CardDescription";const h=c.forwardRef(({className:s,children:r,...t},a)=>e.jsx("div",{ref:a,className:i("",s),...t,children:r}));h.displayName="CardContent";const S=c.forwardRef(({className:s,children:r,...t},a)=>e.jsx("div",{ref:a,className:i("mt-4 pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center gap-2",s),...t,children:r}));S.displayName="CardFooter";const B={primary:"bg-blue-500/20 text-blue-600 dark:text-blue-400",success:"bg-green-500/20 text-green-600 dark:text-green-400",warning:"bg-amber-500/20 text-amber-600 dark:text-amber-400",info:"bg-cyan-500/20 text-cyan-600 dark:text-cyan-400",purple:"bg-purple-500/20 text-purple-600 dark:text-purple-400",orange:"bg-orange-500/20 text-orange-600 dark:text-orange-400"};function z({label:s,value:r,suffix:t,icon:a,trend:n,color:d="primary",loading:o=!1}){const l=B[d];return o?e.jsx(u,{className:"animate-pulse",children:e.jsxs(h,{className:"space-y-3",children:[e.jsx("div",{className:"h-4 w-24 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"}),e.jsx("div",{className:"h-8 w-32 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"}),e.jsx("div",{className:"h-3 w-20 bg-gray-200 dark:bg-gray-700 rounded animate-pulse"})]})}):e.jsx(u,{hover:!0,className:"min-w-0",children:e.jsxs(h,{className:"flex items-start justify-between gap-4",children:[e.jsxs("div",{className:"min-w-0 flex-1",children:[e.jsx("p",{className:"text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-1.5",children:s}),e.jsxs("div",{className:"flex items-baseline gap-1",children:[e.jsx("span",{className:"text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white tabular-nums break-words",children:r}),t&&e.jsx("span",{className:"text-sm font-medium text-gray-500 dark:text-gray-400 ml-1",children:t})]}),n&&e.jsxs("div",{className:"flex items-center gap-1 mt-2",children:[e.jsxs("span",{className:`text-xs font-semibold ${n.value>=0?"text-green-600":"text-red-600"}`,children:[n.value>=0?"+":"",n.value,"%"]}),e.jsx("span",{className:"text-xs text-gray-500 dark:text-gray-400",children:n.label})]})]}),a&&e.jsx("div",{className:i("p-3 rounded-xl flex-shrink-0",l),children:a})]})})}export{p as B,u as C,z as S};
