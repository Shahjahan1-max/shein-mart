const e="/assets/ebay-logo_1776687129277-BLLcW1e1.jpg";export{e};
