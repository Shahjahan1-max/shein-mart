import{aG as a}from"./index-CX4q7i0i.js";function o({meta:e}){return a(e,typeof window<"u"?window.location.pathname:"/"),null}export{o as P};
