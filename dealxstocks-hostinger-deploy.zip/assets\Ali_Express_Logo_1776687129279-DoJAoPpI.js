const s="/assets/Amazon_Logo_1776687129282-Bu5fuDfI.webp",o="/assets/Ali_Express_Logo_1776687129279-Bvjai0yj.webp";export{o as a,s as b};
