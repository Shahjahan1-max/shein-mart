const Xr=()=>{};var ui={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Pi={NODE_ADMIN:!1,SDK_VERSION:"${JSCORE_VERSION}"};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Jr=function(e,i){if(!e)throw Yr(i)},Yr=function(e){return new Error("Firebase Database ("+Pi.SDK_VERSION+") INTERNAL ASSERT FAILED: "+e)};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ki=function(e){const i=[];let s=0;for(let a=0;a<e.length;a++){let h=e.charCodeAt(a);h<128?i[s++]=h:h<2048?(i[s++]=h>>6|192,i[s++]=h&63|128):(h&64512)===55296&&a+1<e.length&&(e.charCodeAt(a+1)&64512)===56320?(h=65536+((h&1023)<<10)+(e.charCodeAt(++a)&1023),i[s++]=h>>18|240,i[s++]=h>>12&63|128,i[s++]=h>>6&63|128,i[s++]=h&63|128):(i[s++]=h>>12|224,i[s++]=h>>6&63|128,i[s++]=h&63|128)}return i},Zr=function(e){const i=[];let s=0,a=0;for(;s<e.length;){const h=e[s++];if(h<128)i[a++]=String.fromCharCode(h);else if(h>191&&h<224){const y=e[s++];i[a++]=String.fromCharCode((h&31)<<6|y&63)}else if(h>239&&h<365){const y=e[s++],p=e[s++],b=e[s++],S=((h&7)<<18|(y&63)<<12|(p&63)<<6|b&63)-65536;i[a++]=String.fromCharCode(55296+(S>>10)),i[a++]=String.fromCharCode(56320+(S&1023))}else{const y=e[s++],p=e[s++];i[a++]=String.fromCharCode((h&15)<<12|(y&63)<<6|p&63)}}return i.join("")},ji={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:typeof atob=="function",encodeByteArray(e,i){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();const s=i?this.byteToCharMapWebSafe_:this.byteToCharMap_,a=[];for(let h=0;h<e.length;h+=3){const y=e[h],p=h+1<e.length,b=p?e[h+1]:0,S=h+2<e.length,E=S?e[h+2]:0,_=y>>2,A=(y&3)<<4|b>>4;let R=(b&15)<<2|E>>6,W=E&63;S||(W=64,p||(R=64)),a.push(s[_],s[A],s[R],s[W])}return a.join("")},encodeString(e,i){return this.HAS_NATIVE_SUPPORT&&!i?btoa(e):this.encodeByteArray(ki(e),i)},decodeString(e,i){return this.HAS_NATIVE_SUPPORT&&!i?atob(e):Zr(this.decodeStringToByteArray(e,i))},decodeStringToByteArray(e,i){this.init_();const s=i?this.charToByteMapWebSafe_:this.charToByteMap_,a=[];for(let h=0;h<e.length;){const y=s[e.charAt(h++)],b=h<e.length?s[e.charAt(h)]:0;++h;const E=h<e.length?s[e.charAt(h)]:64;++h;const A=h<e.length?s[e.charAt(h)]:64;if(++h,y==null||b==null||E==null||A==null)throw new Qr;const R=y<<2|b>>4;if(a.push(R),E!==64){const W=b<<4&240|E>>2;if(a.push(W),A!==64){const F=E<<6&192|A;a.push(F)}}}return a},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class Qr extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}const ts=function(e){const i=ki(e);return ji.encodeByteArray(i,!0)},oe=function(e){return ts(e).replace(/\./g,"")},We=function(e){try{return ji.decodeString(e,!0)}catch(i){console.error("base64Decode failed: ",i)}return null};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ih(e){return Bi(void 0,e)}function Bi(e,i){if(!(i instanceof Object))return i;switch(i.constructor){case Date:const s=i;return new Date(s.getTime());case Object:e===void 0&&(e={});break;case Array:e=[];break;default:return i}for(const s in i)!i.hasOwnProperty(s)||!es(s)||(e[s]=Bi(e[s],i[s]));return e}function es(e){return e!=="__proto__"}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ns(){if(typeof self<"u")return self;if(typeof window<"u")return window;if(typeof global<"u")return global;throw new Error("Unable to locate global object.")}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const is=()=>ns().__FIREBASE_DEFAULTS__,rs=()=>{if(typeof process>"u"||typeof ui>"u")return;const e=ui.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},ss=()=>{if(typeof document>"u")return;let e;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch{return}const i=e&&We(e[1]);return i&&JSON.parse(i)},Ze=()=>{try{return Xr()||is()||rs()||ss()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},os=e=>Ze()?.emulatorHosts?.[e],rh=e=>{const i=os(e);if(!i)return;const s=i.lastIndexOf(":");if(s<=0||s+1===i.length)throw new Error(`Invalid host ${i} with no separate hostname and port!`);const a=parseInt(i.substring(s+1),10);return i[0]==="["?[i.substring(1,s-1),a]:[i.substring(0,s),a]},Ni=()=>Ze()?.config;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class as{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((i,s)=>{this.resolve=i,this.reject=s})}wrapCallback(i){return(s,a)=>{s?this.reject(s):this.resolve(a),typeof i=="function"&&(this.promise.catch(()=>{}),i.length===1?i(s):i(s,a))}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sh(e,i){if(e.uid)throw new Error('The "uid" field is no longer supported by mockUserToken. Please use "sub" instead for Firebase Auth User ID.');const s={alg:"none",type:"JWT"},a=i||"demo-project",h=e.iat||0,y=e.sub||e.user_id;if(!y)throw new Error("mockUserToken must contain 'sub' or 'user_id' field!");const p={iss:`https://securetoken.google.com/${a}`,aud:a,iat:h,exp:h+3600,auth_time:h,sub:y,user_id:y,firebase:{sign_in_provider:"custom",identities:{}},...e};return[oe(JSON.stringify(s)),oe(JSON.stringify(p)),""].join(".")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function hs(){return typeof navigator<"u"&&typeof navigator.userAgent=="string"?navigator.userAgent:""}function oh(){return typeof window<"u"&&!!(window.cordova||window.phonegap||window.PhoneGap)&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(hs())}function xi(){const e=Ze()?.forceEnvironment;if(e==="node")return!0;if(e==="browser")return!1;try{return Object.prototype.toString.call(global.process)==="[object process]"}catch{return!1}}function Li(){const e=typeof chrome=="object"?chrome.runtime:typeof browser=="object"?browser.runtime:void 0;return typeof e=="object"&&e.id!==void 0}function ah(){return typeof navigator=="object"&&navigator.product==="ReactNative"}function hh(){return Pi.NODE_ADMIN===!0}function ch(){return!xi()&&!!navigator.userAgent&&navigator.userAgent.includes("Safari")&&!navigator.userAgent.includes("Chrome")}function lh(){return!xi()&&!!navigator.userAgent&&(navigator.userAgent.includes("Safari")||navigator.userAgent.includes("WebKit"))&&!navigator.userAgent.includes("Chrome")}function Qe(){try{return typeof indexedDB=="object"}catch{return!1}}function tn(){return new Promise((e,i)=>{try{let s=!0;const a="validate-browser-context-for-indexeddb-analytics-module",h=self.indexedDB.open(a);h.onsuccess=()=>{h.result.close(),s||self.indexedDB.deleteDatabase(a),e(!0)},h.onupgradeneeded=()=>{s=!1},h.onerror=()=>{i(h.error?.message||"")}}catch(s){i(s)}})}function Fi(){return!(typeof navigator>"u"||!navigator.cookieEnabled)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cs="FirebaseError";class wt extends Error{constructor(i,s,a){super(s),this.code=i,this.customData=a,this.name=cs,Object.setPrototypeOf(this,wt.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,le.prototype.create)}}class le{constructor(i,s,a){this.service=i,this.serviceName=s,this.errors=a}create(i,...s){const a=s[0]||{},h=`${this.service}/${i}`,y=this.errors[i],p=y?ls(y,a):"Error",b=`${this.serviceName}: ${p} (${h}).`;return new wt(h,b,a)}}function ls(e,i){return e.replace(us,(s,a)=>{const h=i[a];return h!=null?String(h):`<${a}?>`})}const us=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fi(e){return JSON.parse(e)}function uh(e){return JSON.stringify(e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $i=function(e){let i={},s={},a={},h="";try{const y=e.split(".");i=fi(We(y[0])||""),s=fi(We(y[1])||""),h=y[2],a=s.d||{},delete s.d}catch{}return{header:i,claims:s,data:a,signature:h}},fh=function(e){const i=$i(e),s=i.claims;return!!s&&typeof s=="object"&&s.hasOwnProperty("iat")},ph=function(e){const i=$i(e).claims;return typeof i=="object"&&i.admin===!0};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function gh(e,i){return Object.prototype.hasOwnProperty.call(e,i)}function dh(e,i){if(Object.prototype.hasOwnProperty.call(e,i))return e[i]}function mh(e){for(const i in e)if(Object.prototype.hasOwnProperty.call(e,i))return!1;return!0}function yh(e,i,s){const a={};for(const h in e)Object.prototype.hasOwnProperty.call(e,h)&&(a[h]=i.call(s,e[h],h,e));return a}function ae(e,i){if(e===i)return!0;const s=Object.keys(e),a=Object.keys(i);for(const h of s){if(!a.includes(h))return!1;const y=e[h],p=i[h];if(pi(y)&&pi(p)){if(!ae(y,p))return!1}else if(y!==p)return!1}for(const h of a)if(!s.includes(h))return!1;return!0}function pi(e){return e!==null&&typeof e=="object"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wh(e){const i=[];for(const[s,a]of Object.entries(e))Array.isArray(a)?a.forEach(h=>{i.push(encodeURIComponent(s)+"="+encodeURIComponent(h))}):i.push(encodeURIComponent(s)+"="+encodeURIComponent(a));return i.length?"&"+i.join("&"):""}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vh{constructor(){this.chain_=[],this.buf_=[],this.W_=[],this.pad_=[],this.inbuf_=0,this.total_=0,this.blockSize=512/8,this.pad_[0]=128;for(let i=1;i<this.blockSize;++i)this.pad_[i]=0;this.reset()}reset(){this.chain_[0]=1732584193,this.chain_[1]=4023233417,this.chain_[2]=2562383102,this.chain_[3]=271733878,this.chain_[4]=3285377520,this.inbuf_=0,this.total_=0}compress_(i,s){s||(s=0);const a=this.W_;if(typeof i=="string")for(let A=0;A<16;A++)a[A]=i.charCodeAt(s)<<24|i.charCodeAt(s+1)<<16|i.charCodeAt(s+2)<<8|i.charCodeAt(s+3),s+=4;else for(let A=0;A<16;A++)a[A]=i[s]<<24|i[s+1]<<16|i[s+2]<<8|i[s+3],s+=4;for(let A=16;A<80;A++){const R=a[A-3]^a[A-8]^a[A-14]^a[A-16];a[A]=(R<<1|R>>>31)&4294967295}let h=this.chain_[0],y=this.chain_[1],p=this.chain_[2],b=this.chain_[3],S=this.chain_[4],E,_;for(let A=0;A<80;A++){A<40?A<20?(E=b^y&(p^b),_=1518500249):(E=y^p^b,_=1859775393):A<60?(E=y&p|b&(y|p),_=2400959708):(E=y^p^b,_=3395469782);const R=(h<<5|h>>>27)+E+S+_+a[A]&4294967295;S=b,b=p,p=(y<<30|y>>>2)&4294967295,y=h,h=R}this.chain_[0]=this.chain_[0]+h&4294967295,this.chain_[1]=this.chain_[1]+y&4294967295,this.chain_[2]=this.chain_[2]+p&4294967295,this.chain_[3]=this.chain_[3]+b&4294967295,this.chain_[4]=this.chain_[4]+S&4294967295}update(i,s){if(i==null)return;s===void 0&&(s=i.length);const a=s-this.blockSize;let h=0;const y=this.buf_;let p=this.inbuf_;for(;h<s;){if(p===0)for(;h<=a;)this.compress_(i,h),h+=this.blockSize;if(typeof i=="string"){for(;h<s;)if(y[p]=i.charCodeAt(h),++p,++h,p===this.blockSize){this.compress_(y),p=0;break}}else for(;h<s;)if(y[p]=i[h],++p,++h,p===this.blockSize){this.compress_(y),p=0;break}}this.inbuf_=p,this.total_+=s}digest(){const i=[];let s=this.total_*8;this.inbuf_<56?this.update(this.pad_,56-this.inbuf_):this.update(this.pad_,this.blockSize-(this.inbuf_-56));for(let h=this.blockSize-1;h>=56;h--)this.buf_[h]=s&255,s/=256;this.compress_(this.buf_);let a=0;for(let h=0;h<5;h++)for(let y=24;y>=0;y-=8)i[a]=this.chain_[h]>>y&255,++a;return i}}function bh(e,i){return`${e} failed: ${i} argument `}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ih=function(e){const i=[];let s=0;for(let a=0;a<e.length;a++){let h=e.charCodeAt(a);if(h>=55296&&h<=56319){const y=h-55296;a++,Jr(a<e.length,"Surrogate pair missing trail surrogate.");const p=e.charCodeAt(a)-56320;h=65536+(y<<10)+p}h<128?i[s++]=h:h<2048?(i[s++]=h>>6|192,i[s++]=h&63|128):h<65536?(i[s++]=h>>12|224,i[s++]=h>>6&63|128,i[s++]=h&63|128):(i[s++]=h>>18|240,i[s++]=h>>12&63|128,i[s++]=h>>6&63|128,i[s++]=h&63|128)}return i},Eh=function(e){let i=0;for(let s=0;s<e.length;s++){const a=e.charCodeAt(s);a<128?i++:a<2048?i+=2:a>=55296&&a<=56319?(i+=4,s++):i+=3}return i};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const fs=1e3,ps=2,gs=14400*1e3,ds=.5;function gi(e,i=fs,s=ps){const a=i*Math.pow(s,e),h=Math.round(ds*a*(Math.random()-.5)*2);return Math.min(gs,a+h)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function en(e){return e&&e._delegate?e._delegate:e}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Sh(e){try{return(e.startsWith("http://")||e.startsWith("https://")?new URL(e).hostname:e).endsWith(".cloudworkstations.dev")}catch{return!1}}async function Ah(e){return(await fetch(e,{credentials:"include"})).ok}class ot{constructor(i,s,a){this.name=i,this.instanceFactory=s,this.type=a,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(i){return this.instantiationMode=i,this}setMultipleInstances(i){return this.multipleInstances=i,this}setServiceProps(i){return this.serviceProps=i,this}setInstanceCreatedCallback(i){return this.onInstanceCreated=i,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pt="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ms{constructor(i,s){this.name=i,this.container=s,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(i){const s=this.normalizeInstanceIdentifier(i);if(!this.instancesDeferred.has(s)){const a=new as;if(this.instancesDeferred.set(s,a),this.isInitialized(s)||this.shouldAutoInitialize())try{const h=this.getOrInitializeService({instanceIdentifier:s});h&&a.resolve(h)}catch{}}return this.instancesDeferred.get(s).promise}getImmediate(i){const s=this.normalizeInstanceIdentifier(i?.identifier),a=i?.optional??!1;if(this.isInitialized(s)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:s})}catch(h){if(a)return null;throw h}else{if(a)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(i){if(i.name!==this.name)throw Error(`Mismatching Component ${i.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=i,!!this.shouldAutoInitialize()){if(ws(i))try{this.getOrInitializeService({instanceIdentifier:pt})}catch{}for(const[s,a]of this.instancesDeferred.entries()){const h=this.normalizeInstanceIdentifier(s);try{const y=this.getOrInitializeService({instanceIdentifier:h});a.resolve(y)}catch{}}}}clearInstance(i=pt){this.instancesDeferred.delete(i),this.instancesOptions.delete(i),this.instances.delete(i)}async delete(){const i=Array.from(this.instances.values());await Promise.all([...i.filter(s=>"INTERNAL"in s).map(s=>s.INTERNAL.delete()),...i.filter(s=>"_delete"in s).map(s=>s._delete())])}isComponentSet(){return this.component!=null}isInitialized(i=pt){return this.instances.has(i)}getOptions(i=pt){return this.instancesOptions.get(i)||{}}initialize(i={}){const{options:s={}}=i,a=this.normalizeInstanceIdentifier(i.instanceIdentifier);if(this.isInitialized(a))throw Error(`${this.name}(${a}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);const h=this.getOrInitializeService({instanceIdentifier:a,options:s});for(const[y,p]of this.instancesDeferred.entries()){const b=this.normalizeInstanceIdentifier(y);a===b&&p.resolve(h)}return h}onInit(i,s){const a=this.normalizeInstanceIdentifier(s),h=this.onInitCallbacks.get(a)??new Set;h.add(i),this.onInitCallbacks.set(a,h);const y=this.instances.get(a);return y&&i(y,a),()=>{h.delete(i)}}invokeOnInitCallbacks(i,s){const a=this.onInitCallbacks.get(s);if(a)for(const h of a)try{h(i,s)}catch{}}getOrInitializeService({instanceIdentifier:i,options:s={}}){let a=this.instances.get(i);if(!a&&this.component&&(a=this.component.instanceFactory(this.container,{instanceIdentifier:ys(i),options:s}),this.instances.set(i,a),this.instancesOptions.set(i,s),this.invokeOnInitCallbacks(a,i),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,i,a)}catch{}return a||null}normalizeInstanceIdentifier(i=pt){return this.component?this.component.multipleInstances?i:pt:i}shouldAutoInitialize(){return!!this.component&&this.component.instantiationMode!=="EXPLICIT"}}function ys(e){return e===pt?void 0:e}function ws(e){return e.instantiationMode==="EAGER"}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vs{constructor(i){this.name=i,this.providers=new Map}addComponent(i){const s=this.getProvider(i.name);if(s.isComponentSet())throw new Error(`Component ${i.name} has already been registered with ${this.name}`);s.setComponent(i)}addOrOverwriteComponent(i){this.getProvider(i.name).isComponentSet()&&this.providers.delete(i.name),this.addComponent(i)}getProvider(i){if(this.providers.has(i))return this.providers.get(i);const s=new ms(i,this);return this.providers.set(i,s),s}getProviders(){return Array.from(this.providers.values())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var O;(function(e){e[e.DEBUG=0]="DEBUG",e[e.VERBOSE=1]="VERBOSE",e[e.INFO=2]="INFO",e[e.WARN=3]="WARN",e[e.ERROR=4]="ERROR",e[e.SILENT=5]="SILENT"})(O||(O={}));const bs={debug:O.DEBUG,verbose:O.VERBOSE,info:O.INFO,warn:O.WARN,error:O.ERROR,silent:O.SILENT},Is=O.INFO,Es={[O.DEBUG]:"log",[O.VERBOSE]:"log",[O.INFO]:"info",[O.WARN]:"warn",[O.ERROR]:"error"},Ss=(e,i,...s)=>{if(i<e.logLevel)return;const a=new Date().toISOString(),h=Es[i];if(h)console[h](`[${a}]  ${e.name}:`,...s);else throw new Error(`Attempted to log a message with an invalid logType (value: ${i})`)};class Hi{constructor(i){this.name=i,this._logLevel=Is,this._logHandler=Ss,this._userLogHandler=null}get logLevel(){return this._logLevel}set logLevel(i){if(!(i in O))throw new TypeError(`Invalid value "${i}" assigned to \`logLevel\``);this._logLevel=i}setLogLevel(i){this._logLevel=typeof i=="string"?bs[i]:i}get logHandler(){return this._logHandler}set logHandler(i){if(typeof i!="function")throw new TypeError("Value assigned to `logHandler` must be a function");this._logHandler=i}get userLogHandler(){return this._userLogHandler}set userLogHandler(i){this._userLogHandler=i}debug(...i){this._userLogHandler&&this._userLogHandler(this,O.DEBUG,...i),this._logHandler(this,O.DEBUG,...i)}log(...i){this._userLogHandler&&this._userLogHandler(this,O.VERBOSE,...i),this._logHandler(this,O.VERBOSE,...i)}info(...i){this._userLogHandler&&this._userLogHandler(this,O.INFO,...i),this._logHandler(this,O.INFO,...i)}warn(...i){this._userLogHandler&&this._userLogHandler(this,O.WARN,...i),this._logHandler(this,O.WARN,...i)}error(...i){this._userLogHandler&&this._userLogHandler(this,O.ERROR,...i),this._logHandler(this,O.ERROR,...i)}}const As=(e,i)=>i.some(s=>e instanceof s);let di,mi;function Ts(){return di||(di=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])}function _s(){return mi||(mi=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])}const Ui=new WeakMap,Ge=new WeakMap,Vi=new WeakMap,Le=new WeakMap,nn=new WeakMap;function Cs(e){const i=new Promise((s,a)=>{const h=()=>{e.removeEventListener("success",y),e.removeEventListener("error",p)},y=()=>{s(it(e.result)),h()},p=()=>{a(e.error),h()};e.addEventListener("success",y),e.addEventListener("error",p)});return i.then(s=>{s instanceof IDBCursor&&Ui.set(s,e)}).catch(()=>{}),nn.set(i,e),i}function Ds(e){if(Ge.has(e))return;const i=new Promise((s,a)=>{const h=()=>{e.removeEventListener("complete",y),e.removeEventListener("error",p),e.removeEventListener("abort",p)},y=()=>{s(),h()},p=()=>{a(e.error||new DOMException("AbortError","AbortError")),h()};e.addEventListener("complete",y),e.addEventListener("error",p),e.addEventListener("abort",p)});Ge.set(e,i)}let Ke={get(e,i,s){if(e instanceof IDBTransaction){if(i==="done")return Ge.get(e);if(i==="objectStoreNames")return e.objectStoreNames||Vi.get(e);if(i==="store")return s.objectStoreNames[1]?void 0:s.objectStore(s.objectStoreNames[0])}return it(e[i])},set(e,i,s){return e[i]=s,!0},has(e,i){return e instanceof IDBTransaction&&(i==="done"||i==="store")?!0:i in e}};function Os(e){Ke=e(Ke)}function Rs(e){return e===IDBDatabase.prototype.transaction&&!("objectStoreNames"in IDBTransaction.prototype)?function(i,...s){const a=e.call(Fe(this),i,...s);return Vi.set(a,i.sort?i.sort():[i]),it(a)}:_s().includes(e)?function(...i){return e.apply(Fe(this),i),it(Ui.get(this))}:function(...i){return it(e.apply(Fe(this),i))}}function Ms(e){return typeof e=="function"?Rs(e):(e instanceof IDBTransaction&&Ds(e),As(e,Ts())?new Proxy(e,Ke):e)}function it(e){if(e instanceof IDBRequest)return Cs(e);if(Le.has(e))return Le.get(e);const i=Ms(e);return i!==e&&(Le.set(e,i),nn.set(i,e)),i}const Fe=e=>nn.get(e);function zi(e,i,{blocked:s,upgrade:a,blocking:h,terminated:y}={}){const p=indexedDB.open(e,i),b=it(p);return a&&p.addEventListener("upgradeneeded",S=>{a(it(p.result),S.oldVersion,S.newVersion,it(p.transaction),S)}),s&&p.addEventListener("blocked",S=>s(S.oldVersion,S.newVersion,S)),b.then(S=>{y&&S.addEventListener("close",()=>y()),h&&S.addEventListener("versionchange",E=>h(E.oldVersion,E.newVersion,E))}).catch(()=>{}),b}const Ps=["get","getKey","getAll","getAllKeys","count"],ks=["put","add","delete","clear"],$e=new Map;function yi(e,i){if(!(e instanceof IDBDatabase&&!(i in e)&&typeof i=="string"))return;if($e.get(i))return $e.get(i);const s=i.replace(/FromIndex$/,""),a=i!==s,h=ks.includes(s);if(!(s in(a?IDBIndex:IDBObjectStore).prototype)||!(h||Ps.includes(s)))return;const y=async function(p,...b){const S=this.transaction(p,h?"readwrite":"readonly");let E=S.store;return a&&(E=E.index(b.shift())),(await Promise.all([E[s](...b),h&&S.done]))[0]};return $e.set(i,y),y}Os(e=>({...e,get:(i,s,a)=>yi(i,s)||e.get(i,s,a),has:(i,s)=>!!yi(i,s)||e.has(i,s)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class js{constructor(i){this.container=i}getPlatformInfoString(){return this.container.getProviders().map(s=>{if(Bs(s)){const a=s.getImmediate();return`${a.library}/${a.version}`}else return null}).filter(s=>s).join(" ")}}function Bs(e){return e.getComponent()?.type==="VERSION"}const qe="@firebase/app",wi="0.14.12";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const q=new Hi("@firebase/app"),Ns="@firebase/app-compat",xs="@firebase/analytics-compat",Ls="@firebase/analytics",Fs="@firebase/app-check-compat",$s="@firebase/app-check",Hs="@firebase/auth",Us="@firebase/auth-compat",Vs="@firebase/database",zs="@firebase/data-connect",Ws="@firebase/database-compat",Gs="@firebase/functions",Ks="@firebase/functions-compat",qs="@firebase/installations",Xs="@firebase/installations-compat",Js="@firebase/messaging",Ys="@firebase/messaging-compat",Zs="@firebase/performance",Qs="@firebase/performance-compat",to="@firebase/remote-config",eo="@firebase/remote-config-compat",no="@firebase/storage",io="@firebase/storage-compat",ro="@firebase/firestore",so="@firebase/ai",oo="@firebase/firestore-compat",ao="firebase",ho="12.13.0";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Xe="[DEFAULT]",co={[qe]:"fire-core",[Ns]:"fire-core-compat",[Ls]:"fire-analytics",[xs]:"fire-analytics-compat",[$s]:"fire-app-check",[Fs]:"fire-app-check-compat",[Hs]:"fire-auth",[Us]:"fire-auth-compat",[Vs]:"fire-rtdb",[zs]:"fire-data-connect",[Ws]:"fire-rtdb-compat",[Gs]:"fire-fn",[Ks]:"fire-fn-compat",[qs]:"fire-iid",[Xs]:"fire-iid-compat",[Js]:"fire-fcm",[Ys]:"fire-fcm-compat",[Zs]:"fire-perf",[Qs]:"fire-perf-compat",[to]:"fire-rc",[eo]:"fire-rc-compat",[no]:"fire-gcs",[io]:"fire-gcs-compat",[ro]:"fire-fst",[oo]:"fire-fst-compat",[so]:"fire-vertex","fire-js":"fire-js",[ao]:"fire-js-all"};/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ut=new Map,lo=new Map,Je=new Map;function vi(e,i){try{e.container.addComponent(i)}catch(s){q.debug(`Component ${i.name} failed to register with FirebaseApp ${e.name}`,s)}}function dt(e){const i=e.name;if(Je.has(i))return q.debug(`There were multiple attempts to register component ${i}.`),!1;Je.set(i,e);for(const s of Ut.values())vi(s,e);for(const s of lo.values())vi(s,e);return!0}function ue(e,i){const s=e.container.getProvider("heartbeat").getImmediate({optional:!0});return s&&s.triggerHeartbeat(),e.container.getProvider(i)}function Th(e){return e==null?!1:e.settings!==void 0}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const uo={"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."},rt=new le("app","Firebase",uo);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fo{constructor(i,s,a){this._isDeleted=!1,this._options={...i},this._config={...s},this._name=s.name,this._automaticDataCollectionEnabled=s.automaticDataCollectionEnabled,this._container=a,this.container.addComponent(new ot("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(i){this.checkDestroyed(),this._automaticDataCollectionEnabled=i}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(i){this._isDeleted=i}checkDestroyed(){if(this.isDeleted)throw rt.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const _h=ho;function po(e,i={}){let s=e;typeof i!="object"&&(i={name:i});const a={name:Xe,automaticDataCollectionEnabled:!0,...i},h=a.name;if(typeof h!="string"||!h)throw rt.create("bad-app-name",{appName:String(h)});if(s||(s=Ni()),!s)throw rt.create("no-options");const y=Ut.get(h);if(y){if(ae(s,y.options)&&ae(a,y.config))return y;throw rt.create("duplicate-app",{appName:h})}const p=new vs(h);for(const S of Je.values())p.addComponent(S);const b=new fo(s,a,p);return Ut.set(h,b),b}function go(e=Xe){const i=Ut.get(e);if(!i&&e===Xe&&Ni())return po();if(!i)throw rt.create("no-app",{appName:e});return i}function Ch(){return Array.from(Ut.values())}function st(e,i,s){let a=co[e]??e;s&&(a+=`-${s}`);const h=a.match(/\s|\//),y=i.match(/\s|\//);if(h||y){const p=[`Unable to register library "${a}" with version "${i}":`];h&&p.push(`library name "${a}" contains illegal characters (whitespace or "/")`),h&&y&&p.push("and"),y&&p.push(`version name "${i}" contains illegal characters (whitespace or "/")`),q.warn(p.join(" "));return}dt(new ot(`${a}-version`,()=>({library:a,version:i}),"VERSION"))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const mo="firebase-heartbeat-database",yo=1,Vt="firebase-heartbeat-store";let He=null;function Wi(){return He||(He=zi(mo,yo,{upgrade:(e,i)=>{switch(i){case 0:try{e.createObjectStore(Vt)}catch(s){console.warn(s)}}}}).catch(e=>{throw rt.create("idb-open",{originalErrorMessage:e.message})})),He}async function wo(e){try{const s=(await Wi()).transaction(Vt),a=await s.objectStore(Vt).get(Gi(e));return await s.done,a}catch(i){if(i instanceof wt)q.warn(i.message);else{const s=rt.create("idb-get",{originalErrorMessage:i?.message});q.warn(s.message)}}}async function bi(e,i){try{const a=(await Wi()).transaction(Vt,"readwrite");await a.objectStore(Vt).put(i,Gi(e)),await a.done}catch(s){if(s instanceof wt)q.warn(s.message);else{const a=rt.create("idb-set",{originalErrorMessage:s?.message});q.warn(a.message)}}}function Gi(e){return`${e.name}!${e.options.appId}`}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const vo=1024,bo=30;class Io{constructor(i){this.container=i,this._heartbeatsCache=null;const s=this.container.getProvider("app").getImmediate();this._storage=new So(s),this._heartbeatsCachePromise=this._storage.read().then(a=>(this._heartbeatsCache=a,a))}async triggerHeartbeat(){try{const s=this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(),a=Ii();if(this._heartbeatsCache?.heartbeats==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,this._heartbeatsCache?.heartbeats==null)||this._heartbeatsCache.lastSentHeartbeatDate===a||this._heartbeatsCache.heartbeats.some(h=>h.date===a))return;if(this._heartbeatsCache.heartbeats.push({date:a,agent:s}),this._heartbeatsCache.heartbeats.length>bo){const h=Ao(this._heartbeatsCache.heartbeats);this._heartbeatsCache.heartbeats.splice(h,1)}return this._storage.overwrite(this._heartbeatsCache)}catch(i){q.warn(i)}}async getHeartbeatsHeader(){try{if(this._heartbeatsCache===null&&await this._heartbeatsCachePromise,this._heartbeatsCache?.heartbeats==null||this._heartbeatsCache.heartbeats.length===0)return"";const i=Ii(),{heartbeatsToSend:s,unsentEntries:a}=Eo(this._heartbeatsCache.heartbeats),h=oe(JSON.stringify({version:2,heartbeats:s}));return this._heartbeatsCache.lastSentHeartbeatDate=i,a.length>0?(this._heartbeatsCache.heartbeats=a,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),h}catch(i){return q.warn(i),""}}}function Ii(){return new Date().toISOString().substring(0,10)}function Eo(e,i=vo){const s=[];let a=e.slice();for(const h of e){const y=s.find(p=>p.agent===h.agent);if(y){if(y.dates.push(h.date),Ei(s)>i){y.dates.pop();break}}else if(s.push({agent:h.agent,dates:[h.date]}),Ei(s)>i){s.pop();break}a=a.slice(1)}return{heartbeatsToSend:s,unsentEntries:a}}class So{constructor(i){this.app=i,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return Qe()?tn().then(()=>!0).catch(()=>!1):!1}async read(){if(await this._canUseIndexedDBPromise){const s=await wo(this.app);return s?.heartbeats?s:{heartbeats:[]}}else return{heartbeats:[]}}async overwrite(i){if(await this._canUseIndexedDBPromise){const a=await this.read();return bi(this.app,{lastSentHeartbeatDate:i.lastSentHeartbeatDate??a.lastSentHeartbeatDate,heartbeats:i.heartbeats})}else return}async add(i){if(await this._canUseIndexedDBPromise){const a=await this.read();return bi(this.app,{lastSentHeartbeatDate:i.lastSentHeartbeatDate??a.lastSentHeartbeatDate,heartbeats:[...a.heartbeats,...i.heartbeats]})}else return}}function Ei(e){return oe(JSON.stringify({version:2,heartbeats:e})).length}function Ao(e){if(e.length===0)return-1;let i=0,s=e[0].date;for(let a=1;a<e.length;a++)e[a].date<s&&(s=e[a].date,i=a);return i}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function To(e){dt(new ot("platform-logger",i=>new js(i),"PRIVATE")),dt(new ot("heartbeat",i=>new Io(i),"PRIVATE")),st(qe,wi,e),st(qe,wi,"esm2020"),st("fire-js","")}To("");var _o="firebase",Co="12.13.0";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */st(_o,Co,"app");const Ki="@firebase/installations",rn="0.6.22";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const qi=1e4,Xi=`w:${rn}`,Ji="FIS_v2",Do="https://firebaseinstallations.googleapis.com/v1",Oo=3600*1e3,Ro="installations",Mo="Installations";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Po={"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."},mt=new le(Ro,Mo,Po);function Yi(e){return e instanceof wt&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Zi({projectId:e}){return`${Do}/projects/${e}/installations`}function Qi(e){return{token:e.token,requestStatus:2,expiresIn:jo(e.expiresIn),creationTime:Date.now()}}async function tr(e,i){const a=(await i.json()).error;return mt.create("request-failed",{requestName:e,serverCode:a.code,serverMessage:a.message,serverStatus:a.status})}function er({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}function ko(e,{refreshToken:i}){const s=er(e);return s.append("Authorization",Bo(i)),s}async function nr(e){const i=await e();return i.status>=500&&i.status<600?e():i}function jo(e){return Number(e.replace("s","000"))}function Bo(e){return`${Ji} ${e}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function No({appConfig:e,heartbeatServiceProvider:i},{fid:s}){const a=Zi(e),h=er(e),y=i.getImmediate({optional:!0});if(y){const E=await y.getHeartbeatsHeader();E&&h.append("x-firebase-client",E)}const p={fid:s,authVersion:Ji,appId:e.appId,sdkVersion:Xi},b={method:"POST",headers:h,body:JSON.stringify(p)},S=await nr(()=>fetch(a,b));if(S.ok){const E=await S.json();return{fid:E.fid||s,registrationStatus:2,refreshToken:E.refreshToken,authToken:Qi(E.authToken)}}else throw await tr("Create Installation",S)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ir(e){return new Promise(i=>{setTimeout(i,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function xo(e){return btoa(String.fromCharCode(...e)).replace(/\+/g,"-").replace(/\//g,"_")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Lo=/^[cdef][\w-]{21}$/,Ye="";function Fo(){try{const e=new Uint8Array(17);(self.crypto||self.msCrypto).getRandomValues(e),e[0]=112+e[0]%16;const s=$o(e);return Lo.test(s)?s:Ye}catch{return Ye}}function $o(e){return xo(e).substr(0,22)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function fe(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rr=new Map;function sr(e,i){const s=fe(e);or(s,i),Ho(s,i)}function or(e,i){const s=rr.get(e);if(s)for(const a of s)a(i)}function Ho(e,i){const s=Uo();s&&s.postMessage({key:e,fid:i}),Vo()}let gt=null;function Uo(){return!gt&&"BroadcastChannel"in self&&(gt=new BroadcastChannel("[Firebase] FID Change"),gt.onmessage=e=>{or(e.data.key,e.data.fid)}),gt}function Vo(){rr.size===0&&gt&&(gt.close(),gt=null)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zo="firebase-installations-database",Wo=1,yt="firebase-installations-store";let Ue=null;function sn(){return Ue||(Ue=zi(zo,Wo,{upgrade:(e,i)=>{i===0&&e.createObjectStore(yt)}})),Ue}async function he(e,i){const s=fe(e),h=(await sn()).transaction(yt,"readwrite"),y=h.objectStore(yt),p=await y.get(s);return await y.put(i,s),await h.done,(!p||p.fid!==i.fid)&&sr(e,i.fid),i}async function ar(e){const i=fe(e),a=(await sn()).transaction(yt,"readwrite");await a.objectStore(yt).delete(i),await a.done}async function pe(e,i){const s=fe(e),h=(await sn()).transaction(yt,"readwrite"),y=h.objectStore(yt),p=await y.get(s),b=i(p);return b===void 0?await y.delete(s):await y.put(b,s),await h.done,b&&(!p||p.fid!==b.fid)&&sr(e,b.fid),b}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function on(e){let i;const s=await pe(e.appConfig,a=>{const h=Go(a),y=Ko(e,h);return i=y.registrationPromise,y.installationEntry});return s.fid===Ye?{installationEntry:await i}:{installationEntry:s,registrationPromise:i}}function Go(e){const i=e||{fid:Fo(),registrationStatus:0};return hr(i)}function Ko(e,i){if(i.registrationStatus===0){if(!navigator.onLine){const h=Promise.reject(mt.create("app-offline"));return{installationEntry:i,registrationPromise:h}}const s={fid:i.fid,registrationStatus:1,registrationTime:Date.now()},a=qo(e,s);return{installationEntry:s,registrationPromise:a}}else return i.registrationStatus===1?{installationEntry:i,registrationPromise:Xo(e)}:{installationEntry:i}}async function qo(e,i){try{const s=await No(e,i);return he(e.appConfig,s)}catch(s){throw Yi(s)&&s.customData.serverCode===409?await ar(e.appConfig):await he(e.appConfig,{fid:i.fid,registrationStatus:0}),s}}async function Xo(e){let i=await Si(e.appConfig);for(;i.registrationStatus===1;)await ir(100),i=await Si(e.appConfig);if(i.registrationStatus===0){const{installationEntry:s,registrationPromise:a}=await on(e);return a||s}return i}function Si(e){return pe(e,i=>{if(!i)throw mt.create("installation-not-found");return hr(i)})}function hr(e){return Jo(e)?{fid:e.fid,registrationStatus:0}:e}function Jo(e){return e.registrationStatus===1&&e.registrationTime+qi<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Yo({appConfig:e,heartbeatServiceProvider:i},s){const a=Zo(e,s),h=ko(e,s),y=i.getImmediate({optional:!0});if(y){const E=await y.getHeartbeatsHeader();E&&h.append("x-firebase-client",E)}const p={installation:{sdkVersion:Xi,appId:e.appId}},b={method:"POST",headers:h,body:JSON.stringify(p)},S=await nr(()=>fetch(a,b));if(S.ok){const E=await S.json();return Qi(E)}else throw await tr("Generate Auth Token",S)}function Zo(e,{fid:i}){return`${Zi(e)}/${i}/authTokens:generate`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function an(e,i=!1){let s;const a=await pe(e.appConfig,y=>{if(!cr(y))throw mt.create("not-registered");const p=y.authToken;if(!i&&ea(p))return y;if(p.requestStatus===1)return s=Qo(e,i),y;{if(!navigator.onLine)throw mt.create("app-offline");const b=ia(y);return s=ta(e,b),b}});return s?await s:a.authToken}async function Qo(e,i){let s=await Ai(e.appConfig);for(;s.authToken.requestStatus===1;)await ir(100),s=await Ai(e.appConfig);const a=s.authToken;return a.requestStatus===0?an(e,i):a}function Ai(e){return pe(e,i=>{if(!cr(i))throw mt.create("not-registered");const s=i.authToken;return ra(s)?{...i,authToken:{requestStatus:0}}:i})}async function ta(e,i){try{const s=await Yo(e,i),a={...i,authToken:s};return await he(e.appConfig,a),s}catch(s){if(Yi(s)&&(s.customData.serverCode===401||s.customData.serverCode===404))await ar(e.appConfig);else{const a={...i,authToken:{requestStatus:0}};await he(e.appConfig,a)}throw s}}function cr(e){return e!==void 0&&e.registrationStatus===2}function ea(e){return e.requestStatus===2&&!na(e)}function na(e){const i=Date.now();return i<e.creationTime||e.creationTime+e.expiresIn<i+Oo}function ia(e){const i={requestStatus:1,requestTime:Date.now()};return{...e,authToken:i}}function ra(e){return e.requestStatus===1&&e.requestTime+qi<Date.now()}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function sa(e){const i=e,{installationEntry:s,registrationPromise:a}=await on(i);return a?a.catch(console.error):an(i).catch(console.error),s.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function oa(e,i=!1){const s=e;return await aa(s),(await an(s,i)).token}async function aa(e){const{registrationPromise:i}=await on(e);i&&await i}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ha(e){if(!e||!e.options)throw Ve("App Configuration");if(!e.name)throw Ve("App Name");const i=["projectId","apiKey","appId"];for(const s of i)if(!e.options[s])throw Ve(s);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}function Ve(e){return mt.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const lr="installations",ca="installations-internal",la=e=>{const i=e.getProvider("app").getImmediate(),s=ha(i),a=ue(i,"heartbeat");return{app:i,appConfig:s,heartbeatServiceProvider:a,_delete:()=>Promise.resolve()}},ua=e=>{const i=e.getProvider("app").getImmediate(),s=ue(i,lr).getImmediate();return{getId:()=>sa(s),getToken:h=>oa(s,h)}};function fa(){dt(new ot(lr,la,"PUBLIC")),dt(new ot(ca,ua,"PRIVATE"))}fa();st(Ki,rn);st(Ki,rn,"esm2020");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ce="analytics",pa="firebase_id",ga="origin",da=60*1e3,ma="https://firebase.googleapis.com/v1alpha/projects/-/apps/{app-id}/webConfig",hn="https://www.googletagmanager.com/gtag/js";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const L=new Hi("@firebase/analytics");/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ya={"already-exists":"A Firebase Analytics instance with the appId {$id}  already exists. Only one Firebase Analytics instance can be created for each appId.","already-initialized":"initializeAnalytics() cannot be called again with different options than those it was initially called with. It can be called again with the same options to return the existing instance, or getAnalytics() can be used to get a reference to the already-initialized instance.","already-initialized-settings":"Firebase Analytics has already been initialized.settings() must be called before initializing any Analytics instanceor it will have no effect.","interop-component-reg-failed":"Firebase Analytics Interop Component failed to instantiate: {$reason}","invalid-analytics-context":"Firebase Analytics is not supported in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","indexeddb-unavailable":"IndexedDB unavailable or restricted in this environment. Wrap initialization of analytics in analytics.isSupported() to prevent initialization in unsupported environments. Details: {$errorInfo}","fetch-throttle":"The config fetch request timed out while in an exponential backoff state. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.","config-fetch-failed":"Dynamic config fetch failed: [{$httpStatus}] {$responseMessage}","no-api-key":'The "apiKey" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid API key.',"no-app-id":'The "appId" field is empty in the local Firebase config. Firebase Analytics requires this field tocontain a valid app ID.',"no-client-id":'The "client_id" field is empty.',"invalid-gtag-resource":"Trusted Types detected an invalid gtag resource: {$gtagURL}."},V=new le("analytics","Analytics",ya);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function wa(e){if(!e.startsWith(hn)){const i=V.create("invalid-gtag-resource",{gtagURL:e});return L.warn(i.message),""}return e}function ur(e){return Promise.all(e.map(i=>i.catch(s=>s)))}function va(e,i){let s;return window.trustedTypes&&(s=window.trustedTypes.createPolicy(e,i)),s}function ba(e,i){const s=va("firebase-js-sdk-policy",{createScriptURL:wa}),a=document.createElement("script"),h=`${hn}?l=${e}&id=${i}`;a.src=s?s?.createScriptURL(h):h,a.async=!0,document.head.appendChild(a)}function Ia(e){let i=[];return Array.isArray(window[e])?i=window[e]:window[e]=i,i}async function Ea(e,i,s,a,h,y){const p=a[h];try{if(p)await i[p];else{const S=(await ur(s)).find(E=>E.measurementId===h);S&&await i[S.appId]}}catch(b){L.error(b)}e("config",h,y)}async function Sa(e,i,s,a,h){try{let y=[];if(h&&h.send_to){let p=h.send_to;Array.isArray(p)||(p=[p]);const b=await ur(s);for(const S of p){const E=b.find(A=>A.measurementId===S),_=E&&i[E.appId];if(_)y.push(_);else{y=[];break}}}y.length===0&&(y=Object.values(i)),await Promise.all(y),e("event",a,h||{})}catch(y){L.error(y)}}function Aa(e,i,s,a){async function h(y,...p){try{if(y==="event"){const[b,S]=p;await Sa(e,i,s,b,S)}else if(y==="config"){const[b,S]=p;await Ea(e,i,s,a,b,S)}else if(y==="consent"){const[b,S]=p;e("consent",b,S)}else if(y==="get"){const[b,S,E]=p;e("get",b,S,E)}else if(y==="set"){const[b]=p;e("set",b)}else e(y,...p)}catch(b){L.error(b)}}return h}function Ta(e,i,s,a,h){let y=function(...p){window[a].push(arguments)};return window[h]&&typeof window[h]=="function"&&(y=window[h]),window[h]=Aa(y,e,i,s),{gtagCore:y,wrappedGtag:window[h]}}function _a(e){const i=window.document.getElementsByTagName("script");for(const s of Object.values(i))if(s.src&&s.src.includes(hn)&&s.src.includes(e))return s;return null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ca=30,Da=1e3;class Oa{constructor(i={},s=Da){this.throttleMetadata=i,this.intervalMillis=s}getThrottleMetadata(i){return this.throttleMetadata[i]}setThrottleMetadata(i,s){this.throttleMetadata[i]=s}deleteThrottleMetadata(i){delete this.throttleMetadata[i]}}const fr=new Oa;function Ra(e){return new Headers({Accept:"application/json","x-goog-api-key":e})}async function Ma(e){const{appId:i,apiKey:s}=e,a={method:"GET",headers:Ra(s)},h=ma.replace("{app-id}",i),y=await fetch(h,a);if(y.status!==200&&y.status!==304){let p="";try{const b=await y.json();b.error?.message&&(p=b.error.message)}catch{}throw V.create("config-fetch-failed",{httpStatus:y.status,responseMessage:p})}return y.json()}async function Pa(e,i=fr,s){const{appId:a,apiKey:h,measurementId:y}=e.options;if(!a)throw V.create("no-app-id");if(!h){if(y)return{measurementId:y,appId:a};throw V.create("no-api-key")}const p=i.getThrottleMetadata(a)||{backoffCount:0,throttleEndTimeMillis:Date.now()},b=new Ba;return setTimeout(async()=>{b.abort()},da),pr({appId:a,apiKey:h,measurementId:y},p,b,i)}async function pr(e,{throttleEndTimeMillis:i,backoffCount:s},a,h=fr){const{appId:y,measurementId:p}=e;try{await ka(a,i)}catch(b){if(p)return L.warn(`Timed out fetching this Firebase app's measurement ID from the server. Falling back to the measurement ID ${p} provided in the "measurementId" field in the local Firebase config. [${b?.message}]`),{appId:y,measurementId:p};throw b}try{const b=await Ma(e);return h.deleteThrottleMetadata(y),b}catch(b){const S=b;if(!ja(S)){if(h.deleteThrottleMetadata(y),p)return L.warn(`Failed to fetch this Firebase app's measurement ID from the server. Falling back to the measurement ID ${p} provided in the "measurementId" field in the local Firebase config. [${S?.message}]`),{appId:y,measurementId:p};throw b}const E=Number(S?.customData?.httpStatus)===503?gi(s,h.intervalMillis,Ca):gi(s,h.intervalMillis),_={throttleEndTimeMillis:Date.now()+E,backoffCount:s+1};return h.setThrottleMetadata(y,_),L.debug(`Calling attemptFetch again in ${E} millis`),pr(e,_,a,h)}}function ka(e,i){return new Promise((s,a)=>{const h=Math.max(i-Date.now(),0),y=setTimeout(s,h);e.addEventListener(()=>{clearTimeout(y),a(V.create("fetch-throttle",{throttleEndTimeMillis:i}))})})}function ja(e){if(!(e instanceof wt)||!e.customData)return!1;const i=Number(e.customData.httpStatus);return i===429||i===500||i===503||i===504}class Ba{constructor(){this.listeners=[]}addEventListener(i){this.listeners.push(i)}abort(){this.listeners.forEach(i=>i())}}async function Na(e,i,s,a,h){if(h&&h.global){e("event",s,a);return}else{const y=await i,p={...a,send_to:y};e("event",s,p)}}async function xa(e,i,s,a){if(a&&a.global){const h={};for(const y of Object.keys(s))h[`user_properties.${y}`]=s[y];return e("set",h),Promise.resolve()}else{const h=await i;e("config",h,{update:!0,user_properties:s})}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function La(){if(Qe())try{await tn()}catch(e){return L.warn(V.create("indexeddb-unavailable",{errorInfo:e?.toString()}).message),!1}else return L.warn(V.create("indexeddb-unavailable",{errorInfo:"IndexedDB is not available in this environment."}).message),!1;return!0}async function Fa(e,i,s,a,h,y,p){const b=Pa(e);b.then(R=>{s[R.measurementId]=R.appId,e.options.measurementId&&R.measurementId!==e.options.measurementId&&L.warn(`The measurement ID in the local Firebase config (${e.options.measurementId}) does not match the measurement ID fetched from the server (${R.measurementId}). To ensure analytics events are always sent to the correct Analytics property, update the measurement ID field in the local config or remove it from the local config.`)}).catch(R=>L.error(R)),i.push(b);const S=La().then(R=>{if(R)return a.getId()}),[E,_]=await Promise.all([b,S]);_a(y)||ba(y,E.measurementId),h("js",new Date);const A=p?.config??{};return A[ga]="firebase",A.update=!0,_!=null&&(A[pa]=_),h("config",E.measurementId,A),E.measurementId}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $a{constructor(i){this.app=i}_delete(){return delete Tt[this.app.options.appId],Promise.resolve()}}let Tt={},Ti=[];const _i={};let ze="dataLayer",Ha="gtag",Ci,cn,Di=!1;function Ua(){const e=[];if(Li()&&e.push("This is a browser extension environment."),Fi()||e.push("Cookies are not available."),e.length>0){const i=e.map((a,h)=>`(${h+1}) ${a}`).join(" "),s=V.create("invalid-analytics-context",{errorInfo:i});L.warn(s.message)}}function Va(e,i,s){Ua();const a=e.options.appId;if(!a)throw V.create("no-app-id");if(!e.options.apiKey)if(e.options.measurementId)L.warn(`The "apiKey" field is empty in the local Firebase config. This is needed to fetch the latest measurement ID for this Firebase app. Falling back to the measurement ID ${e.options.measurementId} provided in the "measurementId" field in the local Firebase config.`);else throw V.create("no-api-key");if(Tt[a]!=null)throw V.create("already-exists",{id:a});if(!Di){Ia(ze);const{wrappedGtag:y,gtagCore:p}=Ta(Tt,Ti,_i,ze,Ha);cn=y,Ci=p,Di=!0}return Tt[a]=Fa(e,Ti,_i,i,Ci,ze,s),new $a(e)}function za(e=go()){e=en(e);const i=ue(e,ce);return i.isInitialized()?i.getImmediate():gr(e)}function gr(e,i={}){const s=ue(e,ce);if(s.isInitialized()){const h=s.getImmediate();if(ae(i,s.getOptions()))return h;throw V.create("already-initialized")}return s.initialize({options:i})}async function Wa(){if(Li()||!Fi()||!Qe())return!1;try{return await tn()}catch{return!1}}function dr(e,i,s){e=en(e),xa(cn,Tt[e.app.options.appId],i,s).catch(a=>L.error(a))}function mr(e,i,s,a){e=en(e),Na(cn,Tt[e.app.options.appId],i,s,a).catch(h=>L.error(h))}const Oi="@firebase/analytics",Ri="0.10.22";function Ga(){dt(new ot(ce,(i,{options:s})=>{const a=i.getProvider("app").getImmediate(),h=i.getProvider("installations-internal").getImmediate();return Va(a,h,s)},"PUBLIC")),dt(new ot("analytics-internal",e,"PRIVATE")),st(Oi,Ri),st(Oi,Ri,"esm2020");function e(i){try{const s=i.getProvider(ce).getImmediate();return{logEvent:(a,h,y)=>mr(s,a,h,y),setUserProperties:(a,h)=>dr(s,a,h)}}catch(s){throw V.create("interop-component-reg-failed",{reason:s})}}}Ga();const Dh=Object.freeze(Object.defineProperty({__proto__:null,getAnalytics:za,initializeAnalytics:gr,isSupported:Wa,logEvent:mr,setUserProperties:dr},Symbol.toStringTag,{value:"Module"}));var Mi=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Ka,qa;(function(){var e;/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/function i(g,c){function u(){}u.prototype=c.prototype,g.F=c.prototype,g.prototype=new u,g.prototype.constructor=g,g.D=function(d,f,w){for(var l=Array(arguments.length-2),H=2;H<arguments.length;H++)l[H-2]=arguments[H];return c.prototype[f].apply(d,l)}}function s(){this.blockSize=-1}function a(){this.blockSize=-1,this.blockSize=64,this.g=Array(4),this.C=Array(this.blockSize),this.o=this.h=0,this.u()}i(a,s),a.prototype.u=function(){this.g[0]=1732584193,this.g[1]=4023233417,this.g[2]=2562383102,this.g[3]=271733878,this.o=this.h=0};function h(g,c,u){u||(u=0);const d=Array(16);if(typeof c=="string")for(var f=0;f<16;++f)d[f]=c.charCodeAt(u++)|c.charCodeAt(u++)<<8|c.charCodeAt(u++)<<16|c.charCodeAt(u++)<<24;else for(f=0;f<16;++f)d[f]=c[u++]|c[u++]<<8|c[u++]<<16|c[u++]<<24;c=g.g[0],u=g.g[1],f=g.g[2];let w=g.g[3],l;l=c+(w^u&(f^w))+d[0]+3614090360&4294967295,c=u+(l<<7&4294967295|l>>>25),l=w+(f^c&(u^f))+d[1]+3905402710&4294967295,w=c+(l<<12&4294967295|l>>>20),l=f+(u^w&(c^u))+d[2]+606105819&4294967295,f=w+(l<<17&4294967295|l>>>15),l=u+(c^f&(w^c))+d[3]+3250441966&4294967295,u=f+(l<<22&4294967295|l>>>10),l=c+(w^u&(f^w))+d[4]+4118548399&4294967295,c=u+(l<<7&4294967295|l>>>25),l=w+(f^c&(u^f))+d[5]+1200080426&4294967295,w=c+(l<<12&4294967295|l>>>20),l=f+(u^w&(c^u))+d[6]+2821735955&4294967295,f=w+(l<<17&4294967295|l>>>15),l=u+(c^f&(w^c))+d[7]+4249261313&4294967295,u=f+(l<<22&4294967295|l>>>10),l=c+(w^u&(f^w))+d[8]+1770035416&4294967295,c=u+(l<<7&4294967295|l>>>25),l=w+(f^c&(u^f))+d[9]+2336552879&4294967295,w=c+(l<<12&4294967295|l>>>20),l=f+(u^w&(c^u))+d[10]+4294925233&4294967295,f=w+(l<<17&4294967295|l>>>15),l=u+(c^f&(w^c))+d[11]+2304563134&4294967295,u=f+(l<<22&4294967295|l>>>10),l=c+(w^u&(f^w))+d[12]+1804603682&4294967295,c=u+(l<<7&4294967295|l>>>25),l=w+(f^c&(u^f))+d[13]+4254626195&4294967295,w=c+(l<<12&4294967295|l>>>20),l=f+(u^w&(c^u))+d[14]+2792965006&4294967295,f=w+(l<<17&4294967295|l>>>15),l=u+(c^f&(w^c))+d[15]+1236535329&4294967295,u=f+(l<<22&4294967295|l>>>10),l=c+(f^w&(u^f))+d[1]+4129170786&4294967295,c=u+(l<<5&4294967295|l>>>27),l=w+(u^f&(c^u))+d[6]+3225465664&4294967295,w=c+(l<<9&4294967295|l>>>23),l=f+(c^u&(w^c))+d[11]+643717713&4294967295,f=w+(l<<14&4294967295|l>>>18),l=u+(w^c&(f^w))+d[0]+3921069994&4294967295,u=f+(l<<20&4294967295|l>>>12),l=c+(f^w&(u^f))+d[5]+3593408605&4294967295,c=u+(l<<5&4294967295|l>>>27),l=w+(u^f&(c^u))+d[10]+38016083&4294967295,w=c+(l<<9&4294967295|l>>>23),l=f+(c^u&(w^c))+d[15]+3634488961&4294967295,f=w+(l<<14&4294967295|l>>>18),l=u+(w^c&(f^w))+d[4]+3889429448&4294967295,u=f+(l<<20&4294967295|l>>>12),l=c+(f^w&(u^f))+d[9]+568446438&4294967295,c=u+(l<<5&4294967295|l>>>27),l=w+(u^f&(c^u))+d[14]+3275163606&4294967295,w=c+(l<<9&4294967295|l>>>23),l=f+(c^u&(w^c))+d[3]+4107603335&4294967295,f=w+(l<<14&4294967295|l>>>18),l=u+(w^c&(f^w))+d[8]+1163531501&4294967295,u=f+(l<<20&4294967295|l>>>12),l=c+(f^w&(u^f))+d[13]+2850285829&4294967295,c=u+(l<<5&4294967295|l>>>27),l=w+(u^f&(c^u))+d[2]+4243563512&4294967295,w=c+(l<<9&4294967295|l>>>23),l=f+(c^u&(w^c))+d[7]+1735328473&4294967295,f=w+(l<<14&4294967295|l>>>18),l=u+(w^c&(f^w))+d[12]+2368359562&4294967295,u=f+(l<<20&4294967295|l>>>12),l=c+(u^f^w)+d[5]+4294588738&4294967295,c=u+(l<<4&4294967295|l>>>28),l=w+(c^u^f)+d[8]+2272392833&4294967295,w=c+(l<<11&4294967295|l>>>21),l=f+(w^c^u)+d[11]+1839030562&4294967295,f=w+(l<<16&4294967295|l>>>16),l=u+(f^w^c)+d[14]+4259657740&4294967295,u=f+(l<<23&4294967295|l>>>9),l=c+(u^f^w)+d[1]+2763975236&4294967295,c=u+(l<<4&4294967295|l>>>28),l=w+(c^u^f)+d[4]+1272893353&4294967295,w=c+(l<<11&4294967295|l>>>21),l=f+(w^c^u)+d[7]+4139469664&4294967295,f=w+(l<<16&4294967295|l>>>16),l=u+(f^w^c)+d[10]+3200236656&4294967295,u=f+(l<<23&4294967295|l>>>9),l=c+(u^f^w)+d[13]+681279174&4294967295,c=u+(l<<4&4294967295|l>>>28),l=w+(c^u^f)+d[0]+3936430074&4294967295,w=c+(l<<11&4294967295|l>>>21),l=f+(w^c^u)+d[3]+3572445317&4294967295,f=w+(l<<16&4294967295|l>>>16),l=u+(f^w^c)+d[6]+76029189&4294967295,u=f+(l<<23&4294967295|l>>>9),l=c+(u^f^w)+d[9]+3654602809&4294967295,c=u+(l<<4&4294967295|l>>>28),l=w+(c^u^f)+d[12]+3873151461&4294967295,w=c+(l<<11&4294967295|l>>>21),l=f+(w^c^u)+d[15]+530742520&4294967295,f=w+(l<<16&4294967295|l>>>16),l=u+(f^w^c)+d[2]+3299628645&4294967295,u=f+(l<<23&4294967295|l>>>9),l=c+(f^(u|~w))+d[0]+4096336452&4294967295,c=u+(l<<6&4294967295|l>>>26),l=w+(u^(c|~f))+d[7]+1126891415&4294967295,w=c+(l<<10&4294967295|l>>>22),l=f+(c^(w|~u))+d[14]+2878612391&4294967295,f=w+(l<<15&4294967295|l>>>17),l=u+(w^(f|~c))+d[5]+4237533241&4294967295,u=f+(l<<21&4294967295|l>>>11),l=c+(f^(u|~w))+d[12]+1700485571&4294967295,c=u+(l<<6&4294967295|l>>>26),l=w+(u^(c|~f))+d[3]+2399980690&4294967295,w=c+(l<<10&4294967295|l>>>22),l=f+(c^(w|~u))+d[10]+4293915773&4294967295,f=w+(l<<15&4294967295|l>>>17),l=u+(w^(f|~c))+d[1]+2240044497&4294967295,u=f+(l<<21&4294967295|l>>>11),l=c+(f^(u|~w))+d[8]+1873313359&4294967295,c=u+(l<<6&4294967295|l>>>26),l=w+(u^(c|~f))+d[15]+4264355552&4294967295,w=c+(l<<10&4294967295|l>>>22),l=f+(c^(w|~u))+d[6]+2734768916&4294967295,f=w+(l<<15&4294967295|l>>>17),l=u+(w^(f|~c))+d[13]+1309151649&4294967295,u=f+(l<<21&4294967295|l>>>11),l=c+(f^(u|~w))+d[4]+4149444226&4294967295,c=u+(l<<6&4294967295|l>>>26),l=w+(u^(c|~f))+d[11]+3174756917&4294967295,w=c+(l<<10&4294967295|l>>>22),l=f+(c^(w|~u))+d[2]+718787259&4294967295,f=w+(l<<15&4294967295|l>>>17),l=u+(w^(f|~c))+d[9]+3951481745&4294967295,g.g[0]=g.g[0]+c&4294967295,g.g[1]=g.g[1]+(f+(l<<21&4294967295|l>>>11))&4294967295,g.g[2]=g.g[2]+f&4294967295,g.g[3]=g.g[3]+w&4294967295}a.prototype.v=function(g,c){c===void 0&&(c=g.length);const u=c-this.blockSize,d=this.C;let f=this.h,w=0;for(;w<c;){if(f==0)for(;w<=u;)h(this,g,w),w+=this.blockSize;if(typeof g=="string"){for(;w<c;)if(d[f++]=g.charCodeAt(w++),f==this.blockSize){h(this,d),f=0;break}}else for(;w<c;)if(d[f++]=g[w++],f==this.blockSize){h(this,d),f=0;break}}this.h=f,this.o+=c},a.prototype.A=function(){var g=Array((this.h<56?this.blockSize:this.blockSize*2)-this.h);g[0]=128;for(var c=1;c<g.length-8;++c)g[c]=0;c=this.o*8;for(var u=g.length-8;u<g.length;++u)g[u]=c&255,c/=256;for(this.v(g),g=Array(16),c=0,u=0;u<4;++u)for(let d=0;d<32;d+=8)g[c++]=this.g[u]>>>d&255;return g};function y(g,c){var u=b;return Object.prototype.hasOwnProperty.call(u,g)?u[g]:u[g]=c(g)}function p(g,c){this.h=c;const u=[];let d=!0;for(let f=g.length-1;f>=0;f--){const w=g[f]|0;d&&w==c||(u[f]=w,d=!1)}this.g=u}var b={};function S(g){return-128<=g&&g<128?y(g,function(c){return new p([c|0],c<0?-1:0)}):new p([g|0],g<0?-1:0)}function E(g){if(isNaN(g)||!isFinite(g))return A;if(g<0)return P(E(-g));const c=[];let u=1;for(let d=0;g>=u;d++)c[d]=g/u|0,u*=4294967296;return new p(c,0)}function _(g,c){if(g.length==0)throw Error("number format error: empty string");if(c=c||10,c<2||36<c)throw Error("radix out of range: "+c);if(g.charAt(0)=="-")return P(_(g.substring(1),c));if(g.indexOf("-")>=0)throw Error('number format error: interior "-" character');const u=E(Math.pow(c,8));let d=A;for(let w=0;w<g.length;w+=8){var f=Math.min(8,g.length-w);const l=parseInt(g.substring(w,w+f),c);f<8?(f=E(Math.pow(c,f)),d=d.j(f).add(E(l))):(d=d.j(u),d=d.add(E(l)))}return d}var A=S(0),R=S(1),W=S(16777216);e=p.prototype,e.m=function(){if($(this))return-P(this).m();let g=0,c=1;for(let u=0;u<this.g.length;u++){const d=this.i(u);g+=(d>=0?d:4294967296+d)*c,c*=4294967296}return g},e.toString=function(g){if(g=g||10,g<2||36<g)throw Error("radix out of range: "+g);if(F(this))return"0";if($(this))return"-"+P(this).toString(g);const c=E(Math.pow(g,6));var u=this;let d="";for(;;){const f=It(u,c).g;u=vt(u,f.j(c));let w=((u.g.length>0?u.g[0]:u.h)>>>0).toString(g);if(u=f,F(u))return w+d;for(;w.length<6;)w="0"+w;d=w+d}},e.i=function(g){return g<0?0:g<this.g.length?this.g[g]:this.h};function F(g){if(g.h!=0)return!1;for(let c=0;c<g.g.length;c++)if(g.g[c]!=0)return!1;return!0}function $(g){return g.h==-1}e.l=function(g){return g=vt(this,g),$(g)?-1:F(g)?0:1};function P(g){const c=g.g.length,u=[];for(let d=0;d<c;d++)u[d]=~g.g[d];return new p(u,~g.h).add(R)}e.abs=function(){return $(this)?P(this):this},e.add=function(g){const c=Math.max(this.g.length,g.g.length),u=[];let d=0;for(let f=0;f<=c;f++){let w=d+(this.i(f)&65535)+(g.i(f)&65535),l=(w>>>16)+(this.i(f)>>>16)+(g.i(f)>>>16);d=l>>>16,w&=65535,l&=65535,u[f]=l<<16|w}return new p(u,u[u.length-1]&-2147483648?-1:0)};function vt(g,c){return g.add(P(c))}e.j=function(g){if(F(this)||F(g))return A;if($(this))return $(g)?P(this).j(P(g)):P(P(this).j(g));if($(g))return P(this.j(P(g)));if(this.l(W)<0&&g.l(W)<0)return E(this.m()*g.m());const c=this.g.length+g.g.length,u=[];for(var d=0;d<2*c;d++)u[d]=0;for(d=0;d<this.g.length;d++)for(let f=0;f<g.g.length;f++){const w=this.i(d)>>>16,l=this.i(d)&65535,H=g.i(f)>>>16,at=g.i(f)&65535;u[2*d+2*f]+=l*at,bt(u,2*d+2*f),u[2*d+2*f+1]+=w*at,bt(u,2*d+2*f+1),u[2*d+2*f+1]+=l*H,bt(u,2*d+2*f+1),u[2*d+2*f+2]+=w*H,bt(u,2*d+2*f+2)}for(g=0;g<c;g++)u[g]=u[2*g+1]<<16|u[2*g];for(g=c;g<2*c;g++)u[g]=0;return new p(u,0)};function bt(g,c){for(;(g[c]&65535)!=g[c];)g[c+1]+=g[c]>>>16,g[c]&=65535,c++}function X(g,c){this.g=g,this.h=c}function It(g,c){if(F(c))throw Error("division by zero");if(F(g))return new X(A,A);if($(g))return c=It(P(g),c),new X(P(c.g),P(c.h));if($(c))return c=It(g,P(c)),new X(P(c.g),c.h);if(g.g.length>30){if($(g)||$(c))throw Error("slowDivide_ only works with positive integers.");for(var u=R,d=c;d.l(g)<=0;)u=J(u),d=J(d);var f=z(u,1),w=z(d,1);for(d=z(d,2),u=z(u,2);!F(d);){var l=w.add(d);l.l(g)<=0&&(f=f.add(u),w=l),d=z(d,1),u=z(u,1)}return c=vt(g,f.j(c)),new X(f,c)}for(f=A;g.l(c)>=0;){for(u=Math.max(1,Math.floor(g.m()/c.m())),d=Math.ceil(Math.log(u)/Math.LN2),d=d<=48?1:Math.pow(2,d-48),w=E(u),l=w.j(c);$(l)||l.l(g)>0;)u-=d,w=E(u),l=w.j(c);F(w)&&(w=R),f=f.add(w),g=vt(g,l)}return new X(f,g)}e.B=function(g){return It(this,g).h},e.and=function(g){const c=Math.max(this.g.length,g.g.length),u=[];for(let d=0;d<c;d++)u[d]=this.i(d)&g.i(d);return new p(u,this.h&g.h)},e.or=function(g){const c=Math.max(this.g.length,g.g.length),u=[];for(let d=0;d<c;d++)u[d]=this.i(d)|g.i(d);return new p(u,this.h|g.h)},e.xor=function(g){const c=Math.max(this.g.length,g.g.length),u=[];for(let d=0;d<c;d++)u[d]=this.i(d)^g.i(d);return new p(u,this.h^g.h)};function J(g){const c=g.g.length+1,u=[];for(let d=0;d<c;d++)u[d]=g.i(d)<<1|g.i(d-1)>>>31;return new p(u,g.h)}function z(g,c){const u=c>>5;c%=32;const d=g.g.length-u,f=[];for(let w=0;w<d;w++)f[w]=c>0?g.i(w+u)>>>c|g.i(w+u+1)<<32-c:g.i(w+u);return new p(f,g.h)}a.prototype.digest=a.prototype.A,a.prototype.reset=a.prototype.u,a.prototype.update=a.prototype.v,qa=a,p.prototype.add=p.prototype.add,p.prototype.multiply=p.prototype.j,p.prototype.modulo=p.prototype.B,p.prototype.compare=p.prototype.l,p.prototype.toNumber=p.prototype.m,p.prototype.toString=p.prototype.toString,p.prototype.getBits=p.prototype.i,p.fromNumber=E,p.fromString=_,Ka=p}).apply(typeof Mi<"u"?Mi:typeof self<"u"?self:typeof window<"u"?window:{});var se=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};/** @license
Copyright The Closure Library Authors.
SPDX-License-Identifier: Apache-2.0
*/var Xa,Ja,Ya,Za,Qa,th,eh,nh;(function(){var e,i=Object.defineProperty;function s(t){t=[typeof globalThis=="object"&&globalThis,t,typeof window=="object"&&window,typeof self=="object"&&self,typeof se=="object"&&se];for(var n=0;n<t.length;++n){var r=t[n];if(r&&r.Math==Math)return r}throw Error("Cannot find global object")}var a=s(this);function h(t,n){if(n)t:{var r=a;t=t.split(".");for(var o=0;o<t.length-1;o++){var m=t[o];if(!(m in r))break t;r=r[m]}t=t[t.length-1],o=r[t],n=n(o),n!=o&&n!=null&&i(r,t,{configurable:!0,writable:!0,value:n})}}h("Symbol.dispose",function(t){return t||Symbol("Symbol.dispose")}),h("Array.prototype.values",function(t){return t||function(){return this[Symbol.iterator]()}}),h("Object.entries",function(t){return t||function(n){var r=[],o;for(o in n)Object.prototype.hasOwnProperty.call(n,o)&&r.push([o,n[o]]);return r}});/** @license

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/var y=y||{},p=this||self;function b(t){var n=typeof t;return n=="object"&&t!=null||n=="function"}function S(t,n,r){return t.call.apply(t.bind,arguments)}function E(t,n,r){return E=S,E.apply(null,arguments)}function _(t,n){var r=Array.prototype.slice.call(arguments,1);return function(){var o=r.slice();return o.push.apply(o,arguments),t.apply(this,o)}}function A(t,n){function r(){}r.prototype=n.prototype,t.Z=n.prototype,t.prototype=new r,t.prototype.constructor=t,t.Ob=function(o,m,v){for(var I=Array(arguments.length-2),T=2;T<arguments.length;T++)I[T-2]=arguments[T];return n.prototype[m].apply(o,I)}}var R=typeof AsyncContext<"u"&&typeof AsyncContext.Snapshot=="function"?t=>t&&AsyncContext.Snapshot.wrap(t):t=>t;function W(t){const n=t.length;if(n>0){const r=Array(n);for(let o=0;o<n;o++)r[o]=t[o];return r}return[]}function F(t,n){for(let o=1;o<arguments.length;o++){const m=arguments[o];var r=typeof m;if(r=r!="object"?r:m?Array.isArray(m)?"array":r:"null",r=="array"||r=="object"&&typeof m.length=="number"){r=t.length||0;const v=m.length||0;t.length=r+v;for(let I=0;I<v;I++)t[r+I]=m[I]}else t.push(m)}}class ${constructor(n,r){this.i=n,this.j=r,this.h=0,this.g=null}get(){let n;return this.h>0?(this.h--,n=this.g,this.g=n.next,n.next=null):n=this.i(),n}}function P(t){p.setTimeout(()=>{throw t},0)}function vt(){var t=g;let n=null;return t.g&&(n=t.g,t.g=t.g.next,t.g||(t.h=null),n.next=null),n}class bt{constructor(){this.h=this.g=null}add(n,r){const o=X.get();o.set(n,r),this.h?this.h.next=o:this.g=o,this.h=o}}var X=new $(()=>new It,t=>t.reset());class It{constructor(){this.next=this.g=this.h=null}set(n,r){this.h=n,this.g=r,this.next=null}reset(){this.next=this.g=this.h=null}}let J,z=!1,g=new bt,c=()=>{const t=Promise.resolve(void 0);J=()=>{t.then(u)}};function u(){for(var t;t=vt();){try{t.h.call(t.g)}catch(r){P(r)}var n=X;n.j(t),n.h<100&&(n.h++,t.next=n.g,n.g=t)}z=!1}function d(){this.u=this.u,this.C=this.C}d.prototype.u=!1,d.prototype.dispose=function(){this.u||(this.u=!0,this.N())},d.prototype[Symbol.dispose]=function(){this.dispose()},d.prototype.N=function(){if(this.C)for(;this.C.length;)this.C.shift()()};function f(t,n){this.type=t,this.g=this.target=n,this.defaultPrevented=!1}f.prototype.h=function(){this.defaultPrevented=!0};var w=(function(){if(!p.addEventListener||!Object.defineProperty)return!1;var t=!1,n=Object.defineProperty({},"passive",{get:function(){t=!0}});try{const r=()=>{};p.addEventListener("test",r,n),p.removeEventListener("test",r,n)}catch{}return t})();function l(t){return/^[\s\xa0]*$/.test(t)}function H(t,n){f.call(this,t?t.type:""),this.relatedTarget=this.g=this.target=null,this.button=this.screenY=this.screenX=this.clientY=this.clientX=0,this.key="",this.metaKey=this.shiftKey=this.altKey=this.ctrlKey=!1,this.state=null,this.pointerId=0,this.pointerType="",this.i=null,t&&this.init(t,n)}A(H,f),H.prototype.init=function(t,n){const r=this.type=t.type,o=t.changedTouches&&t.changedTouches.length?t.changedTouches[0]:null;this.target=t.target||t.srcElement,this.g=n,n=t.relatedTarget,n||(r=="mouseover"?n=t.fromElement:r=="mouseout"&&(n=t.toElement)),this.relatedTarget=n,o?(this.clientX=o.clientX!==void 0?o.clientX:o.pageX,this.clientY=o.clientY!==void 0?o.clientY:o.pageY,this.screenX=o.screenX||0,this.screenY=o.screenY||0):(this.clientX=t.clientX!==void 0?t.clientX:t.pageX,this.clientY=t.clientY!==void 0?t.clientY:t.pageY,this.screenX=t.screenX||0,this.screenY=t.screenY||0),this.button=t.button,this.key=t.key||"",this.ctrlKey=t.ctrlKey,this.altKey=t.altKey,this.shiftKey=t.shiftKey,this.metaKey=t.metaKey,this.pointerId=t.pointerId||0,this.pointerType=t.pointerType,this.state=t.state,this.i=t,t.defaultPrevented&&H.Z.h.call(this)},H.prototype.h=function(){H.Z.h.call(this);const t=this.i;t.preventDefault?t.preventDefault():t.returnValue=!1};var at="closure_listenable_"+(Math.random()*1e6|0),yr=0;function wr(t,n,r,o,m){this.listener=t,this.proxy=null,this.src=n,this.type=r,this.capture=!!o,this.ha=m,this.key=++yr,this.da=this.fa=!1}function zt(t){t.da=!0,t.listener=null,t.proxy=null,t.src=null,t.ha=null}function Wt(t,n,r){for(const o in t)n.call(r,t[o],o,t)}function vr(t,n){for(const r in t)n.call(void 0,t[r],r,t)}function ln(t){const n={};for(const r in t)n[r]=t[r];return n}const un="constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");function fn(t,n){let r,o;for(let m=1;m<arguments.length;m++){o=arguments[m];for(r in o)t[r]=o[r];for(let v=0;v<un.length;v++)r=un[v],Object.prototype.hasOwnProperty.call(o,r)&&(t[r]=o[r])}}function Gt(t){this.src=t,this.g={},this.h=0}Gt.prototype.add=function(t,n,r,o,m){const v=t.toString();t=this.g[v],t||(t=this.g[v]=[],this.h++);const I=de(t,n,o,m);return I>-1?(n=t[I],r||(n.fa=!1)):(n=new wr(n,this.src,v,!!o,m),n.fa=r,t.push(n)),n};function ge(t,n){const r=n.type;if(r in t.g){var o=t.g[r],m=Array.prototype.indexOf.call(o,n,void 0),v;(v=m>=0)&&Array.prototype.splice.call(o,m,1),v&&(zt(n),t.g[r].length==0&&(delete t.g[r],t.h--))}}function de(t,n,r,o){for(let m=0;m<t.length;++m){const v=t[m];if(!v.da&&v.listener==n&&v.capture==!!r&&v.ha==o)return m}return-1}var me="closure_lm_"+(Math.random()*1e6|0),ye={};function pn(t,n,r,o,m){if(Array.isArray(n)){for(let v=0;v<n.length;v++)pn(t,n[v],r,o,m);return null}return r=mn(r),t&&t[at]?t.J(n,r,b(o)?!!o.capture:!1,m):br(t,n,r,!1,o,m)}function br(t,n,r,o,m,v){if(!n)throw Error("Invalid event type");const I=b(m)?!!m.capture:!!m;let T=ve(t);if(T||(t[me]=T=new Gt(t)),r=T.add(n,r,o,I,v),r.proxy)return r;if(o=Ir(),r.proxy=o,o.src=t,o.listener=r,t.addEventListener)w||(m=I),m===void 0&&(m=!1),t.addEventListener(n.toString(),o,m);else if(t.attachEvent)t.attachEvent(dn(n.toString()),o);else if(t.addListener&&t.removeListener)t.addListener(o);else throw Error("addEventListener and attachEvent are unavailable.");return r}function Ir(){function t(r){return n.call(t.src,t.listener,r)}const n=Er;return t}function gn(t,n,r,o,m){if(Array.isArray(n))for(var v=0;v<n.length;v++)gn(t,n[v],r,o,m);else o=b(o)?!!o.capture:!!o,r=mn(r),t&&t[at]?(t=t.i,v=String(n).toString(),v in t.g&&(n=t.g[v],r=de(n,r,o,m),r>-1&&(zt(n[r]),Array.prototype.splice.call(n,r,1),n.length==0&&(delete t.g[v],t.h--)))):t&&(t=ve(t))&&(n=t.g[n.toString()],t=-1,n&&(t=de(n,r,o,m)),(r=t>-1?n[t]:null)&&we(r))}function we(t){if(typeof t!="number"&&t&&!t.da){var n=t.src;if(n&&n[at])ge(n.i,t);else{var r=t.type,o=t.proxy;n.removeEventListener?n.removeEventListener(r,o,t.capture):n.detachEvent?n.detachEvent(dn(r),o):n.addListener&&n.removeListener&&n.removeListener(o),(r=ve(n))?(ge(r,t),r.h==0&&(r.src=null,n[me]=null)):zt(t)}}}function dn(t){return t in ye?ye[t]:ye[t]="on"+t}function Er(t,n){if(t.da)t=!0;else{n=new H(n,this);const r=t.listener,o=t.ha||t.src;t.fa&&we(t),t=r.call(o,n)}return t}function ve(t){return t=t[me],t instanceof Gt?t:null}var be="__closure_events_fn_"+(Math.random()*1e9>>>0);function mn(t){return typeof t=="function"?t:(t[be]||(t[be]=function(n){return t.handleEvent(n)}),t[be])}function B(){d.call(this),this.i=new Gt(this),this.M=this,this.G=null}A(B,d),B.prototype[at]=!0,B.prototype.removeEventListener=function(t,n,r,o){gn(this,t,n,r,o)};function N(t,n){var r,o=t.G;if(o)for(r=[];o;o=o.G)r.push(o);if(t=t.M,o=n.type||n,typeof n=="string")n=new f(n,t);else if(n instanceof f)n.target=n.target||t;else{var m=n;n=new f(o,t),fn(n,m)}m=!0;let v,I;if(r)for(I=r.length-1;I>=0;I--)v=n.g=r[I],m=Kt(v,o,!0,n)&&m;if(v=n.g=t,m=Kt(v,o,!0,n)&&m,m=Kt(v,o,!1,n)&&m,r)for(I=0;I<r.length;I++)v=n.g=r[I],m=Kt(v,o,!1,n)&&m}B.prototype.N=function(){if(B.Z.N.call(this),this.i){var t=this.i;for(const n in t.g){const r=t.g[n];for(let o=0;o<r.length;o++)zt(r[o]);delete t.g[n],t.h--}}this.G=null},B.prototype.J=function(t,n,r,o){return this.i.add(String(t),n,!1,r,o)},B.prototype.K=function(t,n,r,o){return this.i.add(String(t),n,!0,r,o)};function Kt(t,n,r,o){if(n=t.i.g[String(n)],!n)return!0;n=n.concat();let m=!0;for(let v=0;v<n.length;++v){const I=n[v];if(I&&!I.da&&I.capture==r){const T=I.listener,k=I.ha||I.src;I.fa&&ge(t.i,I),m=T.call(k,o)!==!1&&m}}return m&&!o.defaultPrevented}function Sr(t,n){if(typeof t!="function")if(t&&typeof t.handleEvent=="function")t=E(t.handleEvent,t);else throw Error("Invalid listener argument");return Number(n)>2147483647?-1:p.setTimeout(t,n||0)}function yn(t){t.g=Sr(()=>{t.g=null,t.i&&(t.i=!1,yn(t))},t.l);const n=t.h;t.h=null,t.m.apply(null,n)}class Ar extends d{constructor(n,r){super(),this.m=n,this.l=r,this.h=null,this.i=!1,this.g=null}j(n){this.h=arguments,this.g?this.i=!0:yn(this)}N(){super.N(),this.g&&(p.clearTimeout(this.g),this.g=null,this.i=!1,this.h=null)}}function _t(t){d.call(this),this.h=t,this.g={}}A(_t,d);var wn=[];function vn(t){Wt(t.g,function(n,r){this.g.hasOwnProperty(r)&&we(n)},t),t.g={}}_t.prototype.N=function(){_t.Z.N.call(this),vn(this)},_t.prototype.handleEvent=function(){throw Error("EventHandler.handleEvent not implemented")};var Ie=p.JSON.stringify,Tr=p.JSON.parse,_r=class{stringify(t){return p.JSON.stringify(t,void 0)}parse(t){return p.JSON.parse(t,void 0)}};function bn(){}function In(){}var Ct={OPEN:"a",hb:"b",ERROR:"c",tb:"d"};function Ee(){f.call(this,"d")}A(Ee,f);function Se(){f.call(this,"c")}A(Se,f);var ht={},En=null;function qt(){return En=En||new B}ht.Ia="serverreachability";function Sn(t){f.call(this,ht.Ia,t)}A(Sn,f);function Dt(t){const n=qt();N(n,new Sn(n))}ht.STAT_EVENT="statevent";function An(t,n){f.call(this,ht.STAT_EVENT,t),this.stat=n}A(An,f);function x(t){const n=qt();N(n,new An(n,t))}ht.Ja="timingevent";function Tn(t,n){f.call(this,ht.Ja,t),this.size=n}A(Tn,f);function Ot(t,n){if(typeof t!="function")throw Error("Fn must not be null and must be a function");return p.setTimeout(function(){t()},n)}function Rt(){this.g=!0}Rt.prototype.ua=function(){this.g=!1};function Cr(t,n,r,o,m,v){t.info(function(){if(t.g)if(v){var I="",T=v.split("&");for(let C=0;C<T.length;C++){var k=T[C].split("=");if(k.length>1){const j=k[0];k=k[1];const K=j.split("_");I=K.length>=2&&K[1]=="type"?I+(j+"="+k+"&"):I+(j+"=redacted&")}}}else I=null;else I=v;return"XMLHTTP REQ ("+o+") [attempt "+m+"]: "+n+`
`+r+`
`+I})}function Dr(t,n,r,o,m,v,I){t.info(function(){return"XMLHTTP RESP ("+o+") [ attempt "+m+"]: "+n+`
`+r+`
`+v+" "+I})}function Et(t,n,r,o){t.info(function(){return"XMLHTTP TEXT ("+n+"): "+Rr(t,r)+(o?" "+o:"")})}function Or(t,n){t.info(function(){return"TIMEOUT: "+n})}Rt.prototype.info=function(){};function Rr(t,n){if(!t.g)return n;if(!n)return null;try{const v=JSON.parse(n);if(v){for(t=0;t<v.length;t++)if(Array.isArray(v[t])){var r=v[t];if(!(r.length<2)){var o=r[1];if(Array.isArray(o)&&!(o.length<1)){var m=o[0];if(m!="noop"&&m!="stop"&&m!="close")for(let I=1;I<o.length;I++)o[I]=""}}}}return Ie(v)}catch{return n}}var Xt={NO_ERROR:0,cb:1,qb:2,pb:3,kb:4,ob:5,rb:6,Ga:7,TIMEOUT:8,ub:9},_n={ib:"complete",Fb:"success",ERROR:"error",Ga:"abort",xb:"ready",yb:"readystatechange",TIMEOUT:"timeout",sb:"incrementaldata",wb:"progress",lb:"downloadprogress",Nb:"uploadprogress"},Cn;function Ae(){}A(Ae,bn),Ae.prototype.g=function(){return new XMLHttpRequest},Cn=new Ae;function Mt(t){return encodeURIComponent(String(t))}function Mr(t){var n=1;t=t.split(":");const r=[];for(;n>0&&t.length;)r.push(t.shift()),n--;return t.length&&r.push(t.join(":")),r}function Y(t,n,r,o){this.j=t,this.i=n,this.l=r,this.S=o||1,this.V=new _t(this),this.H=45e3,this.J=null,this.o=!1,this.u=this.B=this.A=this.M=this.F=this.T=this.D=null,this.G=[],this.g=null,this.C=0,this.m=this.v=null,this.X=-1,this.K=!1,this.P=0,this.O=null,this.W=this.L=this.U=this.R=!1,this.h=new Dn}function Dn(){this.i=null,this.g="",this.h=!1}var On={},Te={};function _e(t,n,r){t.M=1,t.A=Yt(G(n)),t.u=r,t.R=!0,Rn(t,null)}function Rn(t,n){t.F=Date.now(),Jt(t),t.B=G(t.A);var r=t.B,o=t.S;Array.isArray(o)||(o=[String(o)]),Vn(r.i,"t",o),t.C=0,r=t.j.L,t.h=new Dn,t.g=ai(t.j,r?n:null,!t.u),t.P>0&&(t.O=new Ar(E(t.Y,t,t.g),t.P)),n=t.V,r=t.g,o=t.ba;var m="readystatechange";Array.isArray(m)||(m&&(wn[0]=m.toString()),m=wn);for(let v=0;v<m.length;v++){const I=pn(r,m[v],o||n.handleEvent,!1,n.h||n);if(!I)break;n.g[I.key]=I}n=t.J?ln(t.J):{},t.u?(t.v||(t.v="POST"),n["Content-Type"]="application/x-www-form-urlencoded",t.g.ea(t.B,t.v,t.u,n)):(t.v="GET",t.g.ea(t.B,t.v,null,n)),Dt(),Cr(t.i,t.v,t.B,t.l,t.S,t.u)}Y.prototype.ba=function(t){t=t.target;const n=this.O;n&&tt(t)==3?n.j():this.Y(t)},Y.prototype.Y=function(t){try{if(t==this.g)t:{const T=tt(this.g),k=this.g.ya(),C=this.g.ca();if(!(T<3)&&(T!=3||this.g&&(this.h.h||this.g.la()||Jn(this.g)))){this.K||T!=4||k==7||(k==8||C<=0?Dt(3):Dt(2)),Ce(this);var n=this.g.ca();this.X=n;var r=Pr(this);if(this.o=n==200,Dr(this.i,this.v,this.B,this.l,this.S,T,n),this.o){if(this.U&&!this.L){e:{if(this.g){var o,m=this.g;if((o=m.g?m.g.getResponseHeader("X-HTTP-Initial-Response"):null)&&!l(o)){var v=o;break e}}v=null}if(t=v)Et(this.i,this.l,t,"Initial handshake response via X-HTTP-Initial-Response"),this.L=!0,De(this,t);else{this.o=!1,this.m=3,x(12),ct(this),Pt(this);break t}}if(this.R){t=!0;let j;for(;!this.K&&this.C<r.length;)if(j=kr(this,r),j==Te){T==4&&(this.m=4,x(14),t=!1),Et(this.i,this.l,null,"[Incomplete Response]");break}else if(j==On){this.m=4,x(15),Et(this.i,this.l,r,"[Invalid Chunk]"),t=!1;break}else Et(this.i,this.l,j,null),De(this,j);if(Mn(this)&&this.C!=0&&(this.h.g=this.h.g.slice(this.C),this.C=0),T!=4||r.length!=0||this.h.h||(this.m=1,x(16),t=!1),this.o=this.o&&t,!t)Et(this.i,this.l,r,"[Invalid Chunked Response]"),ct(this),Pt(this);else if(r.length>0&&!this.W){this.W=!0;var I=this.j;I.g==this&&I.aa&&!I.P&&(I.j.info("Great, no buffering proxy detected. Bytes received: "+r.length),Ne(I),I.P=!0,x(11))}}else Et(this.i,this.l,r,null),De(this,r);T==4&&ct(this),this.o&&!this.K&&(T==4?ii(this.j,this):(this.o=!1,Jt(this)))}else Kr(this.g),n==400&&r.indexOf("Unknown SID")>0?(this.m=3,x(12)):(this.m=0,x(13)),ct(this),Pt(this)}}}catch{}};function Pr(t){if(!Mn(t))return t.g.la();const n=Jn(t.g);if(n==="")return"";let r="";const o=n.length,m=tt(t.g)==4;if(!t.h.i){if(typeof TextDecoder>"u")return ct(t),Pt(t),"";t.h.i=new p.TextDecoder}for(let v=0;v<o;v++)t.h.h=!0,r+=t.h.i.decode(n[v],{stream:!(m&&v==o-1)});return n.length=0,t.h.g+=r,t.C=0,t.h.g}function Mn(t){return t.g?t.v=="GET"&&t.M!=2&&t.j.Aa:!1}function kr(t,n){var r=t.C,o=n.indexOf(`
`,r);return o==-1?Te:(r=Number(n.substring(r,o)),isNaN(r)?On:(o+=1,o+r>n.length?Te:(n=n.slice(o,o+r),t.C=o+r,n)))}Y.prototype.cancel=function(){this.K=!0,ct(this)};function Jt(t){t.T=Date.now()+t.H,Pn(t,t.H)}function Pn(t,n){if(t.D!=null)throw Error("WatchDog timer not null");t.D=Ot(E(t.aa,t),n)}function Ce(t){t.D&&(p.clearTimeout(t.D),t.D=null)}Y.prototype.aa=function(){this.D=null;const t=Date.now();t-this.T>=0?(Or(this.i,this.B),this.M!=2&&(Dt(),x(17)),ct(this),this.m=2,Pt(this)):Pn(this,this.T-t)};function Pt(t){t.j.I==0||t.K||ii(t.j,t)}function ct(t){Ce(t);var n=t.O;n&&typeof n.dispose=="function"&&n.dispose(),t.O=null,vn(t.V),t.g&&(n=t.g,t.g=null,n.abort(),n.dispose())}function De(t,n){try{var r=t.j;if(r.I!=0&&(r.g==t||Oe(r.h,t))){if(!t.L&&Oe(r.h,t)&&r.I==3){try{var o=r.Ba.g.parse(n)}catch{o=null}if(Array.isArray(o)&&o.length==3){var m=o;if(m[0]==0){t:if(!r.v){if(r.g)if(r.g.F+3e3<t.F)ne(r),te(r);else break t;Be(r),x(18)}}else r.xa=m[1],0<r.xa-r.K&&m[2]<37500&&r.F&&r.A==0&&!r.C&&(r.C=Ot(E(r.Va,r),6e3));Bn(r.h)<=1&&r.ta&&(r.ta=void 0)}else ut(r,11)}else if((t.L||r.g==t)&&ne(r),!l(n))for(m=r.Ba.g.parse(n),n=0;n<m.length;n++){let C=m[n];const j=C[0];if(!(j<=r.K))if(r.K=j,C=C[1],r.I==2)if(C[0]=="c"){r.M=C[1],r.ba=C[2];const K=C[3];K!=null&&(r.ka=K,r.j.info("VER="+r.ka));const ft=C[4];ft!=null&&(r.za=ft,r.j.info("SVER="+r.za));const et=C[5];et!=null&&typeof et=="number"&&et>0&&(o=1.5*et,r.O=o,r.j.info("backChannelRequestTimeoutMs_="+o)),o=r;const nt=t.g;if(nt){const re=nt.g?nt.g.getResponseHeader("X-Client-Wire-Protocol"):null;if(re){var v=o.h;v.g||re.indexOf("spdy")==-1&&re.indexOf("quic")==-1&&re.indexOf("h2")==-1||(v.j=v.l,v.g=new Set,v.h&&(Re(v,v.h),v.h=null))}if(o.G){const xe=nt.g?nt.g.getResponseHeader("X-HTTP-Session-Id"):null;xe&&(o.wa=xe,D(o.J,o.G,xe))}}r.I=3,r.l&&r.l.ra(),r.aa&&(r.T=Date.now()-t.F,r.j.info("Handshake RTT: "+r.T+"ms")),o=r;var I=t;if(o.na=oi(o,o.L?o.ba:null,o.W),I.L){Nn(o.h,I);var T=I,k=o.O;k&&(T.H=k),T.D&&(Ce(T),Jt(T)),o.g=I}else ei(o);r.i.length>0&&ee(r)}else C[0]!="stop"&&C[0]!="close"||ut(r,7);else r.I==3&&(C[0]=="stop"||C[0]=="close"?C[0]=="stop"?ut(r,7):je(r):C[0]!="noop"&&r.l&&r.l.qa(C),r.A=0)}}Dt(4)}catch{}}var jr=class{constructor(t,n){this.g=t,this.map=n}};function kn(t){this.l=t||10,p.PerformanceNavigationTiming?(t=p.performance.getEntriesByType("navigation"),t=t.length>0&&(t[0].nextHopProtocol=="hq"||t[0].nextHopProtocol=="h2")):t=!!(p.chrome&&p.chrome.loadTimes&&p.chrome.loadTimes()&&p.chrome.loadTimes().wasFetchedViaSpdy),this.j=t?this.l:1,this.g=null,this.j>1&&(this.g=new Set),this.h=null,this.i=[]}function jn(t){return t.h?!0:t.g?t.g.size>=t.j:!1}function Bn(t){return t.h?1:t.g?t.g.size:0}function Oe(t,n){return t.h?t.h==n:t.g?t.g.has(n):!1}function Re(t,n){t.g?t.g.add(n):t.h=n}function Nn(t,n){t.h&&t.h==n?t.h=null:t.g&&t.g.has(n)&&t.g.delete(n)}kn.prototype.cancel=function(){if(this.i=xn(this),this.h)this.h.cancel(),this.h=null;else if(this.g&&this.g.size!==0){for(const t of this.g.values())t.cancel();this.g.clear()}};function xn(t){if(t.h!=null)return t.i.concat(t.h.G);if(t.g!=null&&t.g.size!==0){let n=t.i;for(const r of t.g.values())n=n.concat(r.G);return n}return W(t.i)}var Ln=RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");function Br(t,n){if(t){t=t.split("&");for(let r=0;r<t.length;r++){const o=t[r].indexOf("=");let m,v=null;o>=0?(m=t[r].substring(0,o),v=t[r].substring(o+1)):m=t[r],n(m,v?decodeURIComponent(v.replace(/\+/g," ")):"")}}}function Z(t){this.g=this.o=this.j="",this.u=null,this.m=this.h="",this.l=!1;let n;t instanceof Z?(this.l=t.l,kt(this,t.j),this.o=t.o,this.g=t.g,jt(this,t.u),this.h=t.h,Me(this,zn(t.i)),this.m=t.m):t&&(n=String(t).match(Ln))?(this.l=!1,kt(this,n[1]||"",!0),this.o=Bt(n[2]||""),this.g=Bt(n[3]||"",!0),jt(this,n[4]),this.h=Bt(n[5]||"",!0),Me(this,n[6]||"",!0),this.m=Bt(n[7]||"")):(this.l=!1,this.i=new xt(null,this.l))}Z.prototype.toString=function(){const t=[];var n=this.j;n&&t.push(Nt(n,Fn,!0),":");var r=this.g;return(r||n=="file")&&(t.push("//"),(n=this.o)&&t.push(Nt(n,Fn,!0),"@"),t.push(Mt(r).replace(/%25([0-9a-fA-F]{2})/g,"%$1")),r=this.u,r!=null&&t.push(":",String(r))),(r=this.h)&&(this.g&&r.charAt(0)!="/"&&t.push("/"),t.push(Nt(r,r.charAt(0)=="/"?Lr:xr,!0))),(r=this.i.toString())&&t.push("?",r),(r=this.m)&&t.push("#",Nt(r,$r)),t.join("")},Z.prototype.resolve=function(t){const n=G(this);let r=!!t.j;r?kt(n,t.j):r=!!t.o,r?n.o=t.o:r=!!t.g,r?n.g=t.g:r=t.u!=null;var o=t.h;if(r)jt(n,t.u);else if(r=!!t.h){if(o.charAt(0)!="/")if(this.g&&!this.h)o="/"+o;else{var m=n.h.lastIndexOf("/");m!=-1&&(o=n.h.slice(0,m+1)+o)}if(m=o,m==".."||m==".")o="";else if(m.indexOf("./")!=-1||m.indexOf("/.")!=-1){o=m.lastIndexOf("/",0)==0,m=m.split("/");const v=[];for(let I=0;I<m.length;){const T=m[I++];T=="."?o&&I==m.length&&v.push(""):T==".."?((v.length>1||v.length==1&&v[0]!="")&&v.pop(),o&&I==m.length&&v.push("")):(v.push(T),o=!0)}o=v.join("/")}else o=m}return r?n.h=o:r=t.i.toString()!=="",r?Me(n,zn(t.i)):r=!!t.m,r&&(n.m=t.m),n};function G(t){return new Z(t)}function kt(t,n,r){t.j=r?Bt(n,!0):n,t.j&&(t.j=t.j.replace(/:$/,""))}function jt(t,n){if(n){if(n=Number(n),isNaN(n)||n<0)throw Error("Bad port number "+n);t.u=n}else t.u=null}function Me(t,n,r){n instanceof xt?(t.i=n,Hr(t.i,t.l)):(r||(n=Nt(n,Fr)),t.i=new xt(n,t.l))}function D(t,n,r){t.i.set(n,r)}function Yt(t){return D(t,"zx",Math.floor(Math.random()*2147483648).toString(36)+Math.abs(Math.floor(Math.random()*2147483648)^Date.now()).toString(36)),t}function Bt(t,n){return t?n?decodeURI(t.replace(/%25/g,"%2525")):decodeURIComponent(t):""}function Nt(t,n,r){return typeof t=="string"?(t=encodeURI(t).replace(n,Nr),r&&(t=t.replace(/%25([0-9a-fA-F]{2})/g,"%$1")),t):null}function Nr(t){return t=t.charCodeAt(0),"%"+(t>>4&15).toString(16)+(t&15).toString(16)}var Fn=/[#\/\?@]/g,xr=/[#\?:]/g,Lr=/[#\?]/g,Fr=/[#\?@]/g,$r=/#/g;function xt(t,n){this.h=this.g=null,this.i=t||null,this.j=!!n}function lt(t){t.g||(t.g=new Map,t.h=0,t.i&&Br(t.i,function(n,r){t.add(decodeURIComponent(n.replace(/\+/g," ")),r)}))}e=xt.prototype,e.add=function(t,n){lt(this),this.i=null,t=St(this,t);let r=this.g.get(t);return r||this.g.set(t,r=[]),r.push(n),this.h+=1,this};function $n(t,n){lt(t),n=St(t,n),t.g.has(n)&&(t.i=null,t.h-=t.g.get(n).length,t.g.delete(n))}function Hn(t,n){return lt(t),n=St(t,n),t.g.has(n)}e.forEach=function(t,n){lt(this),this.g.forEach(function(r,o){r.forEach(function(m){t.call(n,m,o,this)},this)},this)};function Un(t,n){lt(t);let r=[];if(typeof n=="string")Hn(t,n)&&(r=r.concat(t.g.get(St(t,n))));else for(t=Array.from(t.g.values()),n=0;n<t.length;n++)r=r.concat(t[n]);return r}e.set=function(t,n){return lt(this),this.i=null,t=St(this,t),Hn(this,t)&&(this.h-=this.g.get(t).length),this.g.set(t,[n]),this.h+=1,this},e.get=function(t,n){return t?(t=Un(this,t),t.length>0?String(t[0]):n):n};function Vn(t,n,r){$n(t,n),r.length>0&&(t.i=null,t.g.set(St(t,n),W(r)),t.h+=r.length)}e.toString=function(){if(this.i)return this.i;if(!this.g)return"";const t=[],n=Array.from(this.g.keys());for(let o=0;o<n.length;o++){var r=n[o];const m=Mt(r);r=Un(this,r);for(let v=0;v<r.length;v++){let I=m;r[v]!==""&&(I+="="+Mt(r[v])),t.push(I)}}return this.i=t.join("&")};function zn(t){const n=new xt;return n.i=t.i,t.g&&(n.g=new Map(t.g),n.h=t.h),n}function St(t,n){return n=String(n),t.j&&(n=n.toLowerCase()),n}function Hr(t,n){n&&!t.j&&(lt(t),t.i=null,t.g.forEach(function(r,o){const m=o.toLowerCase();o!=m&&($n(this,o),Vn(this,m,r))},t)),t.j=n}function Ur(t,n){const r=new Rt;if(p.Image){const o=new Image;o.onload=_(Q,r,"TestLoadImage: loaded",!0,n,o),o.onerror=_(Q,r,"TestLoadImage: error",!1,n,o),o.onabort=_(Q,r,"TestLoadImage: abort",!1,n,o),o.ontimeout=_(Q,r,"TestLoadImage: timeout",!1,n,o),p.setTimeout(function(){o.ontimeout&&o.ontimeout()},1e4),o.src=t}else n(!1)}function Vr(t,n){const r=new Rt,o=new AbortController,m=setTimeout(()=>{o.abort(),Q(r,"TestPingServer: timeout",!1,n)},1e4);fetch(t,{signal:o.signal}).then(v=>{clearTimeout(m),v.ok?Q(r,"TestPingServer: ok",!0,n):Q(r,"TestPingServer: server error",!1,n)}).catch(()=>{clearTimeout(m),Q(r,"TestPingServer: error",!1,n)})}function Q(t,n,r,o,m){try{m&&(m.onload=null,m.onerror=null,m.onabort=null,m.ontimeout=null),o(r)}catch{}}function zr(){this.g=new _r}function Pe(t){this.i=t.Sb||null,this.h=t.ab||!1}A(Pe,bn),Pe.prototype.g=function(){return new Zt(this.i,this.h)};function Zt(t,n){B.call(this),this.H=t,this.o=n,this.m=void 0,this.status=this.readyState=0,this.responseType=this.responseText=this.response=this.statusText="",this.onreadystatechange=null,this.A=new Headers,this.h=null,this.F="GET",this.D="",this.g=!1,this.B=this.j=this.l=null,this.v=new AbortController}A(Zt,B),e=Zt.prototype,e.open=function(t,n){if(this.readyState!=0)throw this.abort(),Error("Error reopening a connection");this.F=t,this.D=n,this.readyState=1,Ft(this)},e.send=function(t){if(this.readyState!=1)throw this.abort(),Error("need to call open() first. ");if(this.v.signal.aborted)throw this.abort(),Error("Request was aborted.");this.g=!0;const n={headers:this.A,method:this.F,credentials:this.m,cache:void 0,signal:this.v.signal};t&&(n.body=t),(this.H||p).fetch(new Request(this.D,n)).then(this.Pa.bind(this),this.ga.bind(this))},e.abort=function(){this.response=this.responseText="",this.A=new Headers,this.status=0,this.v.abort(),this.j&&this.j.cancel("Request was aborted.").catch(()=>{}),this.readyState>=1&&this.g&&this.readyState!=4&&(this.g=!1,Lt(this)),this.readyState=0},e.Pa=function(t){if(this.g&&(this.l=t,this.h||(this.status=this.l.status,this.statusText=this.l.statusText,this.h=t.headers,this.readyState=2,Ft(this)),this.g&&(this.readyState=3,Ft(this),this.g)))if(this.responseType==="arraybuffer")t.arrayBuffer().then(this.Na.bind(this),this.ga.bind(this));else if(typeof p.ReadableStream<"u"&&"body"in t){if(this.j=t.body.getReader(),this.o){if(this.responseType)throw Error('responseType must be empty for "streamBinaryChunks" mode responses.');this.response=[]}else this.response=this.responseText="",this.B=new TextDecoder;Wn(this)}else t.text().then(this.Oa.bind(this),this.ga.bind(this))};function Wn(t){t.j.read().then(t.Ma.bind(t)).catch(t.ga.bind(t))}e.Ma=function(t){if(this.g){if(this.o&&t.value)this.response.push(t.value);else if(!this.o){var n=t.value?t.value:new Uint8Array(0);(n=this.B.decode(n,{stream:!t.done}))&&(this.response=this.responseText+=n)}t.done?Lt(this):Ft(this),this.readyState==3&&Wn(this)}},e.Oa=function(t){this.g&&(this.response=this.responseText=t,Lt(this))},e.Na=function(t){this.g&&(this.response=t,Lt(this))},e.ga=function(){this.g&&Lt(this)};function Lt(t){t.readyState=4,t.l=null,t.j=null,t.B=null,Ft(t)}e.setRequestHeader=function(t,n){this.A.append(t,n)},e.getResponseHeader=function(t){return this.h&&this.h.get(t.toLowerCase())||""},e.getAllResponseHeaders=function(){if(!this.h)return"";const t=[],n=this.h.entries();for(var r=n.next();!r.done;)r=r.value,t.push(r[0]+": "+r[1]),r=n.next();return t.join(`\r
`)};function Ft(t){t.onreadystatechange&&t.onreadystatechange.call(t)}Object.defineProperty(Zt.prototype,"withCredentials",{get:function(){return this.m==="include"},set:function(t){this.m=t?"include":"same-origin"}});function Gn(t){let n="";return Wt(t,function(r,o){n+=o,n+=":",n+=r,n+=`\r
`}),n}function ke(t,n,r){t:{for(o in r){var o=!1;break t}o=!0}o||(r=Gn(r),typeof t=="string"?r!=null&&Mt(r):D(t,n,r))}function M(t){B.call(this),this.headers=new Map,this.L=t||null,this.h=!1,this.g=null,this.D="",this.o=0,this.l="",this.j=this.B=this.v=this.A=!1,this.m=null,this.F="",this.H=!1}A(M,B);var Wr=/^https?$/i,Gr=["POST","PUT"];e=M.prototype,e.Fa=function(t){this.H=t},e.ea=function(t,n,r,o){if(this.g)throw Error("[goog.net.XhrIo] Object is active with another request="+this.D+"; newUri="+t);n=n?n.toUpperCase():"GET",this.D=t,this.l="",this.o=0,this.A=!1,this.h=!0,this.g=this.L?this.L.g():Cn.g(),this.g.onreadystatechange=R(E(this.Ca,this));try{this.B=!0,this.g.open(n,String(t),!0),this.B=!1}catch(v){Kn(this,v);return}if(t=r||"",r=new Map(this.headers),o)if(Object.getPrototypeOf(o)===Object.prototype)for(var m in o)r.set(m,o[m]);else if(typeof o.keys=="function"&&typeof o.get=="function")for(const v of o.keys())r.set(v,o.get(v));else throw Error("Unknown input type for opt_headers: "+String(o));o=Array.from(r.keys()).find(v=>v.toLowerCase()=="content-type"),m=p.FormData&&t instanceof p.FormData,!(Array.prototype.indexOf.call(Gr,n,void 0)>=0)||o||m||r.set("Content-Type","application/x-www-form-urlencoded;charset=utf-8");for(const[v,I]of r)this.g.setRequestHeader(v,I);this.F&&(this.g.responseType=this.F),"withCredentials"in this.g&&this.g.withCredentials!==this.H&&(this.g.withCredentials=this.H);try{this.m&&(clearTimeout(this.m),this.m=null),this.v=!0,this.g.send(t),this.v=!1}catch(v){Kn(this,v)}};function Kn(t,n){t.h=!1,t.g&&(t.j=!0,t.g.abort(),t.j=!1),t.l=n,t.o=5,qn(t),Qt(t)}function qn(t){t.A||(t.A=!0,N(t,"complete"),N(t,"error"))}e.abort=function(t){this.g&&this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1,this.o=t||7,N(this,"complete"),N(this,"abort"),Qt(this))},e.N=function(){this.g&&(this.h&&(this.h=!1,this.j=!0,this.g.abort(),this.j=!1),Qt(this,!0)),M.Z.N.call(this)},e.Ca=function(){this.u||(this.B||this.v||this.j?Xn(this):this.Xa())},e.Xa=function(){Xn(this)};function Xn(t){if(t.h&&typeof y<"u"){if(t.v&&tt(t)==4)setTimeout(t.Ca.bind(t),0);else if(N(t,"readystatechange"),tt(t)==4){t.h=!1;try{const v=t.ca();t:switch(v){case 200:case 201:case 202:case 204:case 206:case 304:case 1223:var n=!0;break t;default:n=!1}var r;if(!(r=n)){var o;if(o=v===0){let I=String(t.D).match(Ln)[1]||null;!I&&p.self&&p.self.location&&(I=p.self.location.protocol.slice(0,-1)),o=!Wr.test(I?I.toLowerCase():"")}r=o}if(r)N(t,"complete"),N(t,"success");else{t.o=6;try{var m=tt(t)>2?t.g.statusText:""}catch{m=""}t.l=m+" ["+t.ca()+"]",qn(t)}}finally{Qt(t)}}}}function Qt(t,n){if(t.g){t.m&&(clearTimeout(t.m),t.m=null);const r=t.g;t.g=null,n||N(t,"ready");try{r.onreadystatechange=null}catch{}}}e.isActive=function(){return!!this.g};function tt(t){return t.g?t.g.readyState:0}e.ca=function(){try{return tt(this)>2?this.g.status:-1}catch{return-1}},e.la=function(){try{return this.g?this.g.responseText:""}catch{return""}},e.La=function(t){if(this.g){var n=this.g.responseText;return t&&n.indexOf(t)==0&&(n=n.substring(t.length)),Tr(n)}};function Jn(t){try{if(!t.g)return null;if("response"in t.g)return t.g.response;switch(t.F){case"":case"text":return t.g.responseText;case"arraybuffer":if("mozResponseArrayBuffer"in t.g)return t.g.mozResponseArrayBuffer}return null}catch{return null}}function Kr(t){const n={};t=(t.g&&tt(t)>=2&&t.g.getAllResponseHeaders()||"").split(`\r
`);for(let o=0;o<t.length;o++){if(l(t[o]))continue;var r=Mr(t[o]);const m=r[0];if(r=r[1],typeof r!="string")continue;r=r.trim();const v=n[m]||[];n[m]=v,v.push(r)}vr(n,function(o){return o.join(", ")})}e.ya=function(){return this.o},e.Ha=function(){return typeof this.l=="string"?this.l:String(this.l)};function $t(t,n,r){return r&&r.internalChannelParams&&r.internalChannelParams[t]||n}function Yn(t){this.za=0,this.i=[],this.j=new Rt,this.ba=this.na=this.J=this.W=this.g=this.wa=this.G=this.H=this.u=this.U=this.o=null,this.Ya=this.V=0,this.Sa=$t("failFast",!1,t),this.F=this.C=this.v=this.m=this.l=null,this.X=!0,this.xa=this.K=-1,this.Y=this.A=this.D=0,this.Qa=$t("baseRetryDelayMs",5e3,t),this.Za=$t("retryDelaySeedMs",1e4,t),this.Ta=$t("forwardChannelMaxRetries",2,t),this.va=$t("forwardChannelRequestTimeoutMs",2e4,t),this.ma=t&&t.xmlHttpFactory||void 0,this.Ua=t&&t.Rb||void 0,this.Aa=t&&t.useFetchStreams||!1,this.O=void 0,this.L=t&&t.supportsCrossDomainXhr||!1,this.M="",this.h=new kn(t&&t.concurrentRequestLimit),this.Ba=new zr,this.S=t&&t.fastHandshake||!1,this.R=t&&t.encodeInitMessageHeaders||!1,this.S&&this.R&&(this.R=!1),this.Ra=t&&t.Pb||!1,t&&t.ua&&this.j.ua(),t&&t.forceLongPolling&&(this.X=!1),this.aa=!this.S&&this.X&&t&&t.detectBufferingProxy||!1,this.ia=void 0,t&&t.longPollingTimeout&&t.longPollingTimeout>0&&(this.ia=t.longPollingTimeout),this.ta=void 0,this.T=0,this.P=!1,this.ja=this.B=null}e=Yn.prototype,e.ka=8,e.I=1,e.connect=function(t,n,r,o){x(0),this.W=t,this.H=n||{},r&&o!==void 0&&(this.H.OSID=r,this.H.OAID=o),this.F=this.X,this.J=oi(this,null,this.W),ee(this)};function je(t){if(Zn(t),t.I==3){var n=t.V++,r=G(t.J);if(D(r,"SID",t.M),D(r,"RID",n),D(r,"TYPE","terminate"),Ht(t,r),n=new Y(t,t.j,n),n.M=2,n.A=Yt(G(r)),r=!1,p.navigator&&p.navigator.sendBeacon)try{r=p.navigator.sendBeacon(n.A.toString(),"")}catch{}!r&&p.Image&&(new Image().src=n.A,r=!0),r||(n.g=ai(n.j,null),n.g.ea(n.A)),n.F=Date.now(),Jt(n)}si(t)}function te(t){t.g&&(Ne(t),t.g.cancel(),t.g=null)}function Zn(t){te(t),t.v&&(p.clearTimeout(t.v),t.v=null),ne(t),t.h.cancel(),t.m&&(typeof t.m=="number"&&p.clearTimeout(t.m),t.m=null)}function ee(t){if(!jn(t.h)&&!t.m){t.m=!0;var n=t.Ea;J||c(),z||(J(),z=!0),g.add(n,t),t.D=0}}function qr(t,n){return Bn(t.h)>=t.h.j-(t.m?1:0)?!1:t.m?(t.i=n.G.concat(t.i),!0):t.I==1||t.I==2||t.D>=(t.Sa?0:t.Ta)?!1:(t.m=Ot(E(t.Ea,t,n),ri(t,t.D)),t.D++,!0)}e.Ea=function(t){if(this.m)if(this.m=null,this.I==1){if(!t){this.V=Math.floor(Math.random()*1e5),t=this.V++;const m=new Y(this,this.j,t);let v=this.o;if(this.U&&(v?(v=ln(v),fn(v,this.U)):v=this.U),this.u!==null||this.R||(m.J=v,v=null),this.S)t:{for(var n=0,r=0;r<this.i.length;r++){e:{var o=this.i[r];if("__data__"in o.map&&(o=o.map.__data__,typeof o=="string")){o=o.length;break e}o=void 0}if(o===void 0)break;if(n+=o,n>4096){n=r;break t}if(n===4096||r===this.i.length-1){n=r+1;break t}}n=1e3}else n=1e3;n=ti(this,m,n),r=G(this.J),D(r,"RID",t),D(r,"CVER",22),this.G&&D(r,"X-HTTP-Session-Id",this.G),Ht(this,r),v&&(this.R?n="headers="+Mt(Gn(v))+"&"+n:this.u&&ke(r,this.u,v)),Re(this.h,m),this.Ra&&D(r,"TYPE","init"),this.S?(D(r,"$req",n),D(r,"SID","null"),m.U=!0,_e(m,r,null)):_e(m,r,n),this.I=2}}else this.I==3&&(t?Qn(this,t):this.i.length==0||jn(this.h)||Qn(this))};function Qn(t,n){var r;n?r=n.l:r=t.V++;const o=G(t.J);D(o,"SID",t.M),D(o,"RID",r),D(o,"AID",t.K),Ht(t,o),t.u&&t.o&&ke(o,t.u,t.o),r=new Y(t,t.j,r,t.D+1),t.u===null&&(r.J=t.o),n&&(t.i=n.G.concat(t.i)),n=ti(t,r,1e3),r.H=Math.round(t.va*.5)+Math.round(t.va*.5*Math.random()),Re(t.h,r),_e(r,o,n)}function Ht(t,n){t.H&&Wt(t.H,function(r,o){D(n,o,r)}),t.l&&Wt({},function(r,o){D(n,o,r)})}function ti(t,n,r){r=Math.min(t.i.length,r);const o=t.l?E(t.l.Ka,t.l,t):null;t:{var m=t.i;let T=-1;for(;;){const k=["count="+r];T==-1?r>0?(T=m[0].g,k.push("ofs="+T)):T=0:k.push("ofs="+T);let C=!0;for(let j=0;j<r;j++){var v=m[j].g;const K=m[j].map;if(v-=T,v<0)T=Math.max(0,m[j].g-100),C=!1;else try{v="req"+v+"_"||"";try{var I=K instanceof Map?K:Object.entries(K);for(const[ft,et]of I){let nt=et;b(et)&&(nt=Ie(et)),k.push(v+ft+"="+encodeURIComponent(nt))}}catch(ft){throw k.push(v+"type="+encodeURIComponent("_badmap")),ft}}catch{o&&o(K)}}if(C){I=k.join("&");break t}}I=void 0}return t=t.i.splice(0,r),n.G=t,I}function ei(t){if(!t.g&&!t.v){t.Y=1;var n=t.Da;J||c(),z||(J(),z=!0),g.add(n,t),t.A=0}}function Be(t){return t.g||t.v||t.A>=3?!1:(t.Y++,t.v=Ot(E(t.Da,t),ri(t,t.A)),t.A++,!0)}e.Da=function(){if(this.v=null,ni(this),this.aa&&!(this.P||this.g==null||this.T<=0)){var t=4*this.T;this.j.info("BP detection timer enabled: "+t),this.B=Ot(E(this.Wa,this),t)}},e.Wa=function(){this.B&&(this.B=null,this.j.info("BP detection timeout reached."),this.j.info("Buffering proxy detected and switch to long-polling!"),this.F=!1,this.P=!0,x(10),te(this),ni(this))};function Ne(t){t.B!=null&&(p.clearTimeout(t.B),t.B=null)}function ni(t){t.g=new Y(t,t.j,"rpc",t.Y),t.u===null&&(t.g.J=t.o),t.g.P=0;var n=G(t.na);D(n,"RID","rpc"),D(n,"SID",t.M),D(n,"AID",t.K),D(n,"CI",t.F?"0":"1"),!t.F&&t.ia&&D(n,"TO",t.ia),D(n,"TYPE","xmlhttp"),Ht(t,n),t.u&&t.o&&ke(n,t.u,t.o),t.O&&(t.g.H=t.O);var r=t.g;t=t.ba,r.M=1,r.A=Yt(G(n)),r.u=null,r.R=!0,Rn(r,t)}e.Va=function(){this.C!=null&&(this.C=null,te(this),Be(this),x(19))};function ne(t){t.C!=null&&(p.clearTimeout(t.C),t.C=null)}function ii(t,n){var r=null;if(t.g==n){ne(t),Ne(t),t.g=null;var o=2}else if(Oe(t.h,n))r=n.G,Nn(t.h,n),o=1;else return;if(t.I!=0){if(n.o)if(o==1){r=n.u?n.u.length:0,n=Date.now()-n.F;var m=t.D;o=qt(),N(o,new Tn(o,r)),ee(t)}else ei(t);else if(m=n.m,m==3||m==0&&n.X>0||!(o==1&&qr(t,n)||o==2&&Be(t)))switch(r&&r.length>0&&(n=t.h,n.i=n.i.concat(r)),m){case 1:ut(t,5);break;case 4:ut(t,10);break;case 3:ut(t,6);break;default:ut(t,2)}}}function ri(t,n){let r=t.Qa+Math.floor(Math.random()*t.Za);return t.isActive()||(r*=2),r*n}function ut(t,n){if(t.j.info("Error code "+n),n==2){var r=E(t.bb,t),o=t.Ua;const m=!o;o=new Z(o||"//www.google.com/images/cleardot.gif"),p.location&&p.location.protocol=="http"||kt(o,"https"),Yt(o),m?Ur(o.toString(),r):Vr(o.toString(),r)}else x(2);t.I=0,t.l&&t.l.pa(n),si(t),Zn(t)}e.bb=function(t){t?(this.j.info("Successfully pinged google.com"),x(2)):(this.j.info("Failed to ping google.com"),x(1))};function si(t){if(t.I=0,t.ja=[],t.l){const n=xn(t.h);(n.length!=0||t.i.length!=0)&&(F(t.ja,n),F(t.ja,t.i),t.h.i.length=0,W(t.i),t.i.length=0),t.l.oa()}}function oi(t,n,r){var o=r instanceof Z?G(r):new Z(r);if(o.g!="")n&&(o.g=n+"."+o.g),jt(o,o.u);else{var m=p.location;o=m.protocol,n=n?n+"."+m.hostname:m.hostname,m=+m.port;const v=new Z(null);o&&kt(v,o),n&&(v.g=n),m&&jt(v,m),r&&(v.h=r),o=v}return r=t.G,n=t.wa,r&&n&&D(o,r,n),D(o,"VER",t.ka),Ht(t,o),o}function ai(t,n,r){if(n&&!t.L)throw Error("Can't create secondary domain capable XhrIo object.");return n=t.Aa&&!t.ma?new M(new Pe({ab:r})):new M(t.ma),n.Fa(t.L),n}e.isActive=function(){return!!this.l&&this.l.isActive(this)};function hi(){}e=hi.prototype,e.ra=function(){},e.qa=function(){},e.pa=function(){},e.oa=function(){},e.isActive=function(){return!0},e.Ka=function(){};function ie(){}ie.prototype.g=function(t,n){return new U(t,n)};function U(t,n){B.call(this),this.g=new Yn(n),this.l=t,this.h=n&&n.messageUrlParams||null,t=n&&n.messageHeaders||null,n&&n.clientProtocolHeaderRequired&&(t?t["X-Client-Protocol"]="webchannel":t={"X-Client-Protocol":"webchannel"}),this.g.o=t,t=n&&n.initMessageHeaders||null,n&&n.messageContentType&&(t?t["X-WebChannel-Content-Type"]=n.messageContentType:t={"X-WebChannel-Content-Type":n.messageContentType}),n&&n.sa&&(t?t["X-WebChannel-Client-Profile"]=n.sa:t={"X-WebChannel-Client-Profile":n.sa}),this.g.U=t,(t=n&&n.Qb)&&!l(t)&&(this.g.u=t),this.A=n&&n.supportsCrossDomainXhr||!1,this.v=n&&n.sendRawJson||!1,(n=n&&n.httpSessionIdParam)&&!l(n)&&(this.g.G=n,t=this.h,t!==null&&n in t&&(t=this.h,n in t&&delete t[n])),this.j=new At(this)}A(U,B),U.prototype.m=function(){this.g.l=this.j,this.A&&(this.g.L=!0),this.g.connect(this.l,this.h||void 0)},U.prototype.close=function(){je(this.g)},U.prototype.o=function(t){var n=this.g;if(typeof t=="string"){var r={};r.__data__=t,t=r}else this.v&&(r={},r.__data__=Ie(t),t=r);n.i.push(new jr(n.Ya++,t)),n.I==3&&ee(n)},U.prototype.N=function(){this.g.l=null,delete this.j,je(this.g),delete this.g,U.Z.N.call(this)};function ci(t){Ee.call(this),t.__headers__&&(this.headers=t.__headers__,this.statusCode=t.__status__,delete t.__headers__,delete t.__status__);var n=t.__sm__;if(n){t:{for(const r in n){t=r;break t}t=void 0}(this.i=t)&&(t=this.i,n=n!==null&&t in n?n[t]:void 0),this.data=n}else this.data=t}A(ci,Ee);function li(){Se.call(this),this.status=1}A(li,Se);function At(t){this.g=t}A(At,hi),At.prototype.ra=function(){N(this.g,"a")},At.prototype.qa=function(t){N(this.g,new ci(t))},At.prototype.pa=function(t){N(this.g,new li)},At.prototype.oa=function(){N(this.g,"b")},ie.prototype.createWebChannel=ie.prototype.g,U.prototype.send=U.prototype.o,U.prototype.open=U.prototype.m,U.prototype.close=U.prototype.close,nh=function(){return new ie},eh=function(){return qt()},th=ht,Qa={jb:0,mb:1,nb:2,Hb:3,Mb:4,Jb:5,Kb:6,Ib:7,Gb:8,Lb:9,PROXY:10,NOPROXY:11,Eb:12,Ab:13,Bb:14,zb:15,Cb:16,Db:17,fb:18,eb:19,gb:20},Xt.NO_ERROR=0,Xt.TIMEOUT=8,Xt.HTTP_ERROR=6,Za=Xt,_n.COMPLETE="complete",Ya=_n,In.EventType=Ct,Ct.OPEN="a",Ct.CLOSE="b",Ct.ERROR="c",Ct.MESSAGE="d",B.prototype.listen=B.prototype.J,Ja=In,M.prototype.listenOnce=M.prototype.K,M.prototype.getLastError=M.prototype.Ha,M.prototype.getLastErrorCode=M.prototype.ya,M.prototype.getStatus=M.prototype.ca,M.prototype.getResponseJson=M.prototype.La,M.prototype.getResponseText=M.prototype.la,M.prototype.send=M.prototype.ea,M.prototype.setWithCredentials=M.prototype.Fa,Xa=M}).apply(typeof se<"u"?se:typeof self<"u"?self:typeof window<"u"?window:{});export{st as $,po as A,ph as B,ot as C,as as D,Za as E,wt as F,Sh as G,mh as H,Ka as I,Qe as J,oh as K,O as L,qa as M,hh as N,ah as O,ch as P,lh as Q,Wa as R,_h as S,fh as T,fi as U,yh as V,Ja as W,Xa as X,Ah as Y,wh as Z,ue as _,th as a,dh as a0,Eh as a1,Ih as a2,uh as a3,Ya as b,Hi as c,vh as d,Qa as e,Th as f,dt as g,Jr as h,Yr as i,ji as j,ts as k,gh as l,sh as m,nh as n,ih as o,ae as p,bh as q,za as r,go as s,Ch as t,rh as u,ns as v,en as w,eh as x,hs as y,Dh as z};
