import{b as t,r as s,j as i}from"./vendor-react-LLKFCwzd.js";function a({data:r}){const n=t.useMemo(()=>(Array.isArray(r)?r:[r]).filter(Boolean).map(e=>JSON.stringify(e)).join(`
`),[r]),o=i.jsx("script",{type:"application/ld+json",dangerouslySetInnerHTML:{__html:n}});return typeof document<"u"?s.createPortal(o,document.head):null}export{a as J};
