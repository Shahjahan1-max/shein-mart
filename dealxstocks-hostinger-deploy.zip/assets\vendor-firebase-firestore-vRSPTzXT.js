import{_ as oo,p as ao,G as ss,Y as uo,s as mu,u as _u,F as gu,m as pu,c as yu,L as ye,x as Iu,a as Tu,X as Eu,b as Au,E as Tr,W as Tn,n as wu,P as co,y as Fn,v as Ru,J as vu,Q as lo,I as qe,M as Vu,e as zs,f as Su,w as Pu,g as bu,C as xu,$ as Ks,S as Du}from"./vendor-firebase-core-DTLDwBTR.js";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class J{constructor(e){this.uid=e}isAuthenticated(){return this.uid!=null}toKey(){return this.isAuthenticated()?"uid:"+this.uid:"anonymous-user"}isEqual(e){return e.uid===this.uid}}J.UNAUTHENTICATED=new J(null),J.GOOGLE_CREDENTIALS=new J("google-credentials-uid"),J.FIRST_PARTY=new J("first-party-uid"),J.MOCK_USER=new J("mock-user");/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let bt="12.13.0";function Cu(s){bt=s}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Qe=new yu("@firebase/firestore");function at(){return Qe.logLevel}function g(s,...e){if(Qe.logLevel<=ye.DEBUG){const t=e.map(is);Qe.debug(`Firestore (${bt}): ${s}`,...t)}}function H(s,...e){if(Qe.logLevel<=ye.ERROR){const t=e.map(is);Qe.error(`Firestore (${bt}): ${s}`,...t)}}function _t(s,...e){if(Qe.logLevel<=ye.WARN){const t=e.map(is);Qe.warn(`Firestore (${bt}): ${s}`,...t)}}function is(s){if(typeof s=="string")return s;try{return(function(t){return JSON.stringify(t)})(s)}catch{return s}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function I(s,e,t){let n="Unexpected state";typeof e=="string"?n=e:t=e,ho(s,n,t)}function ho(s,e,t){let n=`FIRESTORE (${bt}) INTERNAL ASSERTION FAILED: ${e} (ID: ${s.toString(16)})`;if(t!==void 0)try{n+=" CONTEXT: "+JSON.stringify(t)}catch{n+=" CONTEXT: "+t}throw H(n),new Error(n)}function T(s,e,t,n){let r="Unexpected state";typeof t=="string"?r=t:n=t,s||ho(e,r,n)}function E(s,e){return s}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const m={OK:"ok",CANCELLED:"cancelled",UNKNOWN:"unknown",INVALID_ARGUMENT:"invalid-argument",DEADLINE_EXCEEDED:"deadline-exceeded",NOT_FOUND:"not-found",ALREADY_EXISTS:"already-exists",PERMISSION_DENIED:"permission-denied",UNAUTHENTICATED:"unauthenticated",RESOURCE_EXHAUSTED:"resource-exhausted",FAILED_PRECONDITION:"failed-precondition",ABORTED:"aborted",OUT_OF_RANGE:"out-of-range",UNIMPLEMENTED:"unimplemented",INTERNAL:"internal",UNAVAILABLE:"unavailable",DATA_LOSS:"data-loss"};class y extends gu{constructor(e,t){super(e,t),this.code=e,this.message=t,this.toString=()=>`${this.name}: [code=${this.code}]: ${this.message}`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ht{constructor(){this.promise=new Promise(((e,t)=>{this.resolve=e,this.reject=t}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fo{constructor(e,t){this.user=t,this.type="OAuth",this.headers=new Map,this.headers.set("Authorization",`Bearer ${e}`)}}class Nu{getToken(){return Promise.resolve(null)}invalidateToken(){}start(e,t){e.enqueueRetryable((()=>t(J.UNAUTHENTICATED)))}shutdown(){}}class ku{constructor(e){this.token=e,this.changeListener=null}getToken(){return Promise.resolve(this.token)}invalidateToken(){}start(e,t){this.changeListener=t,e.enqueueRetryable((()=>t(this.token.user)))}shutdown(){this.changeListener=null}}class Mu{constructor(e){this.t=e,this.currentUser=J.UNAUTHENTICATED,this.i=0,this.forceRefresh=!1,this.auth=null}start(e,t){T(this.o===void 0,42304);let n=this.i;const r=u=>this.i!==n?(n=this.i,t(u)):Promise.resolve();let i=new ht;this.o=()=>{this.i++,this.currentUser=this.u(),i.resolve(),i=new ht,e.enqueueRetryable((()=>r(this.currentUser)))};const o=()=>{const u=i;e.enqueueRetryable((async()=>{await u.promise,await r(this.currentUser)}))},a=u=>{g("FirebaseAuthCredentialsProvider","Auth detected"),this.auth=u,this.o&&(this.auth.addAuthTokenListener(this.o),o())};this.t.onInit((u=>a(u))),setTimeout((()=>{if(!this.auth){const u=this.t.getImmediate({optional:!0});u?a(u):(g("FirebaseAuthCredentialsProvider","Auth not yet detected"),i.resolve(),i=new ht)}}),0),o()}getToken(){const e=this.i,t=this.forceRefresh;return this.forceRefresh=!1,this.auth?this.auth.getToken(t).then((n=>this.i!==e?(g("FirebaseAuthCredentialsProvider","getToken aborted due to token change."),this.getToken()):n?(T(typeof n.accessToken=="string",31837,{l:n}),new fo(n.accessToken,this.currentUser)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.auth&&this.o&&this.auth.removeAuthTokenListener(this.o),this.o=void 0}u(){const e=this.auth&&this.auth.getUid();return T(e===null||typeof e=="string",2055,{h:e}),new J(e)}}class Ou{constructor(e,t,n){this.P=e,this.T=t,this.I=n,this.type="FirstParty",this.user=J.FIRST_PARTY,this.R=new Map}A(){return this.I?this.I():null}get headers(){this.R.set("X-Goog-AuthUser",this.P);const e=this.A();return e&&this.R.set("Authorization",e),this.T&&this.R.set("X-Goog-Iam-Authorization-Token",this.T),this.R}}class Fu{constructor(e,t,n){this.P=e,this.T=t,this.I=n}getToken(){return Promise.resolve(new Ou(this.P,this.T,this.I))}start(e,t){e.enqueueRetryable((()=>t(J.FIRST_PARTY)))}shutdown(){}invalidateToken(){}}class Gs{constructor(e){this.value=e,this.type="AppCheck",this.headers=new Map,e&&e.length>0&&this.headers.set("x-firebase-appcheck",this.value)}}class Lu{constructor(e,t){this.V=t,this.forceRefresh=!1,this.appCheck=null,this.m=null,this.p=null,Su(e)&&e.settings.appCheckToken&&(this.p=e.settings.appCheckToken)}start(e,t){T(this.o===void 0,3512);const n=i=>{i.error!=null&&g("FirebaseAppCheckTokenProvider",`Error getting App Check token; using placeholder token instead. Error: ${i.error.message}`);const o=i.token!==this.m;return this.m=i.token,g("FirebaseAppCheckTokenProvider",`Received ${o?"new":"existing"} token.`),o?t(i.token):Promise.resolve()};this.o=i=>{e.enqueueRetryable((()=>n(i)))};const r=i=>{g("FirebaseAppCheckTokenProvider","AppCheck detected"),this.appCheck=i,this.o&&this.appCheck.addTokenListener(this.o)};this.V.onInit((i=>r(i))),setTimeout((()=>{if(!this.appCheck){const i=this.V.getImmediate({optional:!0});i?r(i):g("FirebaseAppCheckTokenProvider","AppCheck not yet detected")}}),0)}getToken(){if(this.p)return Promise.resolve(new Gs(this.p));const e=this.forceRefresh;return this.forceRefresh=!1,this.appCheck?this.appCheck.getToken(e).then((t=>t?(T(typeof t.token=="string",44558,{tokenResult:t}),this.m=t.token,new Gs(t.token)):null)):Promise.resolve(null)}invalidateToken(){this.forceRefresh=!0}shutdown(){this.appCheck&&this.o&&this.appCheck.removeTokenListener(this.o),this.o=void 0}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Bu(s){const e=typeof self<"u"&&(self.crypto||self.msCrypto),t=new Uint8Array(s);if(e&&typeof e.getRandomValues=="function")e.getRandomValues(t);else for(let n=0;n<s;n++)t[n]=Math.floor(256*Math.random());return t}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Uu{static newId(){const e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",t=62*Math.floor(4.129032258064516);let n="";for(;n.length<20;){const r=Bu(40);for(let i=0;i<r.length;++i)n.length<20&&r[i]<t&&(n+=e.charAt(r[i]%62))}return n}}function V(s,e){return s<e?-1:s>e?1:0}function xr(s,e){const t=Math.min(s.length,e.length);for(let n=0;n<t;n++){const r=s.charAt(n),i=e.charAt(n);if(r!==i)return Er(r)===Er(i)?V(r,i):Er(r)?1:-1}return V(s.length,e.length)}const qu=55296,zu=57343;function Er(s){const e=s.charCodeAt(0);return e>=qu&&e<=zu}function gt(s,e,t){return s.length===e.length&&s.every(((n,r)=>t(n,e[r])))}function mo(s){return s+"\0"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $s="__name__";class he{constructor(e,t,n){t===void 0?t=0:t>e.length&&I(637,{offset:t,range:e.length}),n===void 0?n=e.length-t:n>e.length-t&&I(1746,{length:n,range:e.length-t}),this.segments=e,this.offset=t,this.len=n}get length(){return this.len}isEqual(e){return he.comparator(this,e)===0}child(e){const t=this.segments.slice(this.offset,this.limit());return e instanceof he?e.forEach((n=>{t.push(n)})):t.push(e),this.construct(t)}limit(){return this.offset+this.length}popFirst(e){return e=e===void 0?1:e,this.construct(this.segments,this.offset+e,this.length-e)}popLast(){return this.construct(this.segments,this.offset,this.length-1)}firstSegment(){return this.segments[this.offset]}lastSegment(){return this.get(this.length-1)}get(e){return this.segments[this.offset+e]}isEmpty(){return this.length===0}isPrefixOf(e){if(e.length<this.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}isImmediateParentOf(e){if(this.length+1!==e.length)return!1;for(let t=0;t<this.length;t++)if(this.get(t)!==e.get(t))return!1;return!0}forEach(e){for(let t=this.offset,n=this.limit();t<n;t++)e(this.segments[t])}toArray(){return this.segments.slice(this.offset,this.limit())}static comparator(e,t){const n=Math.min(e.length,t.length);for(let r=0;r<n;r++){const i=he.compareSegments(e.get(r),t.get(r));if(i!==0)return i}return V(e.length,t.length)}static compareSegments(e,t){const n=he.isNumericId(e),r=he.isNumericId(t);return n&&!r?-1:!n&&r?1:n&&r?he.extractNumericId(e).compare(he.extractNumericId(t)):xr(e,t)}static isNumericId(e){return e.startsWith("__id")&&e.endsWith("__")}static extractNumericId(e){return qe.fromString(e.substring(4,e.length-2))}}class M extends he{construct(e,t,n){return new M(e,t,n)}canonicalString(){return this.toArray().join("/")}toString(){return this.canonicalString()}toUriEncodedString(){return this.toArray().map(encodeURIComponent).join("/")}static fromString(...e){const t=[];for(const n of e){if(n.indexOf("//")>=0)throw new y(m.INVALID_ARGUMENT,`Invalid segment (${n}). Paths must not contain // in them.`);t.push(...n.split("/").filter((r=>r.length>0)))}return new M(t)}static emptyPath(){return new M([])}}const Ku=/^[_a-zA-Z][_a-zA-Z0-9]*$/;class B extends he{construct(e,t,n){return new B(e,t,n)}static isValidIdentifier(e){return Ku.test(e)}canonicalString(){return this.toArray().map((e=>(e=e.replace(/\\/g,"\\\\").replace(/`/g,"\\`"),B.isValidIdentifier(e)||(e="`"+e+"`"),e))).join(".")}toString(){return this.canonicalString()}isKeyField(){return this.length===1&&this.get(0)===$s}static keyField(){return new B([$s])}static fromServerFormat(e){const t=[];let n="",r=0;const i=()=>{if(n.length===0)throw new y(m.INVALID_ARGUMENT,`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`);t.push(n),n=""};let o=!1;for(;r<e.length;){const a=e[r];if(a==="\\"){if(r+1===e.length)throw new y(m.INVALID_ARGUMENT,"Path has trailing escape character: "+e);const u=e[r+1];if(u!=="\\"&&u!=="."&&u!=="`")throw new y(m.INVALID_ARGUMENT,"Path has invalid escape sequence: "+e);n+=u,r+=2}else a==="`"?(o=!o,r++):a!=="."||o?(n+=a,r++):(i(),r++)}if(i(),o)throw new y(m.INVALID_ARGUMENT,"Unterminated ` in path: "+e);return new B(t)}static emptyPath(){return new B([])}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class p{constructor(e){this.path=e}static fromPath(e){return new p(M.fromString(e))}static fromName(e){return new p(M.fromString(e).popFirst(5))}static empty(){return new p(M.emptyPath())}get collectionGroup(){return this.path.popLast().lastSegment()}hasCollectionId(e){return this.path.length>=2&&this.path.get(this.path.length-2)===e}getCollectionGroup(){return this.path.get(this.path.length-2)}getCollectionPath(){return this.path.popLast()}isEqual(e){return e!==null&&M.comparator(this.path,e.path)===0}toString(){return this.path.toString()}static comparator(e,t){return M.comparator(e.path,t.path)}static isDocumentKey(e){return e.length%2==0}static fromSegments(e){return new p(new M(e.slice()))}}function Gu(s,e,t,n){if(e===!0&&n===!0)throw new y(m.INVALID_ARGUMENT,`${s} and ${t} cannot be used together.`)}function $u(s){return typeof s=="object"&&s!==null&&(Object.getPrototypeOf(s)===Object.prototype||Object.getPrototypeOf(s)===null)}function ju(s){if(s===void 0)return"undefined";if(s===null)return"null";if(typeof s=="string")return s.length>20&&(s=`${s.substring(0,20)}...`),JSON.stringify(s);if(typeof s=="number"||typeof s=="boolean")return""+s;if(typeof s=="object"){if(s instanceof Array)return"an array";{const e=(function(n){return n.constructor?n.constructor.name:null})(s);return e?`a custom ${e} object`:"an object"}}return typeof s=="function"?"a function":I(12329,{type:typeof s})}function Qu(s,e){if("_delegate"in s&&(s=s._delegate),!(s instanceof e)){if(e.name===s.constructor.name)throw new y(m.INVALID_ARGUMENT,"Type does not match the expected instance. Did you pass a reference from a different Firestore SDK?");{const t=ju(s);throw new y(m.INVALID_ARGUMENT,`Expected type '${e.name}', but it was: ${t}`)}}return s}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $(s,e){const t={typeString:s};return e&&(t.value=e),t}function fn(s,e){if(!$u(s))throw new y(m.INVALID_ARGUMENT,"JSON must be an object");let t;for(const n in e)if(e[n]){const r=e[n].typeString,i="value"in e[n]?{value:e[n].value}:void 0;if(!(n in s)){t=`JSON missing required field: '${n}'`;break}const o=s[n];if(r&&typeof o!==r){t=`JSON field '${n}' must be a ${r}.`;break}if(i!==void 0&&o!==i.value){t=`Expected '${n}' field to equal '${i.value}'`;break}}if(t)throw new y(m.INVALID_ARGUMENT,t);return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const js=-62135596800,Qs=1e6;class O{static now(){return O.fromMillis(Date.now())}static fromDate(e){return O.fromMillis(e.getTime())}static fromMillis(e){const t=Math.floor(e/1e3),n=Math.floor((e-1e3*t)*Qs);return new O(t,n)}constructor(e,t){if(this.seconds=e,this.nanoseconds=t,t<0)throw new y(m.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(t>=1e9)throw new y(m.INVALID_ARGUMENT,"Timestamp nanoseconds out of range: "+t);if(e<js)throw new y(m.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e);if(e>=253402300800)throw new y(m.INVALID_ARGUMENT,"Timestamp seconds out of range: "+e)}toDate(){return new Date(this.toMillis())}toMillis(){return 1e3*this.seconds+this.nanoseconds/Qs}_compareTo(e){return this.seconds===e.seconds?V(this.nanoseconds,e.nanoseconds):V(this.seconds,e.seconds)}isEqual(e){return e.seconds===this.seconds&&e.nanoseconds===this.nanoseconds}toString(){return"Timestamp(seconds="+this.seconds+", nanoseconds="+this.nanoseconds+")"}toJSON(){return{type:O._jsonSchemaVersion,seconds:this.seconds,nanoseconds:this.nanoseconds}}static fromJSON(e){if(fn(e,O._jsonSchema))return new O(e.seconds,e.nanoseconds)}valueOf(){const e=this.seconds-js;return String(e).padStart(12,"0")+"."+String(this.nanoseconds).padStart(9,"0")}}O._jsonSchemaVersion="firestore/timestamp/1.0",O._jsonSchema={type:$("string",O._jsonSchemaVersion),seconds:$("number"),nanoseconds:$("number")};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class A{static fromTimestamp(e){return new A(e)}static min(){return new A(new O(0,0))}static max(){return new A(new O(253402300799,999999999))}constructor(e){this.timestamp=e}compareTo(e){return this.timestamp._compareTo(e.timestamp)}isEqual(e){return this.timestamp.isEqual(e.timestamp)}toMicroseconds(){return 1e6*this.timestamp.seconds+this.timestamp.nanoseconds/1e3}toString(){return"SnapshotVersion("+this.timestamp.toString()+")"}toTimestamp(){return this.timestamp}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const pt=-1;class Ln{constructor(e,t,n,r){this.indexId=e,this.collectionGroup=t,this.fields=n,this.indexState=r}}function Dr(s){return s.fields.find((e=>e.kind===2))}function ke(s){return s.fields.filter((e=>e.kind!==2))}Ln.UNKNOWN_ID=-1;class Pn{constructor(e,t){this.fieldPath=e,this.kind=t}}class nn{constructor(e,t){this.sequenceNumber=e,this.offset=t}static empty(){return new nn(0,ie.min())}}function _o(s,e){const t=s.toTimestamp().seconds,n=s.toTimestamp().nanoseconds+1,r=A.fromTimestamp(n===1e9?new O(t+1,0):new O(t,n));return new ie(r,p.empty(),e)}function go(s){return new ie(s.readTime,s.key,pt)}class ie{constructor(e,t,n){this.readTime=e,this.documentKey=t,this.largestBatchId=n}static min(){return new ie(A.min(),p.empty(),pt)}static max(){return new ie(A.max(),p.empty(),pt)}}function os(s,e){let t=s.readTime.compareTo(e.readTime);return t!==0?t:(t=p.comparator(s.documentKey,e.documentKey),t!==0?t:V(s.largestBatchId,e.largestBatchId))}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const po="The current tab is not in the required state to perform this operation. It might be necessary to refresh the browser tab.";class yo{constructor(){this.onCommittedListeners=[]}addOnCommittedListener(e){this.onCommittedListeners.push(e)}raiseOnCommittedEvent(){this.onCommittedListeners.forEach((e=>e()))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Xe(s){if(s.code!==m.FAILED_PRECONDITION||s.message!==po)throw s;g("LocalStore","Unexpectedly lost primary lease")}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class d{constructor(e){this.nextCallback=null,this.catchCallback=null,this.result=void 0,this.error=void 0,this.isDone=!1,this.callbackAttached=!1,e((t=>{this.isDone=!0,this.result=t,this.nextCallback&&this.nextCallback(t)}),(t=>{this.isDone=!0,this.error=t,this.catchCallback&&this.catchCallback(t)}))}catch(e){return this.next(void 0,e)}next(e,t){return this.callbackAttached&&I(59440),this.callbackAttached=!0,this.isDone?this.error?this.wrapFailure(t,this.error):this.wrapSuccess(e,this.result):new d(((n,r)=>{this.nextCallback=i=>{this.wrapSuccess(e,i).next(n,r)},this.catchCallback=i=>{this.wrapFailure(t,i).next(n,r)}}))}toPromise(){return new Promise(((e,t)=>{this.next(e,t)}))}wrapUserFunction(e){try{const t=e();return t instanceof d?t:d.resolve(t)}catch(t){return d.reject(t)}}wrapSuccess(e,t){return e?this.wrapUserFunction((()=>e(t))):d.resolve(t)}wrapFailure(e,t){return e?this.wrapUserFunction((()=>e(t))):d.reject(t)}static resolve(e){return new d(((t,n)=>{t(e)}))}static reject(e){return new d(((t,n)=>{n(e)}))}static waitFor(e){return new d(((t,n)=>{let r=0,i=0,o=!1;e.forEach((a=>{++r,a.next((()=>{++i,o&&i===r&&t()}),(u=>n(u)))})),o=!0,i===r&&t()}))}static or(e){let t=d.resolve(!1);for(const n of e)t=t.next((r=>r?d.resolve(r):n()));return t}static forEach(e,t){const n=[];return e.forEach(((r,i)=>{n.push(t.call(this,r,i))})),this.waitFor(n)}static mapArray(e,t){return new d(((n,r)=>{const i=e.length,o=new Array(i);let a=0;for(let u=0;u<i;u++){const c=u;t(e[c]).next((l=>{o[c]=l,++a,a===i&&n(o)}),(l=>r(l)))}}))}static doWhile(e,t){return new d(((n,r)=>{const i=()=>{e()===!0?t().next((()=>{i()}),r):n()};i()}))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const se="SimpleDb";class ir{static open(e,t,n,r){try{return new ir(t,e.transaction(r,n))}catch(i){throw new jt(t,i)}}constructor(e,t){this.action=e,this.transaction=t,this.aborted=!1,this.S=new ht,this.transaction.oncomplete=()=>{this.S.resolve()},this.transaction.onabort=()=>{t.error?this.S.reject(new jt(e,t.error)):this.S.resolve()},this.transaction.onerror=n=>{const r=as(n.target.error);this.S.reject(new jt(e,r))}}get D(){return this.S.promise}abort(e){e&&this.S.reject(e),this.aborted||(g(se,"Aborting transaction:",e?e.message:"Client-initiated abort"),this.aborted=!0,this.transaction.abort())}C(){const e=this.transaction;this.aborted||typeof e.commit!="function"||e.commit()}store(e){const t=this.transaction.objectStore(e);return new Hu(t)}}class Pe{static delete(e){return g(se,"Removing database:",e),Oe(Ru().indexedDB.deleteDatabase(e)).toPromise()}static v(){if(!vu())return!1;if(Pe.F())return!0;const e=Fn(),t=Pe.M(e),n=0<t&&t<10,r=Io(e),i=0<r&&r<4.5;return!(e.indexOf("MSIE ")>0||e.indexOf("Trident/")>0||e.indexOf("Edge/")>0||n||i)}static F(){return typeof process<"u"&&process.__PRIVATE_env?.__PRIVATE_USE_MOCK_PERSISTENCE==="YES"}static O(e,t){return e.store(t)}static M(e){const t=e.match(/i(?:phone|pad|pod) os ([\d_]+)/i),n=t?t[1].split("_").slice(0,2).join("."):"-1";return Number(n)}constructor(e,t,n){this.name=e,this.version=t,this.N=n,this.B=null,Pe.M(Fn())===12.2&&H("Firestore persistence suffers from a bug in iOS 12.2 Safari that may cause your app to stop working. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.")}async L(e){return this.db||(g(se,"Opening database:",this.name),this.db=await new Promise(((t,n)=>{const r=indexedDB.open(this.name,this.version);r.onsuccess=i=>{const o=i.target.result;t(o)},r.onblocked=()=>{n(new jt(e,"Cannot upgrade IndexedDB schema while another tab is open. Close all tabs that access Firestore and reload this page to proceed."))},r.onerror=i=>{const o=i.target.error;o.name==="VersionError"?n(new y(m.FAILED_PRECONDITION,"A newer version of the Firestore SDK was previously used and so the persisted data is not compatible with the version of the SDK you are now using. The SDK will operate with persistence disabled. If you need persistence, please re-upgrade to a newer version of the SDK or else clear the persisted IndexedDB data for your app to start fresh.")):o.name==="InvalidStateError"?n(new y(m.FAILED_PRECONDITION,"Unable to open an IndexedDB connection. This could be due to running in a private browsing session on a browser whose private browsing sessions do not support IndexedDB: "+o)):n(new jt(e,o))},r.onupgradeneeded=i=>{g(se,'Database "'+this.name+'" requires upgrade from version:',i.oldVersion);const o=i.target.result;this.N.k(o,r.transaction,i.oldVersion,this.version).next((()=>{g(se,"Database upgrade to version "+this.version+" complete")}))}}))),this.K&&(this.db.onversionchange=t=>this.K(t)),this.db}q(e){this.K=e,this.db&&(this.db.onversionchange=t=>e(t))}async runTransaction(e,t,n,r){const i=t==="readonly";let o=0;for(;;){++o;try{this.db=await this.L(e);const a=ir.open(this.db,e,i?"readonly":"readwrite",n),u=r(a).next((c=>(a.C(),c))).catch((c=>(a.abort(c),d.reject(c)))).toPromise();return u.catch((()=>{})),await a.D,u}catch(a){const u=a,c=u.name!=="FirebaseError"&&o<3;if(g(se,"Transaction failed with error:",u.message,"Retrying:",c),this.close(),!c)return Promise.reject(u)}}}close(){this.db&&this.db.close(),this.db=void 0}}function Io(s){const e=s.match(/Android ([\d.]+)/i),t=e?e[1].split(".").slice(0,2).join("."):"-1";return Number(t)}class Wu{constructor(e){this.U=e,this.$=!1,this.W=null}get isDone(){return this.$}get G(){return this.W}set cursor(e){this.U=e}done(){this.$=!0}j(e){this.W=e}delete(){return Oe(this.U.delete())}}class jt extends y{constructor(e,t){super(m.UNAVAILABLE,`IndexedDB transaction '${e}' failed: ${t}`),this.name="IndexedDbTransactionError"}}function Ze(s){return s.name==="IndexedDbTransactionError"}class Hu{constructor(e){this.store=e}put(e,t){let n;return t!==void 0?(g(se,"PUT",this.store.name,e,t),n=this.store.put(t,e)):(g(se,"PUT",this.store.name,"<auto-key>",e),n=this.store.put(e)),Oe(n)}add(e){return g(se,"ADD",this.store.name,e,e),Oe(this.store.add(e))}get(e){return Oe(this.store.get(e)).next((t=>(t===void 0&&(t=null),g(se,"GET",this.store.name,e,t),t)))}delete(e){return g(se,"DELETE",this.store.name,e),Oe(this.store.delete(e))}count(){return g(se,"COUNT",this.store.name),Oe(this.store.count())}J(e,t){const n=this.options(e,t),r=n.index?this.store.index(n.index):this.store;if(typeof r.getAll=="function"){const i=r.getAll(n.range);return new d(((o,a)=>{i.onerror=u=>{a(u.target.error)},i.onsuccess=u=>{o(u.target.result)}}))}{const i=this.cursor(n),o=[];return this.H(i,((a,u)=>{o.push(u)})).next((()=>o))}}Z(e,t){const n=this.store.getAll(e,t===null?void 0:t);return new d(((r,i)=>{n.onerror=o=>{i(o.target.error)},n.onsuccess=o=>{r(o.target.result)}}))}X(e,t){g(se,"DELETE ALL",this.store.name);const n=this.options(e,t);n.Y=!1;const r=this.cursor(n);return this.H(r,((i,o,a)=>a.delete()))}ee(e,t){let n;t?n=e:(n={},t=e);const r=this.cursor(n);return this.H(r,t)}te(e){const t=this.cursor({});return new d(((n,r)=>{t.onerror=i=>{const o=as(i.target.error);r(o)},t.onsuccess=i=>{const o=i.target.result;o?e(o.primaryKey,o.value).next((a=>{a?o.continue():n()})):n()}}))}H(e,t){const n=[];return new d(((r,i)=>{e.onerror=o=>{i(o.target.error)},e.onsuccess=o=>{const a=o.target.result;if(!a)return void r();const u=new Wu(a),c=t(a.primaryKey,a.value,u);if(c instanceof d){const l=c.catch((h=>(u.done(),d.reject(h))));n.push(l)}u.isDone?r():u.G===null?a.continue():a.continue(u.G)}})).next((()=>d.waitFor(n)))}options(e,t){let n;return e!==void 0&&(typeof e=="string"?n=e:t=e),{index:n,range:t}}cursor(e){let t="next";if(e.reverse&&(t="prev"),e.index){const n=this.store.index(e.index);return e.Y?n.openKeyCursor(e.range,t):n.openCursor(e.range,t)}return this.store.openCursor(e.range,t)}}function Oe(s){return new d(((e,t)=>{s.onsuccess=n=>{const r=n.target.result;e(r)},s.onerror=n=>{const r=as(n.target.error);t(r)}}))}let Ws=!1;function as(s){const e=Pe.M(Fn());if(e>=12.2&&e<13){const t="An internal error was encountered in the Indexed Database server";if(s.message.indexOf(t)>=0){const n=new y("internal",`IOS_INDEXEDDB_BUG1: IndexedDb has thrown '${t}'. This is likely due to an unavoidable bug in iOS. See https://stackoverflow.com/q/56496296/110915 for details and a potential workaround.`);return Ws||(Ws=!0,setTimeout((()=>{throw n}),0)),n}}return s}const Qt="IndexBackfiller";class Ju{constructor(e,t){this.asyncQueue=e,this.ne=t,this.task=null}start(){this.re(15e3)}stop(){this.task&&(this.task.cancel(),this.task=null)}get started(){return this.task!==null}re(e){g(Qt,`Scheduled in ${e}ms`),this.task=this.asyncQueue.enqueueAfterDelay("index_backfill",e,(async()=>{this.task=null;try{const t=await this.ne.ie();g(Qt,`Documents written: ${t}`)}catch(t){Ze(t)?g(Qt,"Ignoring IndexedDB error during index backfill: ",t):await Xe(t)}await this.re(6e4)}))}}class Yu{constructor(e,t){this.localStore=e,this.persistence=t}async ie(e=50){return this.persistence.runTransaction("Backfill Indexes","readwrite-primary",(t=>this.se(t,e)))}se(e,t){const n=new Set;let r=t,i=!0;return d.doWhile((()=>i===!0&&r>0),(()=>this.localStore.indexManager.getNextCollectionGroupToUpdate(e).next((o=>{if(o!==null&&!n.has(o))return g(Qt,`Processing collection: ${o}`),this.oe(e,o,r).next((a=>{r-=a,n.add(o)}));i=!1})))).next((()=>t-r))}oe(e,t,n){return this.localStore.indexManager.getMinOffsetFromCollectionGroup(e,t).next((r=>this.localStore.localDocuments.getNextDocuments(e,t,r,n).next((i=>{const o=i.changes;return this.localStore.indexManager.updateIndexEntries(e,o).next((()=>this._e(r,i))).next((a=>(g(Qt,`Updating offset: ${a}`),this.localStore.indexManager.updateCollectionGroup(e,t,a)))).next((()=>o.size))}))))}_e(e,t){let n=e;return t.changes.forEach(((r,i)=>{const o=go(i);os(o,n)>0&&(n=o)})),new ie(n.readTime,n.documentKey,Math.max(t.batchId,e.largestBatchId))}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class re{constructor(e,t){this.previousValue=e,t&&(t.sequenceNumberHandler=n=>this.ae(n),this.ue=n=>t.writeSequenceNumber(n))}ae(e){return this.previousValue=Math.max(e,this.previousValue),this.previousValue}next(){const e=++this.previousValue;return this.ue&&this.ue(e),e}}re.ce=-1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const ze=-1;function or(s){return s==null}function rn(s){return s===0&&1/s==-1/0}function Xu(s){return typeof s=="number"&&Number.isInteger(s)&&!rn(s)&&s<=Number.MAX_SAFE_INTEGER&&s>=Number.MIN_SAFE_INTEGER}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Bn="";function ee(s){let e="";for(let t=0;t<s.length;t++)e.length>0&&(e=Hs(e)),e=Zu(s.get(t),e);return Hs(e)}function Zu(s,e){let t=e;const n=s.length;for(let r=0;r<n;r++){const i=s.charAt(r);switch(i){case"\0":t+="";break;case Bn:t+="";break;default:t+=i}}return t}function Hs(s){return s+Bn+""}function fe(s){const e=s.length;if(T(e>=2,64408,{path:s}),e===2)return T(s.charAt(0)===Bn&&s.charAt(1)==="",56145,{path:s}),M.emptyPath();const t=e-2,n=[];let r="";for(let i=0;i<e;){const o=s.indexOf(Bn,i);switch((o<0||o>t)&&I(50515,{path:s}),s.charAt(o+1)){case"":const a=s.substring(i,o);let u;r.length===0?u=a:(r+=a,u=r,r=""),n.push(u);break;case"":r+=s.substring(i,o),r+="\0";break;case"":r+=s.substring(i,o+1);break;default:I(61167,{path:s})}i=o+2}return new M(n)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Me="remoteDocuments",mn="owner",tt="owner",sn="mutationQueues",ec="userId",ce="mutations",Js="batchId",Ue="userMutationsIndex",Ys=["userId","batchId"];/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function bn(s,e){return[s,ee(e)]}function To(s,e,t){return[s,ee(e),t]}const tc={},yt="documentMutations",Un="remoteDocumentsV14",nc=["prefixPath","collectionGroup","readTime","documentId"],xn="documentKeyIndex",rc=["prefixPath","collectionGroup","documentId"],Eo="collectionGroupIndex",sc=["collectionGroup","readTime","prefixPath","documentId"],on="remoteDocumentGlobal",Cr="remoteDocumentGlobalKey",It="targets",Ao="queryTargetsIndex",ic=["canonicalId","targetId"],Tt="targetDocuments",oc=["targetId","path"],us="documentTargetsIndex",ac=["path","targetId"],qn="targetGlobalKey",Ke="targetGlobal",an="collectionParents",uc=["collectionId","parent"],Et="clientMetadata",cc="clientId",ar="bundles",lc="bundleId",ur="namedQueries",hc="name",cs="indexConfiguration",dc="indexId",Nr="collectionGroupIndex",fc="collectionGroup",Wt="indexState",mc=["indexId","uid"],wo="sequenceNumberIndex",_c=["uid","sequenceNumber"],Ht="indexEntries",gc=["indexId","uid","arrayValue","directionalValue","orderedDocumentKey","documentKey"],Ro="documentKeyIndex",pc=["indexId","uid","orderedDocumentKey"],cr="documentOverlays",yc=["userId","collectionPath","documentId"],kr="collectionPathOverlayIndex",Ic=["userId","collectionPath","largestBatchId"],vo="collectionGroupOverlayIndex",Tc=["userId","collectionGroup","largestBatchId"],ls="globals",Ec="name",Vo=[sn,ce,yt,Me,It,mn,Ke,Tt,Et,on,an,ar,ur],Ac=[...Vo,cr],So=[sn,ce,yt,Un,It,mn,Ke,Tt,Et,on,an,ar,ur,cr],Po=So,hs=[...Po,cs,Wt,Ht],wc=hs,bo=[...hs,ls],Rc=bo;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Mr extends yo{constructor(e,t){super(),this.le=e,this.currentSequenceNumber=t}}function Q(s,e){const t=E(s);return Pe.O(t.le,e)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Xs(s){let e=0;for(const t in s)Object.prototype.hasOwnProperty.call(s,t)&&e++;return e}function ds(s,e){for(const t in s)Object.prototype.hasOwnProperty.call(s,t)&&e(t,s[t])}function vc(s){for(const e in s)if(Object.prototype.hasOwnProperty.call(s,e))return!1;return!0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class k{constructor(e,t){this.comparator=e,this.root=t||Y.EMPTY}insert(e,t){return new k(this.comparator,this.root.insert(e,t,this.comparator).copy(null,null,Y.BLACK,null,null))}remove(e){return new k(this.comparator,this.root.remove(e,this.comparator).copy(null,null,Y.BLACK,null,null))}get(e){let t=this.root;for(;!t.isEmpty();){const n=this.comparator(e,t.key);if(n===0)return t.value;n<0?t=t.left:n>0&&(t=t.right)}return null}indexOf(e){let t=0,n=this.root;for(;!n.isEmpty();){const r=this.comparator(e,n.key);if(r===0)return t+n.left.size;r<0?n=n.left:(t+=n.left.size+1,n=n.right)}return-1}isEmpty(){return this.root.isEmpty()}get size(){return this.root.size}minKey(){return this.root.minKey()}maxKey(){return this.root.maxKey()}inorderTraversal(e){return this.root.inorderTraversal(e)}forEach(e){this.inorderTraversal(((t,n)=>(e(t,n),!1)))}toString(){const e=[];return this.inorderTraversal(((t,n)=>(e.push(`${t}:${n}`),!1))),`{${e.join(", ")}}`}reverseTraversal(e){return this.root.reverseTraversal(e)}getIterator(){return new En(this.root,null,this.comparator,!1)}getIteratorFrom(e){return new En(this.root,e,this.comparator,!1)}getReverseIterator(){return new En(this.root,null,this.comparator,!0)}getReverseIteratorFrom(e){return new En(this.root,e,this.comparator,!0)}}class En{constructor(e,t,n,r){this.isReverse=r,this.nodeStack=[];let i=1;for(;!e.isEmpty();)if(i=t?n(e.key,t):1,t&&r&&(i*=-1),i<0)e=this.isReverse?e.left:e.right;else{if(i===0){this.nodeStack.push(e);break}this.nodeStack.push(e),e=this.isReverse?e.right:e.left}}getNext(){let e=this.nodeStack.pop();const t={key:e.key,value:e.value};if(this.isReverse)for(e=e.left;!e.isEmpty();)this.nodeStack.push(e),e=e.right;else for(e=e.right;!e.isEmpty();)this.nodeStack.push(e),e=e.left;return t}hasNext(){return this.nodeStack.length>0}peek(){if(this.nodeStack.length===0)return null;const e=this.nodeStack[this.nodeStack.length-1];return{key:e.key,value:e.value}}}class Y{constructor(e,t,n,r,i){this.key=e,this.value=t,this.color=n??Y.RED,this.left=r??Y.EMPTY,this.right=i??Y.EMPTY,this.size=this.left.size+1+this.right.size}copy(e,t,n,r,i){return new Y(e??this.key,t??this.value,n??this.color,r??this.left,i??this.right)}isEmpty(){return!1}inorderTraversal(e){return this.left.inorderTraversal(e)||e(this.key,this.value)||this.right.inorderTraversal(e)}reverseTraversal(e){return this.right.reverseTraversal(e)||e(this.key,this.value)||this.left.reverseTraversal(e)}min(){return this.left.isEmpty()?this:this.left.min()}minKey(){return this.min().key}maxKey(){return this.right.isEmpty()?this.key:this.right.maxKey()}insert(e,t,n){let r=this;const i=n(e,r.key);return r=i<0?r.copy(null,null,null,r.left.insert(e,t,n),null):i===0?r.copy(null,t,null,null,null):r.copy(null,null,null,null,r.right.insert(e,t,n)),r.fixUp()}removeMin(){if(this.left.isEmpty())return Y.EMPTY;let e=this;return e.left.isRed()||e.left.left.isRed()||(e=e.moveRedLeft()),e=e.copy(null,null,null,e.left.removeMin(),null),e.fixUp()}remove(e,t){let n,r=this;if(t(e,r.key)<0)r.left.isEmpty()||r.left.isRed()||r.left.left.isRed()||(r=r.moveRedLeft()),r=r.copy(null,null,null,r.left.remove(e,t),null);else{if(r.left.isRed()&&(r=r.rotateRight()),r.right.isEmpty()||r.right.isRed()||r.right.left.isRed()||(r=r.moveRedRight()),t(e,r.key)===0){if(r.right.isEmpty())return Y.EMPTY;n=r.right.min(),r=r.copy(n.key,n.value,null,null,r.right.removeMin())}r=r.copy(null,null,null,null,r.right.remove(e,t))}return r.fixUp()}isRed(){return this.color}fixUp(){let e=this;return e.right.isRed()&&!e.left.isRed()&&(e=e.rotateLeft()),e.left.isRed()&&e.left.left.isRed()&&(e=e.rotateRight()),e.left.isRed()&&e.right.isRed()&&(e=e.colorFlip()),e}moveRedLeft(){let e=this.colorFlip();return e.right.left.isRed()&&(e=e.copy(null,null,null,null,e.right.rotateRight()),e=e.rotateLeft(),e=e.colorFlip()),e}moveRedRight(){let e=this.colorFlip();return e.left.left.isRed()&&(e=e.rotateRight(),e=e.colorFlip()),e}rotateLeft(){const e=this.copy(null,null,Y.RED,null,this.right.left);return this.right.copy(null,null,this.color,e,null)}rotateRight(){const e=this.copy(null,null,Y.RED,this.left.right,null);return this.left.copy(null,null,this.color,null,e)}colorFlip(){const e=this.left.copy(null,null,!this.left.color,null,null),t=this.right.copy(null,null,!this.right.color,null,null);return this.copy(null,null,!this.color,e,t)}checkMaxDepth(){const e=this.check();return Math.pow(2,e)<=this.size+1}check(){if(this.isRed()&&this.left.isRed())throw I(43730,{key:this.key,value:this.value});if(this.right.isRed())throw I(14113,{key:this.key,value:this.value});const e=this.left.check();if(e!==this.right.check())throw I(27949);return e+(this.isRed()?0:1)}}Y.EMPTY=null,Y.RED=!0,Y.BLACK=!1;Y.EMPTY=new class{constructor(){this.size=0}get key(){throw I(57766)}get value(){throw I(16141)}get color(){throw I(16727)}get left(){throw I(29726)}get right(){throw I(36894)}copy(e,t,n,r,i){return this}insert(e,t,n){return new Y(e,t)}remove(e,t){return this}isEmpty(){return!0}inorderTraversal(e){return!1}reverseTraversal(e){return!1}minKey(){return null}maxKey(){return null}isRed(){return!1}checkMaxDepth(){return!0}check(){return 0}};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class D{constructor(e){this.comparator=e,this.data=new k(this.comparator)}has(e){return this.data.get(e)!==null}first(){return this.data.minKey()}last(){return this.data.maxKey()}get size(){return this.data.size}indexOf(e){return this.data.indexOf(e)}forEach(e){this.data.inorderTraversal(((t,n)=>(e(t),!1)))}forEachInRange(e,t){const n=this.data.getIteratorFrom(e[0]);for(;n.hasNext();){const r=n.getNext();if(this.comparator(r.key,e[1])>=0)return;t(r.key)}}forEachWhile(e,t){let n;for(n=t!==void 0?this.data.getIteratorFrom(t):this.data.getIterator();n.hasNext();)if(!e(n.getNext().key))return}firstAfterOrEqual(e){const t=this.data.getIteratorFrom(e);return t.hasNext()?t.getNext().key:null}getIterator(){return new Zs(this.data.getIterator())}getIteratorFrom(e){return new Zs(this.data.getIteratorFrom(e))}add(e){return this.copy(this.data.remove(e).insert(e,!0))}delete(e){return this.has(e)?this.copy(this.data.remove(e)):this}isEmpty(){return this.data.isEmpty()}unionWith(e){let t=this;return t.size<e.size&&(t=e,e=this),e.forEach((n=>{t=t.add(n)})),t}isEqual(e){if(!(e instanceof D)||this.size!==e.size)return!1;const t=this.data.getIterator(),n=e.data.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=n.getNext().key;if(this.comparator(r,i)!==0)return!1}return!0}toArray(){const e=[];return this.forEach((t=>{e.push(t)})),e}toString(){const e=[];return this.forEach((t=>e.push(t))),"SortedSet("+e.toString()+")"}copy(e){const t=new D(this.comparator);return t.data=e,t}}class Zs{constructor(e){this.iter=e}getNext(){return this.iter.getNext().key}hasNext(){return this.iter.hasNext()}}function nt(s){return s.hasNext()?s.getNext():void 0}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Te{constructor(e){this.fields=e,e.sort(B.comparator)}static empty(){return new Te([])}unionWith(e){let t=new D(B.comparator);for(const n of this.fields)t=t.add(n);for(const n of e)t=t.add(n);return new Te(t.toArray())}covers(e){for(const t of this.fields)if(t.isPrefixOf(e))return!0;return!1}isEqual(e){return gt(this.fields,e.fields,((t,n)=>t.isEqual(n)))}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xo extends Error{constructor(){super(...arguments),this.name="Base64DecodeError"}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class U{constructor(e){this.binaryString=e}static fromBase64String(e){const t=(function(r){try{return atob(r)}catch(i){throw typeof DOMException<"u"&&i instanceof DOMException?new xo("Invalid base64 string: "+i):i}})(e);return new U(t)}static fromUint8Array(e){const t=(function(r){let i="";for(let o=0;o<r.length;++o)i+=String.fromCharCode(r[o]);return i})(e);return new U(t)}[Symbol.iterator](){let e=0;return{next:()=>e<this.binaryString.length?{value:this.binaryString.charCodeAt(e++),done:!1}:{value:void 0,done:!0}}}toBase64(){return(function(t){return btoa(t)})(this.binaryString)}toUint8Array(){return(function(t){const n=new Uint8Array(t.length);for(let r=0;r<t.length;r++)n[r]=t.charCodeAt(r);return n})(this.binaryString)}approximateByteSize(){return 2*this.binaryString.length}compareTo(e){return V(this.binaryString,e.binaryString)}isEqual(e){return this.binaryString===e.binaryString}}U.EMPTY_BYTE_STRING=new U("");const Vc=new RegExp(/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.(\d+))?Z$/);function be(s){if(T(!!s,39018),typeof s=="string"){let e=0;const t=Vc.exec(s);if(T(!!t,46558,{timestamp:s}),t[1]){let r=t[1];r=(r+"000000000").substr(0,9),e=Number(r)}const n=new Date(s);return{seconds:Math.floor(n.getTime()/1e3),nanos:e}}return{seconds:G(s.seconds),nanos:G(s.nanos)}}function G(s){return typeof s=="number"?s:typeof s=="string"?Number(s):0}function We(s){return typeof s=="string"?U.fromBase64String(s):U.fromUint8Array(s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Do="server_timestamp",Co="__type__",No="__previous_value__",ko="__local_write_time__";function fs(s){return(s?.mapValue?.fields||{})[Co]?.stringValue===Do}function Mo(s){const e=s.mapValue.fields[No];return fs(e)?Mo(e):e}function zn(s){const e=be(s.mapValue.fields[ko].timestampValue);return new O(e.seconds,e.nanos)}const un="(default)";class At{constructor(e,t){this.projectId=e,this.database=t||un}static empty(){return new At("","")}get isDefaultDatabase(){return this.database===un}isEqual(e){return e instanceof At&&e.projectId===this.projectId&&e.database===this.database}}function Sc(s,e){if(!Object.prototype.hasOwnProperty.apply(s.options,["projectId"]))throw new y(m.INVALID_ARGUMENT,'"projectId" not provided in firebase.initializeApp.');return new At(s.options.projectId,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Oo="__type__",Fo="__max__",Se={mapValue:{fields:{__type__:{stringValue:Fo}}}},Lo="__vector__",Kn="value",Dn={nullValue:"NULL_VALUE"};function wt(s){return"nullValue"in s?0:"booleanValue"in s?1:"integerValue"in s||"doubleValue"in s?2:"timestampValue"in s?3:"stringValue"in s?5:"bytesValue"in s?6:"referenceValue"in s?7:"geoPointValue"in s?8:"arrayValue"in s?9:"mapValue"in s?fs(s)?4:Bo(s)?9007199254740991:lr(s)?10:11:I(28295,{value:s})}function pe(s,e){if(s===e)return!0;const t=wt(s);if(t!==wt(e))return!1;switch(t){case 0:case 9007199254740991:return!0;case 1:return s.booleanValue===e.booleanValue;case 4:return zn(s).isEqual(zn(e));case 3:return(function(r,i){if(typeof r.timestampValue=="string"&&typeof i.timestampValue=="string"&&r.timestampValue.length===i.timestampValue.length)return r.timestampValue===i.timestampValue;const o=be(r.timestampValue),a=be(i.timestampValue);return o.seconds===a.seconds&&o.nanos===a.nanos})(s,e);case 5:return s.stringValue===e.stringValue;case 6:return(function(r,i){return We(r.bytesValue).isEqual(We(i.bytesValue))})(s,e);case 7:return s.referenceValue===e.referenceValue;case 8:return(function(r,i){return G(r.geoPointValue.latitude)===G(i.geoPointValue.latitude)&&G(r.geoPointValue.longitude)===G(i.geoPointValue.longitude)})(s,e);case 2:return(function(r,i){if("integerValue"in r&&"integerValue"in i)return G(r.integerValue)===G(i.integerValue);if("doubleValue"in r&&"doubleValue"in i){const o=G(r.doubleValue),a=G(i.doubleValue);return o===a?rn(o)===rn(a):isNaN(o)&&isNaN(a)}return!1})(s,e);case 9:return gt(s.arrayValue.values||[],e.arrayValue.values||[],pe);case 10:case 11:return(function(r,i){const o=r.mapValue.fields||{},a=i.mapValue.fields||{};if(Xs(o)!==Xs(a))return!1;for(const u in o)if(o.hasOwnProperty(u)&&(a[u]===void 0||!pe(o[u],a[u])))return!1;return!0})(s,e);default:return I(52216,{left:s})}}function cn(s,e){return(s.values||[]).find((t=>pe(t,e)))!==void 0}function xe(s,e){if(s===e)return 0;const t=wt(s),n=wt(e);if(t!==n)return V(t,n);switch(t){case 0:case 9007199254740991:return 0;case 1:return V(s.booleanValue,e.booleanValue);case 2:return(function(i,o){const a=G(i.integerValue||i.doubleValue),u=G(o.integerValue||o.doubleValue);return a<u?-1:a>u?1:a===u?0:isNaN(a)?isNaN(u)?0:-1:1})(s,e);case 3:return ei(s.timestampValue,e.timestampValue);case 4:return ei(zn(s),zn(e));case 5:return xr(s.stringValue,e.stringValue);case 6:return(function(i,o){const a=We(i),u=We(o);return a.compareTo(u)})(s.bytesValue,e.bytesValue);case 7:return(function(i,o){const a=i.split("/"),u=o.split("/");for(let c=0;c<a.length&&c<u.length;c++){const l=V(a[c],u[c]);if(l!==0)return l}return V(a.length,u.length)})(s.referenceValue,e.referenceValue);case 8:return(function(i,o){const a=V(G(i.latitude),G(o.latitude));return a!==0?a:V(G(i.longitude),G(o.longitude))})(s.geoPointValue,e.geoPointValue);case 9:return ti(s.arrayValue,e.arrayValue);case 10:return(function(i,o){const a=i.fields||{},u=o.fields||{},c=a[Kn]?.arrayValue,l=u[Kn]?.arrayValue,h=V(c?.values?.length||0,l?.values?.length||0);return h!==0?h:ti(c,l)})(s.mapValue,e.mapValue);case 11:return(function(i,o){if(i===Se.mapValue&&o===Se.mapValue)return 0;if(i===Se.mapValue)return 1;if(o===Se.mapValue)return-1;const a=i.fields||{},u=Object.keys(a),c=o.fields||{},l=Object.keys(c);u.sort(),l.sort();for(let h=0;h<u.length&&h<l.length;++h){const f=xr(u[h],l[h]);if(f!==0)return f;const _=xe(a[u[h]],c[l[h]]);if(_!==0)return _}return V(u.length,l.length)})(s.mapValue,e.mapValue);default:throw I(23264,{he:t})}}function ei(s,e){if(typeof s=="string"&&typeof e=="string"&&s.length===e.length)return V(s,e);const t=be(s),n=be(e),r=V(t.seconds,n.seconds);return r!==0?r:V(t.nanos,n.nanos)}function ti(s,e){const t=s.values||[],n=e.values||[];for(let r=0;r<t.length&&r<n.length;++r){const i=xe(t[r],n[r]);if(i)return i}return V(t.length,n.length)}function Rt(s){return Or(s)}function Or(s){return"nullValue"in s?"null":"booleanValue"in s?""+s.booleanValue:"integerValue"in s?""+s.integerValue:"doubleValue"in s?""+s.doubleValue:"timestampValue"in s?(function(t){const n=be(t);return`time(${n.seconds},${n.nanos})`})(s.timestampValue):"stringValue"in s?s.stringValue:"bytesValue"in s?(function(t){return We(t).toBase64()})(s.bytesValue):"referenceValue"in s?(function(t){return p.fromName(t).toString()})(s.referenceValue):"geoPointValue"in s?(function(t){return`geo(${t.latitude},${t.longitude})`})(s.geoPointValue):"arrayValue"in s?(function(t){let n="[",r=!0;for(const i of t.values||[])r?r=!1:n+=",",n+=Or(i);return n+"]"})(s.arrayValue):"mapValue"in s?(function(t){const n=Object.keys(t.fields||{}).sort();let r="{",i=!0;for(const o of n)i?i=!1:r+=",",r+=`${o}:${Or(t.fields[o])}`;return r+"}"})(s.mapValue):I(61005,{value:s})}function ms(s,e){return{referenceValue:`projects/${s.projectId}/databases/${s.database}/documents/${e.path.canonicalString()}`}}function Fr(s){return!!s&&"integerValue"in s}function ln(s){return!!s&&"arrayValue"in s}function ni(s){return!!s&&"nullValue"in s}function ri(s){return!!s&&"doubleValue"in s&&isNaN(Number(s.doubleValue))}function Ar(s){return!!s&&"mapValue"in s}function lr(s){return(s?.mapValue?.fields||{})[Oo]?.stringValue===Lo}function Jt(s){if(s.geoPointValue)return{geoPointValue:{...s.geoPointValue}};if(s.timestampValue&&typeof s.timestampValue=="object")return{timestampValue:{...s.timestampValue}};if(s.mapValue){const e={mapValue:{fields:{}}};return ds(s.mapValue.fields,((t,n)=>e.mapValue.fields[t]=Jt(n))),e}if(s.arrayValue){const e={arrayValue:{values:[]}};for(let t=0;t<(s.arrayValue.values||[]).length;++t)e.arrayValue.values[t]=Jt(s.arrayValue.values[t]);return e}return{...s}}function Bo(s){return(((s.mapValue||{}).fields||{}).__type__||{}).stringValue===Fo}const Uo={mapValue:{fields:{[Oo]:{stringValue:Lo},[Kn]:{arrayValue:{}}}}};function Pc(s){return"nullValue"in s?Dn:"booleanValue"in s?{booleanValue:!1}:"integerValue"in s||"doubleValue"in s?{doubleValue:NaN}:"timestampValue"in s?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"stringValue"in s?{stringValue:""}:"bytesValue"in s?{bytesValue:""}:"referenceValue"in s?ms(At.empty(),p.empty()):"geoPointValue"in s?{geoPointValue:{latitude:-90,longitude:-180}}:"arrayValue"in s?{arrayValue:{}}:"mapValue"in s?lr(s)?Uo:{mapValue:{}}:I(35942,{value:s})}function bc(s){return"nullValue"in s?{booleanValue:!1}:"booleanValue"in s?{doubleValue:NaN}:"integerValue"in s||"doubleValue"in s?{timestampValue:{seconds:Number.MIN_SAFE_INTEGER}}:"timestampValue"in s?{stringValue:""}:"stringValue"in s?{bytesValue:""}:"bytesValue"in s?ms(At.empty(),p.empty()):"referenceValue"in s?{geoPointValue:{latitude:-90,longitude:-180}}:"geoPointValue"in s?{arrayValue:{}}:"arrayValue"in s?Uo:"mapValue"in s?lr(s)?{mapValue:{}}:Se:I(61959,{value:s})}function si(s,e){const t=xe(s.value,e.value);return t!==0?t:s.inclusive&&!e.inclusive?-1:!s.inclusive&&e.inclusive?1:0}function ii(s,e){const t=xe(s.value,e.value);return t!==0?t:s.inclusive&&!e.inclusive?1:!s.inclusive&&e.inclusive?-1:0}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class oe{constructor(e){this.value=e}static empty(){return new oe({mapValue:{}})}field(e){if(e.isEmpty())return this.value;{let t=this.value;for(let n=0;n<e.length-1;++n)if(t=(t.mapValue.fields||{})[e.get(n)],!Ar(t))return null;return t=(t.mapValue.fields||{})[e.lastSegment()],t||null}}set(e,t){this.getFieldsMap(e.popLast())[e.lastSegment()]=Jt(t)}setAll(e){let t=B.emptyPath(),n={},r=[];e.forEach(((o,a)=>{if(!t.isImmediateParentOf(a)){const u=this.getFieldsMap(t);this.applyChanges(u,n,r),n={},r=[],t=a.popLast()}o?n[a.lastSegment()]=Jt(o):r.push(a.lastSegment())}));const i=this.getFieldsMap(t);this.applyChanges(i,n,r)}delete(e){const t=this.field(e.popLast());Ar(t)&&t.mapValue.fields&&delete t.mapValue.fields[e.lastSegment()]}isEqual(e){return pe(this.value,e.value)}getFieldsMap(e){let t=this.value;t.mapValue.fields||(t.mapValue={fields:{}});for(let n=0;n<e.length;++n){let r=t.mapValue.fields[e.get(n)];Ar(r)&&r.mapValue.fields||(r={mapValue:{fields:{}}},t.mapValue.fields[e.get(n)]=r),t=r}return t.mapValue.fields}applyChanges(e,t,n){ds(t,((r,i)=>e[r]=i));for(const r of n)delete e[r]}clone(){return new oe(Jt(this.value))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class F{constructor(e,t,n,r,i,o,a){this.key=e,this.documentType=t,this.version=n,this.readTime=r,this.createTime=i,this.data=o,this.documentState=a}static newInvalidDocument(e){return new F(e,0,A.min(),A.min(),A.min(),oe.empty(),0)}static newFoundDocument(e,t,n,r){return new F(e,1,t,A.min(),n,r,0)}static newNoDocument(e,t){return new F(e,2,t,A.min(),A.min(),oe.empty(),0)}static newUnknownDocument(e,t){return new F(e,3,t,A.min(),A.min(),oe.empty(),2)}convertToFoundDocument(e,t){return!this.createTime.isEqual(A.min())||this.documentType!==2&&this.documentType!==0||(this.createTime=e),this.version=e,this.documentType=1,this.data=t,this.documentState=0,this}convertToNoDocument(e){return this.version=e,this.documentType=2,this.data=oe.empty(),this.documentState=0,this}convertToUnknownDocument(e){return this.version=e,this.documentType=3,this.data=oe.empty(),this.documentState=2,this}setHasCommittedMutations(){return this.documentState=2,this}setHasLocalMutations(){return this.documentState=1,this.version=A.min(),this}setReadTime(e){return this.readTime=e,this}get hasLocalMutations(){return this.documentState===1}get hasCommittedMutations(){return this.documentState===2}get hasPendingWrites(){return this.hasLocalMutations||this.hasCommittedMutations}isValidDocument(){return this.documentType!==0}isFoundDocument(){return this.documentType===1}isNoDocument(){return this.documentType===2}isUnknownDocument(){return this.documentType===3}isEqual(e){return e instanceof F&&this.key.isEqual(e.key)&&this.version.isEqual(e.version)&&this.documentType===e.documentType&&this.documentState===e.documentState&&this.data.isEqual(e.data)}mutableCopy(){return new F(this.key,this.documentType,this.version,this.readTime,this.createTime,this.data.clone(),this.documentState)}toString(){return`Document(${this.key}, ${this.version}, ${JSON.stringify(this.data.value)}, {createTime: ${this.createTime}}), {documentType: ${this.documentType}}), {documentState: ${this.documentState}})`}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class vt{constructor(e,t){this.position=e,this.inclusive=t}}function oi(s,e,t){let n=0;for(let r=0;r<s.position.length;r++){const i=e[r],o=s.position[r];if(i.field.isKeyField()?n=p.comparator(p.fromName(o.referenceValue),t.key):n=xe(o,t.data.field(i.field)),i.dir==="desc"&&(n*=-1),n!==0)break}return n}function ai(s,e){if(s===null)return e===null;if(e===null||s.inclusive!==e.inclusive||s.position.length!==e.position.length)return!1;for(let t=0;t<s.position.length;t++)if(!pe(s.position[t],e.position[t]))return!1;return!0}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gn{constructor(e,t="asc"){this.field=e,this.dir=t}}function xc(s,e){return s.dir===e.dir&&s.field.isEqual(e.field)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class qo{}class P extends qo{constructor(e,t,n){super(),this.field=e,this.op=t,this.value=n}static create(e,t,n){return e.isKeyField()?t==="in"||t==="not-in"?this.createKeyFieldInFilter(e,t,n):new Dc(e,t,n):t==="array-contains"?new kc(e,n):t==="in"?new Qo(e,n):t==="not-in"?new Mc(e,n):t==="array-contains-any"?new Oc(e,n):new P(e,t,n)}static createKeyFieldInFilter(e,t,n){return t==="in"?new Cc(e,n):new Nc(e,n)}matches(e){const t=e.data.field(this.field);return this.op==="!="?t!==null&&t.nullValue===void 0&&this.matchesComparison(xe(t,this.value)):t!==null&&wt(this.value)===wt(t)&&this.matchesComparison(xe(t,this.value))}matchesComparison(e){switch(this.op){case"<":return e<0;case"<=":return e<=0;case"==":return e===0;case"!=":return e!==0;case">":return e>0;case">=":return e>=0;default:return I(47266,{operator:this.op})}}isInequality(){return["<","<=",">",">=","!=","not-in"].indexOf(this.op)>=0}getFlattenedFilters(){return[this]}getFilters(){return[this]}}class C extends qo{constructor(e,t){super(),this.filters=e,this.op=t,this.Pe=null}static create(e,t){return new C(e,t)}matches(e){return Vt(this)?this.filters.find((t=>!t.matches(e)))===void 0:this.filters.find((t=>t.matches(e)))!==void 0}getFlattenedFilters(){return this.Pe!==null||(this.Pe=this.filters.reduce(((e,t)=>e.concat(t.getFlattenedFilters())),[])),this.Pe}getFilters(){return Object.assign([],this.filters)}}function Vt(s){return s.op==="and"}function Lr(s){return s.op==="or"}function _s(s){return zo(s)&&Vt(s)}function zo(s){for(const e of s.filters)if(e instanceof C)return!1;return!0}function Br(s){if(s instanceof P)return s.field.canonicalString()+s.op.toString()+Rt(s.value);if(_s(s))return s.filters.map((e=>Br(e))).join(",");{const e=s.filters.map((t=>Br(t))).join(",");return`${s.op}(${e})`}}function Ko(s,e){return s instanceof P?(function(n,r){return r instanceof P&&n.op===r.op&&n.field.isEqual(r.field)&&pe(n.value,r.value)})(s,e):s instanceof C?(function(n,r){return r instanceof C&&n.op===r.op&&n.filters.length===r.filters.length?n.filters.reduce(((i,o,a)=>i&&Ko(o,r.filters[a])),!0):!1})(s,e):void I(19439)}function Go(s,e){const t=s.filters.concat(e);return C.create(t,s.op)}function $o(s){return s instanceof P?(function(t){return`${t.field.canonicalString()} ${t.op} ${Rt(t.value)}`})(s):s instanceof C?(function(t){return t.op.toString()+" {"+t.getFilters().map($o).join(" ,")+"}"})(s):"Filter"}class Dc extends P{constructor(e,t,n){super(e,t,n),this.key=p.fromName(n.referenceValue)}matches(e){const t=p.comparator(e.key,this.key);return this.matchesComparison(t)}}class Cc extends P{constructor(e,t){super(e,"in",t),this.keys=jo("in",t)}matches(e){return this.keys.some((t=>t.isEqual(e.key)))}}class Nc extends P{constructor(e,t){super(e,"not-in",t),this.keys=jo("not-in",t)}matches(e){return!this.keys.some((t=>t.isEqual(e.key)))}}function jo(s,e){return(e.arrayValue?.values||[]).map((t=>p.fromName(t.referenceValue)))}class kc extends P{constructor(e,t){super(e,"array-contains",t)}matches(e){const t=e.data.field(this.field);return ln(t)&&cn(t.arrayValue,this.value)}}class Qo extends P{constructor(e,t){super(e,"in",t)}matches(e){const t=e.data.field(this.field);return t!==null&&cn(this.value.arrayValue,t)}}class Mc extends P{constructor(e,t){super(e,"not-in",t)}matches(e){if(cn(this.value.arrayValue,{nullValue:"NULL_VALUE"}))return!1;const t=e.data.field(this.field);return t!==null&&t.nullValue===void 0&&!cn(this.value.arrayValue,t)}}class Oc extends P{constructor(e,t){super(e,"array-contains-any",t)}matches(e){const t=e.data.field(this.field);return!(!ln(t)||!t.arrayValue.values)&&t.arrayValue.values.some((n=>cn(this.value.arrayValue,n)))}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fc{constructor(e,t=null,n=[],r=[],i=null,o=null,a=null){this.path=e,this.collectionGroup=t,this.orderBy=n,this.filters=r,this.limit=i,this.startAt=o,this.endAt=a,this.Te=null}}function Ur(s,e=null,t=[],n=[],r=null,i=null,o=null){return new Fc(s,e,t,n,r,i,o)}function He(s){const e=E(s);if(e.Te===null){let t=e.path.canonicalString();e.collectionGroup!==null&&(t+="|cg:"+e.collectionGroup),t+="|f:",t+=e.filters.map((n=>Br(n))).join(","),t+="|ob:",t+=e.orderBy.map((n=>(function(i){return i.field.canonicalString()+i.dir})(n))).join(","),or(e.limit)||(t+="|l:",t+=e.limit),e.startAt&&(t+="|lb:",t+=e.startAt.inclusive?"b:":"a:",t+=e.startAt.position.map((n=>Rt(n))).join(",")),e.endAt&&(t+="|ub:",t+=e.endAt.inclusive?"a:":"b:",t+=e.endAt.position.map((n=>Rt(n))).join(",")),e.Te=t}return e.Te}function _n(s,e){if(s.limit!==e.limit||s.orderBy.length!==e.orderBy.length)return!1;for(let t=0;t<s.orderBy.length;t++)if(!xc(s.orderBy[t],e.orderBy[t]))return!1;if(s.filters.length!==e.filters.length)return!1;for(let t=0;t<s.filters.length;t++)if(!Ko(s.filters[t],e.filters[t]))return!1;return s.collectionGroup===e.collectionGroup&&!!s.path.isEqual(e.path)&&!!ai(s.startAt,e.startAt)&&ai(s.endAt,e.endAt)}function $n(s){return p.isDocumentKey(s.path)&&s.collectionGroup===null&&s.filters.length===0}function jn(s,e){return s.filters.filter((t=>t instanceof P&&t.field.isEqual(e)))}function ui(s,e,t){let n=Dn,r=!0;for(const i of jn(s,e)){let o=Dn,a=!0;switch(i.op){case"<":case"<=":o=Pc(i.value);break;case"==":case"in":case">=":o=i.value;break;case">":o=i.value,a=!1;break;case"!=":case"not-in":o=Dn}si({value:n,inclusive:r},{value:o,inclusive:a})<0&&(n=o,r=a)}if(t!==null){for(let i=0;i<s.orderBy.length;++i)if(s.orderBy[i].field.isEqual(e)){const o=t.position[i];si({value:n,inclusive:r},{value:o,inclusive:t.inclusive})<0&&(n=o,r=t.inclusive);break}}return{value:n,inclusive:r}}function ci(s,e,t){let n=Se,r=!0;for(const i of jn(s,e)){let o=Se,a=!0;switch(i.op){case">=":case">":o=bc(i.value),a=!1;break;case"==":case"in":case"<=":o=i.value;break;case"<":o=i.value,a=!1;break;case"!=":case"not-in":o=Se}ii({value:n,inclusive:r},{value:o,inclusive:a})>0&&(n=o,r=a)}if(t!==null){for(let i=0;i<s.orderBy.length;++i)if(s.orderBy[i].field.isEqual(e)){const o=t.position[i];ii({value:n,inclusive:r},{value:o,inclusive:t.inclusive})>0&&(n=o,r=t.inclusive);break}}return{value:n,inclusive:r}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hr{constructor(e,t=null,n=[],r=[],i=null,o="F",a=null,u=null){this.path=e,this.collectionGroup=t,this.explicitOrderBy=n,this.filters=r,this.limit=i,this.limitType=o,this.startAt=a,this.endAt=u,this.Ie=null,this.Ee=null,this.Re=null,this.startAt,this.endAt}}function Wo(s,e,t,n,r,i,o,a){return new hr(s,e,t,n,r,i,o,a)}function gs(s){return new hr(s)}function li(s){return s.filters.length===0&&s.limit===null&&s.startAt==null&&s.endAt==null&&(s.explicitOrderBy.length===0||s.explicitOrderBy.length===1&&s.explicitOrderBy[0].field.isKeyField())}function Lc(s){return p.isDocumentKey(s.path)&&s.collectionGroup===null&&s.filters.length===0}function Bc(s){return s.collectionGroup!==null}function Yt(s){const e=E(s);if(e.Ie===null){e.Ie=[];const t=new Set;for(const i of e.explicitOrderBy)e.Ie.push(i),t.add(i.field.canonicalString());const n=e.explicitOrderBy.length>0?e.explicitOrderBy[e.explicitOrderBy.length-1].dir:"asc";(function(o){let a=new D(B.comparator);return o.filters.forEach((u=>{u.getFlattenedFilters().forEach((c=>{c.isInequality()&&(a=a.add(c.field))}))})),a})(e).forEach((i=>{t.has(i.canonicalString())||i.isKeyField()||e.Ie.push(new Gn(i,n))})),t.has(B.keyField().canonicalString())||e.Ie.push(new Gn(B.keyField(),n))}return e.Ie}function ue(s){const e=E(s);return e.Ee||(e.Ee=Uc(e,Yt(s))),e.Ee}function Uc(s,e){if(s.limitType==="F")return Ur(s.path,s.collectionGroup,e,s.filters,s.limit,s.startAt,s.endAt);{e=e.map((r=>{const i=r.dir==="desc"?"asc":"desc";return new Gn(r.field,i)}));const t=s.endAt?new vt(s.endAt.position,s.endAt.inclusive):null,n=s.startAt?new vt(s.startAt.position,s.startAt.inclusive):null;return Ur(s.path,s.collectionGroup,e,s.filters,s.limit,t,n)}}function qr(s,e,t){return new hr(s.path,s.collectionGroup,s.explicitOrderBy.slice(),s.filters.slice(),e,t,s.startAt,s.endAt)}function ps(s,e){return _n(ue(s),ue(e))&&s.limitType===e.limitType}function Ho(s){return`${He(ue(s))}|lt:${s.limitType}`}function Ot(s){return`Query(target=${(function(t){let n=t.path.canonicalString();return t.collectionGroup!==null&&(n+=" collectionGroup="+t.collectionGroup),t.filters.length>0&&(n+=`, filters: [${t.filters.map((r=>$o(r))).join(", ")}]`),or(t.limit)||(n+=", limit: "+t.limit),t.orderBy.length>0&&(n+=`, orderBy: [${t.orderBy.map((r=>(function(o){return`${o.field.canonicalString()} (${o.dir})`})(r))).join(", ")}]`),t.startAt&&(n+=", startAt: ",n+=t.startAt.inclusive?"b:":"a:",n+=t.startAt.position.map((r=>Rt(r))).join(",")),t.endAt&&(n+=", endAt: ",n+=t.endAt.inclusive?"a:":"b:",n+=t.endAt.position.map((r=>Rt(r))).join(",")),`Target(${n})`})(ue(s))}; limitType=${s.limitType})`}function gn(s,e){return e.isFoundDocument()&&(function(n,r){const i=r.key.path;return n.collectionGroup!==null?r.key.hasCollectionId(n.collectionGroup)&&n.path.isPrefixOf(i):p.isDocumentKey(n.path)?n.path.isEqual(i):n.path.isImmediateParentOf(i)})(s,e)&&(function(n,r){for(const i of Yt(n))if(!i.field.isKeyField()&&r.data.field(i.field)===null)return!1;return!0})(s,e)&&(function(n,r){for(const i of n.filters)if(!i.matches(r))return!1;return!0})(s,e)&&(function(n,r){return!(n.startAt&&!(function(o,a,u){const c=oi(o,a,u);return o.inclusive?c<=0:c<0})(n.startAt,Yt(n),r)||n.endAt&&!(function(o,a,u){const c=oi(o,a,u);return o.inclusive?c>=0:c>0})(n.endAt,Yt(n),r))})(s,e)}function Jo(s){return s.collectionGroup||(s.path.length%2==1?s.path.lastSegment():s.path.get(s.path.length-2))}function Yo(s){return(e,t)=>{let n=!1;for(const r of Yt(s)){const i=qc(r,e,t);if(i!==0)return i;n=n||r.field.isKeyField()}return 0}}function qc(s,e,t){const n=s.field.isKeyField()?p.comparator(e.key,t.key):(function(i,o,a){const u=o.data.field(i),c=a.data.field(i);return u!==null&&c!==null?xe(u,c):I(42886)})(s.field,e,t);switch(s.dir){case"asc":return n;case"desc":return-1*n;default:return I(19790,{direction:s.dir})}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ce{constructor(e,t){this.mapKeyFn=e,this.equalsFn=t,this.inner={},this.innerSize=0}get(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n!==void 0){for(const[r,i]of n)if(this.equalsFn(r,e))return i}}has(e){return this.get(e)!==void 0}set(e,t){const n=this.mapKeyFn(e),r=this.inner[n];if(r===void 0)return this.inner[n]=[[e,t]],void this.innerSize++;for(let i=0;i<r.length;i++)if(this.equalsFn(r[i][0],e))return void(r[i]=[e,t]);r.push([e,t]),this.innerSize++}delete(e){const t=this.mapKeyFn(e),n=this.inner[t];if(n===void 0)return!1;for(let r=0;r<n.length;r++)if(this.equalsFn(n[r][0],e))return n.length===1?delete this.inner[t]:n.splice(r,1),this.innerSize--,!0;return!1}forEach(e){ds(this.inner,((t,n)=>{for(const[r,i]of n)e(r,i)}))}isEmpty(){return vc(this.inner)}size(){return this.innerSize}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const zc=new k(p.comparator);function ae(){return zc}const Xo=new k(p.comparator);function Kt(...s){let e=Xo;for(const t of s)e=e.insert(t.key,t);return e}function Kc(s){let e=Xo;return s.forEach(((t,n)=>e=e.insert(t,n.overlayedDocument))),e}function me(){return Xt()}function Zo(){return Xt()}function Xt(){return new Ce((s=>s.toString()),((s,e)=>s.isEqual(e)))}const Gc=new k(p.comparator),$c=new D(p.comparator);function S(...s){let e=$c;for(const t of s)e=e.add(t);return e}const jc=new D(V);function ys(){return jc}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Qc(s,e){if(s.useProto3Json){if(isNaN(e))return{doubleValue:"NaN"};if(e===1/0)return{doubleValue:"Infinity"};if(e===-1/0)return{doubleValue:"-Infinity"}}return{doubleValue:rn(e)?"-0":e}}function Wc(s){return{integerValue:""+s}}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dr{constructor(){this._=void 0}}function Hc(s,e,t){return s instanceof hn?(function(r,i){const o={fields:{[Co]:{stringValue:Do},[ko]:{timestampValue:{seconds:r.seconds,nanos:r.nanoseconds}}}};return i&&fs(i)&&(i=Mo(i)),i&&(o.fields[No]=i),{mapValue:o}})(t,e):s instanceof St?ea(s,e):s instanceof Pt?ta(s,e):(function(r,i){const o=Yc(r,i),a=hi(o)+hi(r.Ae);return Fr(o)&&Fr(r.Ae)?Wc(a):Qc(r.serializer,a)})(s,e)}function Jc(s,e,t){return s instanceof St?ea(s,e):s instanceof Pt?ta(s,e):t}function Yc(s,e){return s instanceof dn?(function(n){return Fr(n)||(function(i){return!!i&&"doubleValue"in i})(n)})(e)?e:{integerValue:0}:null}class hn extends dr{}class St extends dr{constructor(e){super(),this.elements=e}}function ea(s,e){const t=na(e);for(const n of s.elements)t.some((r=>pe(r,n)))||t.push(n);return{arrayValue:{values:t}}}class Pt extends dr{constructor(e){super(),this.elements=e}}function ta(s,e){let t=na(e);for(const n of s.elements)t=t.filter((r=>!pe(r,n)));return{arrayValue:{values:t}}}class dn extends dr{constructor(e,t){super(),this.serializer=e,this.Ae=t}}function hi(s){return G(s.integerValue||s.doubleValue)}function na(s){return ln(s)&&s.arrayValue.values?s.arrayValue.values.slice():[]}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Xc{constructor(e,t){this.field=e,this.transform=t}}function Zc(s,e){return s.field.isEqual(e.field)&&(function(n,r){return n instanceof St&&r instanceof St||n instanceof Pt&&r instanceof Pt?gt(n.elements,r.elements,pe):n instanceof dn&&r instanceof dn?pe(n.Ae,r.Ae):n instanceof hn&&r instanceof hn})(s.transform,e.transform)}class el{constructor(e,t){this.version=e,this.transformResults=t}}class le{constructor(e,t){this.updateTime=e,this.exists=t}static none(){return new le}static exists(e){return new le(void 0,e)}static updateTime(e){return new le(e)}get isNone(){return this.updateTime===void 0&&this.exists===void 0}isEqual(e){return this.exists===e.exists&&(this.updateTime?!!e.updateTime&&this.updateTime.isEqual(e.updateTime):!e.updateTime)}}function Cn(s,e){return s.updateTime!==void 0?e.isFoundDocument()&&e.version.isEqual(s.updateTime):s.exists===void 0||s.exists===e.isFoundDocument()}class fr{}function ra(s,e){if(!s.hasLocalMutations||e&&e.fields.length===0)return null;if(e===null)return s.isNoDocument()?new Is(s.key,le.none()):new pn(s.key,s.data,le.none());{const t=s.data,n=oe.empty();let r=new D(B.comparator);for(let i of e.fields)if(!r.has(i)){let o=t.field(i);o===null&&i.length>1&&(i=i.popLast(),o=t.field(i)),o===null?n.delete(i):n.set(i,o),r=r.add(i)}return new xt(s.key,n,new Te(r.toArray()),le.none())}}function tl(s,e,t){s instanceof pn?(function(r,i,o){const a=r.value.clone(),u=fi(r.fieldTransforms,i,o.transformResults);a.setAll(u),i.convertToFoundDocument(o.version,a).setHasCommittedMutations()})(s,e,t):s instanceof xt?(function(r,i,o){if(!Cn(r.precondition,i))return void i.convertToUnknownDocument(o.version);const a=fi(r.fieldTransforms,i,o.transformResults),u=i.data;u.setAll(sa(r)),u.setAll(a),i.convertToFoundDocument(o.version,u).setHasCommittedMutations()})(s,e,t):(function(r,i,o){i.convertToNoDocument(o.version).setHasCommittedMutations()})(0,e,t)}function Zt(s,e,t,n){return s instanceof pn?(function(i,o,a,u){if(!Cn(i.precondition,o))return a;const c=i.value.clone(),l=mi(i.fieldTransforms,u,o);return c.setAll(l),o.convertToFoundDocument(o.version,c).setHasLocalMutations(),null})(s,e,t,n):s instanceof xt?(function(i,o,a,u){if(!Cn(i.precondition,o))return a;const c=mi(i.fieldTransforms,u,o),l=o.data;return l.setAll(sa(i)),l.setAll(c),o.convertToFoundDocument(o.version,l).setHasLocalMutations(),a===null?null:a.unionWith(i.fieldMask.fields).unionWith(i.fieldTransforms.map((h=>h.field)))})(s,e,t,n):(function(i,o,a){return Cn(i.precondition,o)?(o.convertToNoDocument(o.version).setHasLocalMutations(),null):a})(s,e,t)}function di(s,e){return s.type===e.type&&!!s.key.isEqual(e.key)&&!!s.precondition.isEqual(e.precondition)&&!!(function(n,r){return n===void 0&&r===void 0||!(!n||!r)&&gt(n,r,((i,o)=>Zc(i,o)))})(s.fieldTransforms,e.fieldTransforms)&&(s.type===0?s.value.isEqual(e.value):s.type!==1||s.data.isEqual(e.data)&&s.fieldMask.isEqual(e.fieldMask))}class pn extends fr{constructor(e,t,n,r=[]){super(),this.key=e,this.value=t,this.precondition=n,this.fieldTransforms=r,this.type=0}getFieldMask(){return null}}class xt extends fr{constructor(e,t,n,r,i=[]){super(),this.key=e,this.data=t,this.fieldMask=n,this.precondition=r,this.fieldTransforms=i,this.type=1}getFieldMask(){return this.fieldMask}}function sa(s){const e=new Map;return s.fieldMask.fields.forEach((t=>{if(!t.isEmpty()){const n=s.data.field(t);e.set(t,n)}})),e}function fi(s,e,t){const n=new Map;T(s.length===t.length,32656,{Ve:t.length,de:s.length});for(let r=0;r<t.length;r++){const i=s[r],o=i.transform,a=e.data.field(i.field);n.set(i.field,Jc(o,a,t[r]))}return n}function mi(s,e,t){const n=new Map;for(const r of s){const i=r.transform,o=t.data.field(r.field);n.set(r.field,Hc(i,o,e))}return n}class Is extends fr{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=2,this.fieldTransforms=[]}getFieldMask(){return null}}class ia extends fr{constructor(e,t){super(),this.key=e,this.precondition=t,this.type=3,this.fieldTransforms=[]}getFieldMask(){return null}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ts{constructor(e,t,n,r){this.batchId=e,this.localWriteTime=t,this.baseMutations=n,this.mutations=r}applyToRemoteDocument(e,t){const n=t.mutationResults;for(let r=0;r<this.mutations.length;r++){const i=this.mutations[r];i.key.isEqual(e.key)&&tl(i,e,n[r])}}applyToLocalView(e,t){for(const n of this.baseMutations)n.key.isEqual(e.key)&&(t=Zt(n,e,t,this.localWriteTime));for(const n of this.mutations)n.key.isEqual(e.key)&&(t=Zt(n,e,t,this.localWriteTime));return t}applyToLocalDocumentSet(e,t){const n=Zo();return this.mutations.forEach((r=>{const i=e.get(r.key),o=i.overlayedDocument;let a=this.applyToLocalView(o,i.mutatedFields);a=t.has(r.key)?null:a;const u=ra(o,a);u!==null&&n.set(r.key,u),o.isValidDocument()||o.convertToNoDocument(A.min())})),n}keys(){return this.mutations.reduce(((e,t)=>e.add(t.key)),S())}isEqual(e){return this.batchId===e.batchId&&gt(this.mutations,e.mutations,((t,n)=>di(t,n)))&&gt(this.baseMutations,e.baseMutations,((t,n)=>di(t,n)))}}class Es{constructor(e,t,n,r){this.batch=e,this.commitVersion=t,this.mutationResults=n,this.docVersions=r}static from(e,t,n){T(e.mutations.length===n.length,58842,{me:e.mutations.length,fe:n.length});let r=(function(){return Gc})();const i=e.mutations;for(let o=0;o<i.length;o++)r=r.insert(i[o].key,n[o].version);return new Es(e,t,n,r)}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class As{constructor(e,t){this.largestBatchId=e,this.mutation=t}getKey(){return this.mutation.key}isEqual(e){return e!==null&&this.mutation===e.mutation}toString(){return`Overlay{
      largestBatchId: ${this.largestBatchId},
      mutation: ${this.mutation.toString()}
    }`}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class nl{constructor(e,t){this.count=e,this.unchangedNames=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var K,b;function rl(s){switch(s){case m.OK:return I(64938);case m.CANCELLED:case m.UNKNOWN:case m.DEADLINE_EXCEEDED:case m.RESOURCE_EXHAUSTED:case m.INTERNAL:case m.UNAVAILABLE:case m.UNAUTHENTICATED:return!1;case m.INVALID_ARGUMENT:case m.NOT_FOUND:case m.ALREADY_EXISTS:case m.PERMISSION_DENIED:case m.FAILED_PRECONDITION:case m.ABORTED:case m.OUT_OF_RANGE:case m.UNIMPLEMENTED:case m.DATA_LOSS:return!0;default:return I(15467,{code:s})}}function oa(s){if(s===void 0)return H("GRPC error has no .code"),m.UNKNOWN;switch(s){case K.OK:return m.OK;case K.CANCELLED:return m.CANCELLED;case K.UNKNOWN:return m.UNKNOWN;case K.DEADLINE_EXCEEDED:return m.DEADLINE_EXCEEDED;case K.RESOURCE_EXHAUSTED:return m.RESOURCE_EXHAUSTED;case K.INTERNAL:return m.INTERNAL;case K.UNAVAILABLE:return m.UNAVAILABLE;case K.UNAUTHENTICATED:return m.UNAUTHENTICATED;case K.INVALID_ARGUMENT:return m.INVALID_ARGUMENT;case K.NOT_FOUND:return m.NOT_FOUND;case K.ALREADY_EXISTS:return m.ALREADY_EXISTS;case K.PERMISSION_DENIED:return m.PERMISSION_DENIED;case K.FAILED_PRECONDITION:return m.FAILED_PRECONDITION;case K.ABORTED:return m.ABORTED;case K.OUT_OF_RANGE:return m.OUT_OF_RANGE;case K.UNIMPLEMENTED:return m.UNIMPLEMENTED;case K.DATA_LOSS:return m.DATA_LOSS;default:return I(39323,{code:s})}}(b=K||(K={}))[b.OK=0]="OK",b[b.CANCELLED=1]="CANCELLED",b[b.UNKNOWN=2]="UNKNOWN",b[b.INVALID_ARGUMENT=3]="INVALID_ARGUMENT",b[b.DEADLINE_EXCEEDED=4]="DEADLINE_EXCEEDED",b[b.NOT_FOUND=5]="NOT_FOUND",b[b.ALREADY_EXISTS=6]="ALREADY_EXISTS",b[b.PERMISSION_DENIED=7]="PERMISSION_DENIED",b[b.UNAUTHENTICATED=16]="UNAUTHENTICATED",b[b.RESOURCE_EXHAUSTED=8]="RESOURCE_EXHAUSTED",b[b.FAILED_PRECONDITION=9]="FAILED_PRECONDITION",b[b.ABORTED=10]="ABORTED",b[b.OUT_OF_RANGE=11]="OUT_OF_RANGE",b[b.UNIMPLEMENTED=12]="UNIMPLEMENTED",b[b.INTERNAL=13]="INTERNAL",b[b.UNAVAILABLE=14]="UNAVAILABLE",b[b.DATA_LOSS=15]="DATA_LOSS";/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function sl(){return new TextEncoder}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const il=new qe([4294967295,4294967295],0);function _i(s){const e=sl().encode(s),t=new Vu;return t.update(e),new Uint8Array(t.digest())}function gi(s){const e=new DataView(s.buffer),t=e.getUint32(0,!0),n=e.getUint32(4,!0),r=e.getUint32(8,!0),i=e.getUint32(12,!0);return[new qe([t,n],0),new qe([r,i],0)]}class ws{constructor(e,t,n){if(this.bitmap=e,this.padding=t,this.hashCount=n,t<0||t>=8)throw new Gt(`Invalid padding: ${t}`);if(n<0)throw new Gt(`Invalid hash count: ${n}`);if(e.length>0&&this.hashCount===0)throw new Gt(`Invalid hash count: ${n}`);if(e.length===0&&t!==0)throw new Gt(`Invalid padding when bitmap length is 0: ${t}`);this.ge=8*e.length-t,this.pe=qe.fromNumber(this.ge)}ye(e,t,n){let r=e.add(t.multiply(qe.fromNumber(n)));return r.compare(il)===1&&(r=new qe([r.getBits(0),r.getBits(1)],0)),r.modulo(this.pe).toNumber()}we(e){return!!(this.bitmap[Math.floor(e/8)]&1<<e%8)}mightContain(e){if(this.ge===0)return!1;const t=_i(e),[n,r]=gi(t);for(let i=0;i<this.hashCount;i++){const o=this.ye(n,r,i);if(!this.we(o))return!1}return!0}static create(e,t,n){const r=e%8==0?0:8-e%8,i=new Uint8Array(Math.ceil(e/8)),o=new ws(i,r,t);return n.forEach((a=>o.insert(a))),o}insert(e){if(this.ge===0)return;const t=_i(e),[n,r]=gi(t);for(let i=0;i<this.hashCount;i++){const o=this.ye(n,r,i);this.Se(o)}}Se(e){const t=Math.floor(e/8),n=e%8;this.bitmap[t]|=1<<n}}class Gt extends Error{constructor(){super(...arguments),this.name="BloomFilterError"}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Dt{constructor(e,t,n,r,i){this.snapshotVersion=e,this.targetChanges=t,this.targetMismatches=n,this.documentUpdates=r,this.resolvedLimboDocuments=i}static createSynthesizedRemoteEventForCurrentChange(e,t,n){const r=new Map;return r.set(e,yn.createSynthesizedTargetChangeForCurrentChange(e,t,n)),new Dt(A.min(),r,new k(V),ae(),S())}}class yn{constructor(e,t,n,r,i){this.resumeToken=e,this.current=t,this.addedDocuments=n,this.modifiedDocuments=r,this.removedDocuments=i}static createSynthesizedTargetChangeForCurrentChange(e,t,n){return new yn(n,t,S(),S(),S())}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Nn{constructor(e,t,n,r){this.be=e,this.removedTargetIds=t,this.key=n,this.De=r}}class aa{constructor(e,t){this.targetId=e,this.Ce=t}}class ua{constructor(e,t,n=U.EMPTY_BYTE_STRING,r=null){this.state=e,this.targetIds=t,this.resumeToken=n,this.cause=r}}class pi{constructor(){this.ve=0,this.Fe=yi(),this.Me=U.EMPTY_BYTE_STRING,this.xe=!1,this.Oe=!0}get current(){return this.xe}get resumeToken(){return this.Me}get Ne(){return this.ve!==0}get Be(){return this.Oe}Le(e){e.approximateByteSize()>0&&(this.Oe=!0,this.Me=e)}ke(){let e=S(),t=S(),n=S();return this.Fe.forEach(((r,i)=>{switch(i){case 0:e=e.add(r);break;case 2:t=t.add(r);break;case 1:n=n.add(r);break;default:I(38017,{changeType:i})}})),new yn(this.Me,this.xe,e,t,n)}Ke(){this.Oe=!1,this.Fe=yi()}qe(e,t){this.Oe=!0,this.Fe=this.Fe.insert(e,t)}Ue(e){this.Oe=!0,this.Fe=this.Fe.remove(e)}$e(){this.ve+=1}We(){this.ve-=1,T(this.ve>=0,3241,{ve:this.ve})}Qe(){this.Oe=!0,this.xe=!0}}class ol{constructor(e){this.Ge=e,this.ze=new Map,this.je=ae(),this.Je=An(),this.He=An(),this.Ze=new k(V)}Xe(e){for(const t of e.be)e.De&&e.De.isFoundDocument()?this.Ye(t,e.De):this.et(t,e.key,e.De);for(const t of e.removedTargetIds)this.et(t,e.key,e.De)}tt(e){this.forEachTarget(e,(t=>{const n=this.nt(t);switch(e.state){case 0:this.rt(t)&&n.Le(e.resumeToken);break;case 1:n.We(),n.Ne||n.Ke(),n.Le(e.resumeToken);break;case 2:n.We(),n.Ne||this.removeTarget(t);break;case 3:this.rt(t)&&(n.Qe(),n.Le(e.resumeToken));break;case 4:this.rt(t)&&(this.it(t),n.Le(e.resumeToken));break;default:I(56790,{state:e.state})}}))}forEachTarget(e,t){e.targetIds.length>0?e.targetIds.forEach(t):this.ze.forEach(((n,r)=>{this.rt(r)&&t(r)}))}st(e){const t=e.targetId,n=e.Ce.count,r=this.ot(t);if(r){const i=r.target;if($n(i))if(n===0){const o=new p(i.path);this.et(t,o,F.newNoDocument(o,A.min()))}else T(n===1,20013,{expectedCount:n});else{const o=this._t(t);if(o!==n){const a=this.ut(e),u=a?this.ct(a,e,o):1;if(u!==0){this.it(t);const c=u===2?"TargetPurposeExistenceFilterMismatchBloom":"TargetPurposeExistenceFilterMismatch";this.Ze=this.Ze.insert(t,c)}}}}}ut(e){const t=e.Ce.unchangedNames;if(!t||!t.bits)return null;const{bits:{bitmap:n="",padding:r=0},hashCount:i=0}=t;let o,a;try{o=We(n).toUint8Array()}catch(u){if(u instanceof xo)return _t("Decoding the base64 bloom filter in existence filter failed ("+u.message+"); ignoring the bloom filter and falling back to full re-query."),null;throw u}try{a=new ws(o,r,i)}catch(u){return _t(u instanceof Gt?"BloomFilter error: ":"Applying bloom filter failed: ",u),null}return a.ge===0?null:a}ct(e,t,n){return t.Ce.count===n-this.Pt(e,t.targetId)?0:2}Pt(e,t){const n=this.Ge.getRemoteKeysForTarget(t);let r=0;return n.forEach((i=>{const o=this.Ge.ht(),a=`projects/${o.projectId}/databases/${o.database}/documents/${i.path.canonicalString()}`;e.mightContain(a)||(this.et(t,i,null),r++)})),r}Tt(e){const t=new Map;this.ze.forEach(((i,o)=>{const a=this.ot(o);if(a){if(i.current&&$n(a.target)){const u=new p(a.target.path);this.It(u).has(o)||this.Et(o,u)||this.et(o,u,F.newNoDocument(u,e))}i.Be&&(t.set(o,i.ke()),i.Ke())}}));let n=S();this.He.forEach(((i,o)=>{let a=!0;o.forEachWhile((u=>{const c=this.ot(u);return!c||c.purpose==="TargetPurposeLimboResolution"||(a=!1,!1)})),a&&(n=n.add(i))})),this.je.forEach(((i,o)=>o.setReadTime(e)));const r=new Dt(e,t,this.Ze,this.je,n);return this.je=ae(),this.Je=An(),this.He=An(),this.Ze=new k(V),r}Ye(e,t){if(!this.rt(e))return;const n=this.Et(e,t.key)?2:0;this.nt(e).qe(t.key,n),this.je=this.je.insert(t.key,t),this.Je=this.Je.insert(t.key,this.It(t.key).add(e)),this.He=this.He.insert(t.key,this.Rt(t.key).add(e))}et(e,t,n){if(!this.rt(e))return;const r=this.nt(e);this.Et(e,t)?r.qe(t,1):r.Ue(t),this.He=this.He.insert(t,this.Rt(t).delete(e)),this.He=this.He.insert(t,this.Rt(t).add(e)),n&&(this.je=this.je.insert(t,n))}removeTarget(e){this.ze.delete(e)}_t(e){const t=this.nt(e).ke();return this.Ge.getRemoteKeysForTarget(e).size+t.addedDocuments.size-t.removedDocuments.size}$e(e){this.nt(e).$e()}nt(e){let t=this.ze.get(e);return t||(t=new pi,this.ze.set(e,t)),t}Rt(e){let t=this.He.get(e);return t||(t=new D(V),this.He=this.He.insert(e,t)),t}It(e){let t=this.Je.get(e);return t||(t=new D(V),this.Je=this.Je.insert(e,t)),t}rt(e){const t=this.ot(e)!==null;return t||g("WatchChangeAggregator","Detected inactive target",e),t}ot(e){const t=this.ze.get(e);return t&&t.Ne?null:this.Ge.At(e)}it(e){this.ze.set(e,new pi),this.Ge.getRemoteKeysForTarget(e).forEach((t=>{this.et(e,t,null)}))}Et(e,t){return this.Ge.getRemoteKeysForTarget(e).has(t)}}function An(){return new k(p.comparator)}function yi(){return new k(p.comparator)}const al={asc:"ASCENDING",desc:"DESCENDING"},ul={"<":"LESS_THAN","<=":"LESS_THAN_OR_EQUAL",">":"GREATER_THAN",">=":"GREATER_THAN_OR_EQUAL","==":"EQUAL","!=":"NOT_EQUAL","array-contains":"ARRAY_CONTAINS",in:"IN","not-in":"NOT_IN","array-contains-any":"ARRAY_CONTAINS_ANY"},cl={and:"AND",or:"OR"};class ll{constructor(e,t){this.databaseId=e,this.useProto3Json=t}}function zr(s,e){return s.useProto3Json||or(e)?e:{value:e}}function Qn(s,e){return s.useProto3Json?`${new Date(1e3*e.seconds).toISOString().replace(/\.\d*/,"").replace("Z","")}.${("000000000"+e.nanoseconds).slice(-9)}Z`:{seconds:""+e.seconds,nanos:e.nanoseconds}}function hl(s,e){return s.useProto3Json?e.toBase64():e.toUint8Array()}function dl(s,e){return Qn(s,e.toTimestamp())}function te(s){return T(!!s,49232),A.fromTimestamp((function(t){const n=be(t);return new O(n.seconds,n.nanos)})(s))}function ca(s,e){return Kr(s,e).canonicalString()}function Kr(s,e){const t=(function(r){return new M(["projects",r.projectId,"databases",r.database])})(s).child("documents");return e===void 0?t:t.child(e)}function la(s){const e=M.fromString(s);return T(El(e),10190,{key:e.toString()}),e}function Wn(s,e){return ca(s.databaseId,e.path)}function Ge(s,e){const t=la(e);if(t.get(1)!==s.databaseId.projectId)throw new y(m.INVALID_ARGUMENT,"Tried to deserialize key from different project: "+t.get(1)+" vs "+s.databaseId.projectId);if(t.get(3)!==s.databaseId.database)throw new y(m.INVALID_ARGUMENT,"Tried to deserialize key from different database: "+t.get(3)+" vs "+s.databaseId.database);return new p(fa(t))}function ha(s,e){return ca(s.databaseId,e)}function da(s){const e=la(s);return e.length===4?M.emptyPath():fa(e)}function Gr(s){return new M(["projects",s.databaseId.projectId,"databases",s.databaseId.database]).canonicalString()}function fa(s){return T(s.length>4&&s.get(4)==="documents",29091,{key:s.toString()}),s.popFirst(5)}function Ii(s,e,t){return{name:Wn(s,e),fields:t.value.mapValue.fields}}function fl(s,e,t){const n=Ge(s,e.name),r=te(e.updateTime),i=e.createTime?te(e.createTime):A.min(),o=new oe({mapValue:{fields:e.fields}}),a=F.newFoundDocument(n,r,i,o);return t&&a.setHasCommittedMutations(),t?a.setHasCommittedMutations():a}function ml(s,e){let t;if("targetChange"in e){e.targetChange;const n=(function(c){return c==="NO_CHANGE"?0:c==="ADD"?1:c==="REMOVE"?2:c==="CURRENT"?3:c==="RESET"?4:I(39313,{state:c})})(e.targetChange.targetChangeType||"NO_CHANGE"),r=e.targetChange.targetIds||[],i=(function(c,l){return c.useProto3Json?(T(l===void 0||typeof l=="string",58123),U.fromBase64String(l||"")):(T(l===void 0||l instanceof Buffer||l instanceof Uint8Array,16193),U.fromUint8Array(l||new Uint8Array))})(s,e.targetChange.resumeToken),o=e.targetChange.cause,a=o&&(function(c){const l=c.code===void 0?m.UNKNOWN:oa(c.code);return new y(l,c.message||"")})(o);t=new ua(n,r,i,a||null)}else if("documentChange"in e){e.documentChange;const n=e.documentChange;n.document,n.document.name,n.document.updateTime;const r=Ge(s,n.document.name),i=te(n.document.updateTime),o=n.document.createTime?te(n.document.createTime):A.min(),a=new oe({mapValue:{fields:n.document.fields}}),u=F.newFoundDocument(r,i,o,a),c=n.targetIds||[],l=n.removedTargetIds||[];t=new Nn(c,l,u.key,u)}else if("documentDelete"in e){e.documentDelete;const n=e.documentDelete;n.document;const r=Ge(s,n.document),i=n.readTime?te(n.readTime):A.min(),o=F.newNoDocument(r,i),a=n.removedTargetIds||[];t=new Nn([],a,o.key,o)}else if("documentRemove"in e){e.documentRemove;const n=e.documentRemove;n.document;const r=Ge(s,n.document),i=n.removedTargetIds||[];t=new Nn([],i,r,null)}else{if(!("filter"in e))return I(11601,{Vt:e});{e.filter;const n=e.filter;n.targetId;const{count:r=0,unchangedNames:i}=n,o=new nl(r,i),a=n.targetId;t=new aa(a,o)}}return t}function Hn(s,e){let t;if(e instanceof pn)t={update:Ii(s,e.key,e.value)};else if(e instanceof Is)t={delete:Wn(s,e.key)};else if(e instanceof xt)t={update:Ii(s,e.key,e.data),updateMask:Tl(e.fieldMask)};else{if(!(e instanceof ia))return I(16599,{dt:e.type});t={verify:Wn(s,e.key)}}return e.fieldTransforms.length>0&&(t.updateTransforms=e.fieldTransforms.map((n=>(function(i,o){const a=o.transform;if(a instanceof hn)return{fieldPath:o.field.canonicalString(),setToServerValue:"REQUEST_TIME"};if(a instanceof St)return{fieldPath:o.field.canonicalString(),appendMissingElements:{values:a.elements}};if(a instanceof Pt)return{fieldPath:o.field.canonicalString(),removeAllFromArray:{values:a.elements}};if(a instanceof dn)return{fieldPath:o.field.canonicalString(),increment:a.Ae};throw I(20930,{transform:o.transform})})(0,n)))),e.precondition.isNone||(t.currentDocument=(function(r,i){return i.updateTime!==void 0?{updateTime:dl(r,i.updateTime)}:i.exists!==void 0?{exists:i.exists}:I(27497)})(s,e.precondition)),t}function $r(s,e){const t=e.currentDocument?(function(i){return i.updateTime!==void 0?le.updateTime(te(i.updateTime)):i.exists!==void 0?le.exists(i.exists):le.none()})(e.currentDocument):le.none(),n=e.updateTransforms?e.updateTransforms.map((r=>(function(o,a){let u=null;if("setToServerValue"in a)T(a.setToServerValue==="REQUEST_TIME",16630,{proto:a}),u=new hn;else if("appendMissingElements"in a){const l=a.appendMissingElements.values||[];u=new St(l)}else if("removeAllFromArray"in a){const l=a.removeAllFromArray.values||[];u=new Pt(l)}else"increment"in a?u=new dn(o,a.increment):I(16584,{proto:a});const c=B.fromServerFormat(a.fieldPath);return new Xc(c,u)})(s,r))):[];if(e.update){e.update.name;const r=Ge(s,e.update.name),i=new oe({mapValue:{fields:e.update.fields}});if(e.updateMask){const o=(function(u){const c=u.fieldPaths||[];return new Te(c.map((l=>B.fromServerFormat(l))))})(e.updateMask);return new xt(r,i,o,t,n)}return new pn(r,i,t,n)}if(e.delete){const r=Ge(s,e.delete);return new Is(r,t)}if(e.verify){const r=Ge(s,e.verify);return new ia(r,t)}return I(1463,{proto:e})}function _l(s,e){return s&&s.length>0?(T(e!==void 0,14353),s.map((t=>(function(r,i){let o=r.updateTime?te(r.updateTime):te(i);return o.isEqual(A.min())&&(o=te(i)),new el(o,r.transformResults||[])})(t,e)))):[]}function ma(s,e){return{documents:[ha(s,e.path)]}}function _a(s,e){const t={structuredQuery:{}},n=e.path;let r;e.collectionGroup!==null?(r=n,t.structuredQuery.from=[{collectionId:e.collectionGroup,allDescendants:!0}]):(r=n.popLast(),t.structuredQuery.from=[{collectionId:n.lastSegment()}]),t.parent=ha(s,r);const i=(function(c){if(c.length!==0)return ya(C.create(c,"and"))})(e.filters);i&&(t.structuredQuery.where=i);const o=(function(c){if(c.length!==0)return c.map((l=>(function(f){return{field:ut(f.field),direction:pl(f.dir)}})(l)))})(e.orderBy);o&&(t.structuredQuery.orderBy=o);const a=zr(s,e.limit);return a!==null&&(t.structuredQuery.limit=a),e.startAt&&(t.structuredQuery.startAt=(function(c){return{before:c.inclusive,values:c.position}})(e.startAt)),e.endAt&&(t.structuredQuery.endAt=(function(c){return{before:!c.inclusive,values:c.position}})(e.endAt)),{ft:t,parent:r}}function ga(s){let e=da(s.parent);const t=s.structuredQuery,n=t.from?t.from.length:0;let r=null;if(n>0){T(n===1,65062);const l=t.from[0];l.allDescendants?r=l.collectionId:e=e.child(l.collectionId)}let i=[];t.where&&(i=(function(h){const f=pa(h);return f instanceof C&&_s(f)?f.getFilters():[f]})(t.where));let o=[];t.orderBy&&(o=(function(h){return h.map((f=>(function(R){return new Gn(ct(R.field),(function(v){switch(v){case"ASCENDING":return"asc";case"DESCENDING":return"desc";default:return}})(R.direction))})(f)))})(t.orderBy));let a=null;t.limit&&(a=(function(h){let f;return f=typeof h=="object"?h.value:h,or(f)?null:f})(t.limit));let u=null;t.startAt&&(u=(function(h){const f=!!h.before,_=h.values||[];return new vt(_,f)})(t.startAt));let c=null;return t.endAt&&(c=(function(h){const f=!h.before,_=h.values||[];return new vt(_,f)})(t.endAt)),Wo(e,r,o,i,a,"F",u,c)}function gl(s,e){const t=(function(r){switch(r){case"TargetPurposeListen":return null;case"TargetPurposeExistenceFilterMismatch":return"existence-filter-mismatch";case"TargetPurposeExistenceFilterMismatchBloom":return"existence-filter-mismatch-bloom";case"TargetPurposeLimboResolution":return"limbo-document";default:return I(28987,{purpose:r})}})(e.purpose);return t==null?null:{"goog-listen-tags":t}}function pa(s){return s.unaryFilter!==void 0?(function(t){switch(t.unaryFilter.op){case"IS_NAN":const n=ct(t.unaryFilter.field);return P.create(n,"==",{doubleValue:NaN});case"IS_NULL":const r=ct(t.unaryFilter.field);return P.create(r,"==",{nullValue:"NULL_VALUE"});case"IS_NOT_NAN":const i=ct(t.unaryFilter.field);return P.create(i,"!=",{doubleValue:NaN});case"IS_NOT_NULL":const o=ct(t.unaryFilter.field);return P.create(o,"!=",{nullValue:"NULL_VALUE"});case"OPERATOR_UNSPECIFIED":return I(61313);default:return I(60726)}})(s):s.fieldFilter!==void 0?(function(t){return P.create(ct(t.fieldFilter.field),(function(r){switch(r){case"EQUAL":return"==";case"NOT_EQUAL":return"!=";case"GREATER_THAN":return">";case"GREATER_THAN_OR_EQUAL":return">=";case"LESS_THAN":return"<";case"LESS_THAN_OR_EQUAL":return"<=";case"ARRAY_CONTAINS":return"array-contains";case"IN":return"in";case"NOT_IN":return"not-in";case"ARRAY_CONTAINS_ANY":return"array-contains-any";case"OPERATOR_UNSPECIFIED":return I(58110);default:return I(50506)}})(t.fieldFilter.op),t.fieldFilter.value)})(s):s.compositeFilter!==void 0?(function(t){return C.create(t.compositeFilter.filters.map((n=>pa(n))),(function(r){switch(r){case"AND":return"and";case"OR":return"or";default:return I(1026)}})(t.compositeFilter.op))})(s):I(30097,{filter:s})}function pl(s){return al[s]}function yl(s){return ul[s]}function Il(s){return cl[s]}function ut(s){return{fieldPath:s.canonicalString()}}function ct(s){return B.fromServerFormat(s.fieldPath)}function ya(s){return s instanceof P?(function(t){if(t.op==="=="){if(ri(t.value))return{unaryFilter:{field:ut(t.field),op:"IS_NAN"}};if(ni(t.value))return{unaryFilter:{field:ut(t.field),op:"IS_NULL"}}}else if(t.op==="!="){if(ri(t.value))return{unaryFilter:{field:ut(t.field),op:"IS_NOT_NAN"}};if(ni(t.value))return{unaryFilter:{field:ut(t.field),op:"IS_NOT_NULL"}}}return{fieldFilter:{field:ut(t.field),op:yl(t.op),value:t.value}}})(s):s instanceof C?(function(t){const n=t.getFilters().map((r=>ya(r)));return n.length===1?n[0]:{compositeFilter:{op:Il(t.op),filters:n}}})(s):I(54877,{filter:s})}function Tl(s){const e=[];return s.fields.forEach((t=>e.push(t.canonicalString()))),{fieldPaths:e}}function El(s){return s.length>=4&&s.get(0)==="projects"&&s.get(2)==="databases"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class _e{constructor(e,t,n,r,i=A.min(),o=A.min(),a=U.EMPTY_BYTE_STRING,u=null){this.target=e,this.targetId=t,this.purpose=n,this.sequenceNumber=r,this.snapshotVersion=i,this.lastLimboFreeSnapshotVersion=o,this.resumeToken=a,this.expectedCount=u}withSequenceNumber(e){return new _e(this.target,this.targetId,this.purpose,e,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,this.expectedCount)}withResumeToken(e,t){return new _e(this.target,this.targetId,this.purpose,this.sequenceNumber,t,this.lastLimboFreeSnapshotVersion,e,null)}withExpectedCount(e){return new _e(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,this.lastLimboFreeSnapshotVersion,this.resumeToken,e)}withLastLimboFreeSnapshotVersion(e){return new _e(this.target,this.targetId,this.purpose,this.sequenceNumber,this.snapshotVersion,e,this.resumeToken,this.expectedCount)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ia{constructor(e){this.yt=e}}function Al(s,e){let t;if(e.document)t=fl(s.yt,e.document,!!e.hasCommittedMutations);else if(e.noDocument){const n=p.fromSegments(e.noDocument.path),r=Ye(e.noDocument.readTime);t=F.newNoDocument(n,r),e.hasCommittedMutations&&t.setHasCommittedMutations()}else{if(!e.unknownDocument)return I(56709);{const n=p.fromSegments(e.unknownDocument.path),r=Ye(e.unknownDocument.version);t=F.newUnknownDocument(n,r)}}return e.readTime&&t.setReadTime((function(r){const i=new O(r[0],r[1]);return A.fromTimestamp(i)})(e.readTime)),t}function Ti(s,e){const t=e.key,n={prefixPath:t.getCollectionPath().popLast().toArray(),collectionGroup:t.collectionGroup,documentId:t.path.lastSegment(),readTime:Jn(e.readTime),hasCommittedMutations:e.hasCommittedMutations};if(e.isFoundDocument())n.document=(function(i,o){return{name:Wn(i,o.key),fields:o.data.value.mapValue.fields,updateTime:Qn(i,o.version.toTimestamp()),createTime:Qn(i,o.createTime.toTimestamp())}})(s.yt,e);else if(e.isNoDocument())n.noDocument={path:t.path.toArray(),readTime:Je(e.version)};else{if(!e.isUnknownDocument())return I(57904,{document:e});n.unknownDocument={path:t.path.toArray(),version:Je(e.version)}}return n}function Jn(s){const e=s.toTimestamp();return[e.seconds,e.nanoseconds]}function Je(s){const e=s.toTimestamp();return{seconds:e.seconds,nanoseconds:e.nanoseconds}}function Ye(s){const e=new O(s.seconds,s.nanoseconds);return A.fromTimestamp(e)}function Fe(s,e){const t=(e.baseMutations||[]).map((i=>$r(s.yt,i)));for(let i=0;i<e.mutations.length-1;++i){const o=e.mutations[i];if(i+1<e.mutations.length&&e.mutations[i+1].transform!==void 0){const a=e.mutations[i+1];o.updateTransforms=a.transform.fieldTransforms,e.mutations.splice(i+1,1),++i}}const n=e.mutations.map((i=>$r(s.yt,i))),r=O.fromMillis(e.localWriteTimeMs);return new Ts(e.batchId,r,t,n)}function $t(s){const e=Ye(s.readTime),t=s.lastLimboFreeSnapshotVersion!==void 0?Ye(s.lastLimboFreeSnapshotVersion):A.min();let n;return n=(function(i){return i.documents!==void 0})(s.query)?(function(i){const o=i.documents.length;return T(o===1,1966,{count:o}),ue(gs(da(i.documents[0])))})(s.query):(function(i){return ue(ga(i))})(s.query),new _e(n,s.targetId,"TargetPurposeListen",s.lastListenSequenceNumber,e,t,U.fromBase64String(s.resumeToken))}function Ta(s,e){const t=Je(e.snapshotVersion),n=Je(e.lastLimboFreeSnapshotVersion);let r;r=$n(e.target)?ma(s.yt,e.target):_a(s.yt,e.target).ft;const i=e.resumeToken.toBase64();return{targetId:e.targetId,canonicalId:He(e.target),readTime:t,resumeToken:i,lastListenSequenceNumber:e.sequenceNumber,lastLimboFreeSnapshotVersion:n,query:r}}function Ea(s){const e=ga({parent:s.parent,structuredQuery:s.structuredQuery});return s.limitType==="LAST"?qr(e,e.limit,"L"):e}function wr(s,e){return new As(e.largestBatchId,$r(s.yt,e.overlayMutation))}function Ei(s,e){const t=e.path.lastSegment();return[s,ee(e.path.popLast()),t]}function Ai(s,e,t,n){return{indexId:s,uid:e,sequenceNumber:t,readTime:Je(n.readTime),documentKey:ee(n.documentKey.path),largestBatchId:n.largestBatchId}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class wl{getBundleMetadata(e,t){return wi(e).get(t).next((n=>{if(n)return(function(i){return{id:i.bundleId,createTime:Ye(i.createTime),version:i.version}})(n)}))}saveBundleMetadata(e,t){return wi(e).put((function(r){return{bundleId:r.id,createTime:Je(te(r.createTime)),version:r.version}})(t))}getNamedQuery(e,t){return Ri(e).get(t).next((n=>{if(n)return(function(i){return{name:i.name,query:Ea(i.bundledQuery),readTime:Ye(i.readTime)}})(n)}))}saveNamedQuery(e,t){return Ri(e).put((function(r){return{name:r.name,readTime:Je(te(r.readTime)),bundledQuery:r.bundledQuery}})(t))}}function wi(s){return Q(s,ar)}function Ri(s){return Q(s,ur)}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mr{constructor(e,t){this.serializer=e,this.userId=t}static wt(e,t){const n=t.uid||"";return new mr(e,n)}getOverlay(e,t){return Ft(e).get(Ei(this.userId,t)).next((n=>n?wr(this.serializer,n):null))}getOverlays(e,t){const n=me();return d.forEach(t,(r=>this.getOverlay(e,r).next((i=>{i!==null&&n.set(r,i)})))).next((()=>n))}saveOverlays(e,t,n){const r=[];return n.forEach(((i,o)=>{const a=new As(t,o);r.push(this.St(e,a))})),d.waitFor(r)}removeOverlaysForBatchId(e,t,n){const r=new Set;t.forEach((o=>r.add(ee(o.getCollectionPath()))));const i=[];return r.forEach((o=>{const a=IDBKeyRange.bound([this.userId,o,n],[this.userId,o,n+1],!1,!0);i.push(Ft(e).X(kr,a))})),d.waitFor(i)}getOverlaysForCollection(e,t,n){const r=me(),i=ee(t),o=IDBKeyRange.bound([this.userId,i,n],[this.userId,i,Number.POSITIVE_INFINITY],!0);return Ft(e).J(kr,o).next((a=>{for(const u of a){const c=wr(this.serializer,u);r.set(c.getKey(),c)}return r}))}getOverlaysForCollectionGroup(e,t,n,r){const i=me();let o;const a=IDBKeyRange.bound([this.userId,t,n],[this.userId,t,Number.POSITIVE_INFINITY],!0);return Ft(e).ee({index:vo,range:a},((u,c,l)=>{const h=wr(this.serializer,c);i.size()<r||h.largestBatchId===o?(i.set(h.getKey(),h),o=h.largestBatchId):l.done()})).next((()=>i))}St(e,t){return Ft(e).put((function(r,i,o){const[a,u,c]=Ei(i,o.mutation.key);return{userId:i,collectionPath:u,documentId:c,collectionGroup:o.mutation.key.getCollectionGroup(),largestBatchId:o.largestBatchId,overlayMutation:Hn(r.yt,o.mutation)}})(this.serializer,this.userId,t))}}function Ft(s){return Q(s,cr)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Rl{bt(e){return Q(e,ls)}getSessionToken(e){return this.bt(e).get("sessionToken").next((t=>{const n=t?.value;return n?U.fromUint8Array(n):U.EMPTY_BYTE_STRING}))}setSessionToken(e,t){return this.bt(e).put({name:"sessionToken",value:t.toUint8Array()})}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Le{constructor(){}Dt(e,t){this.Ct(e,t),t.vt()}Ct(e,t){if("nullValue"in e)this.Ft(t,5);else if("booleanValue"in e)this.Ft(t,10),t.Mt(e.booleanValue?1:0);else if("integerValue"in e)this.Ft(t,15),t.Mt(G(e.integerValue));else if("doubleValue"in e){const n=G(e.doubleValue);isNaN(n)?this.Ft(t,13):(this.Ft(t,15),rn(n)?t.Mt(0):t.Mt(n))}else if("timestampValue"in e){let n=e.timestampValue;this.Ft(t,20),typeof n=="string"&&(n=be(n)),t.xt(`${n.seconds||""}`),t.Mt(n.nanos||0)}else if("stringValue"in e)this.Ot(e.stringValue,t),this.Nt(t);else if("bytesValue"in e)this.Ft(t,30),t.Bt(We(e.bytesValue)),this.Nt(t);else if("referenceValue"in e)this.Lt(e.referenceValue,t);else if("geoPointValue"in e){const n=e.geoPointValue;this.Ft(t,45),t.Mt(n.latitude||0),t.Mt(n.longitude||0)}else"mapValue"in e?Bo(e)?this.Ft(t,Number.MAX_SAFE_INTEGER):lr(e)?this.kt(e.mapValue,t):(this.Kt(e.mapValue,t),this.Nt(t)):"arrayValue"in e?(this.qt(e.arrayValue,t),this.Nt(t)):I(19022,{Ut:e})}Ot(e,t){this.Ft(t,25),this.$t(e,t)}$t(e,t){t.xt(e)}Kt(e,t){const n=e.fields||{};this.Ft(t,55);for(const r of Object.keys(n))this.Ot(r,t),this.Ct(n[r],t)}kt(e,t){const n=e.fields||{};this.Ft(t,53);const r=Kn,i=n[r].arrayValue?.values?.length||0;this.Ft(t,15),t.Mt(G(i)),this.Ot(r,t),this.Ct(n[r],t)}qt(e,t){const n=e.values||[];this.Ft(t,50);for(const r of n)this.Ct(r,t)}Lt(e,t){this.Ft(t,37),p.fromName(e).path.forEach((n=>{this.Ft(t,60),this.$t(n,t)}))}Ft(e,t){e.Mt(t)}Nt(e){e.Mt(2)}}Le.Wt=new Le;/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law | agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES | CONDITIONS OF ANY KIND, either express | implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const rt=255;function vl(s){if(s===0)return 8;let e=0;return s>>4||(e+=4,s<<=4),s>>6||(e+=2,s<<=2),s>>7||(e+=1),e}function vi(s){const e=64-(function(n){let r=0;for(let i=0;i<8;++i){const o=vl(255&n[i]);if(r+=o,o!==8)break}return r})(s);return Math.ceil(e/8)}class Vl{constructor(){this.buffer=new Uint8Array(1024),this.position=0}Qt(e){const t=e[Symbol.iterator]();let n=t.next();for(;!n.done;)this.Gt(n.value),n=t.next();this.zt()}jt(e){const t=e[Symbol.iterator]();let n=t.next();for(;!n.done;)this.Jt(n.value),n=t.next();this.Ht()}Zt(e){for(const t of e){const n=t.charCodeAt(0);if(n<128)this.Gt(n);else if(n<2048)this.Gt(960|n>>>6),this.Gt(128|63&n);else if(t<"\uD800"||"\uDBFF"<t)this.Gt(480|n>>>12),this.Gt(128|63&n>>>6),this.Gt(128|63&n);else{const r=t.codePointAt(0);this.Gt(240|r>>>18),this.Gt(128|63&r>>>12),this.Gt(128|63&r>>>6),this.Gt(128|63&r)}}this.zt()}Xt(e){for(const t of e){const n=t.charCodeAt(0);if(n<128)this.Jt(n);else if(n<2048)this.Jt(960|n>>>6),this.Jt(128|63&n);else if(t<"\uD800"||"\uDBFF"<t)this.Jt(480|n>>>12),this.Jt(128|63&n>>>6),this.Jt(128|63&n);else{const r=t.codePointAt(0);this.Jt(240|r>>>18),this.Jt(128|63&r>>>12),this.Jt(128|63&r>>>6),this.Jt(128|63&r)}}this.Ht()}Yt(e){const t=this.en(e),n=vi(t);this.tn(1+n),this.buffer[this.position++]=255&n;for(let r=t.length-n;r<t.length;++r)this.buffer[this.position++]=255&t[r]}nn(e){const t=this.en(e),n=vi(t);this.tn(1+n),this.buffer[this.position++]=~(255&n);for(let r=t.length-n;r<t.length;++r)this.buffer[this.position++]=~(255&t[r])}rn(){this.sn(rt),this.sn(255)}_n(){this.an(rt),this.an(255)}reset(){this.position=0}seed(e){this.tn(e.length),this.buffer.set(e,this.position),this.position+=e.length}un(){return this.buffer.slice(0,this.position)}en(e){const t=(function(i){const o=new DataView(new ArrayBuffer(8));return o.setFloat64(0,i,!1),new Uint8Array(o.buffer)})(e),n=!!(128&t[0]);t[0]^=n?255:128;for(let r=1;r<t.length;++r)t[r]^=n?255:0;return t}Gt(e){const t=255&e;t===0?(this.sn(0),this.sn(255)):t===rt?(this.sn(rt),this.sn(0)):this.sn(t)}Jt(e){const t=255&e;t===0?(this.an(0),this.an(255)):t===rt?(this.an(rt),this.an(0)):this.an(e)}zt(){this.sn(0),this.sn(1)}Ht(){this.an(0),this.an(1)}sn(e){this.tn(1),this.buffer[this.position++]=e}an(e){this.tn(1),this.buffer[this.position++]=~e}tn(e){const t=e+this.position;if(t<=this.buffer.length)return;let n=2*this.buffer.length;n<t&&(n=t);const r=new Uint8Array(n);r.set(this.buffer),this.buffer=r}}class Sl{constructor(e){this.cn=e}Bt(e){this.cn.Qt(e)}xt(e){this.cn.Zt(e)}Mt(e){this.cn.Yt(e)}vt(){this.cn.rn()}}class Pl{constructor(e){this.cn=e}Bt(e){this.cn.jt(e)}xt(e){this.cn.Xt(e)}Mt(e){this.cn.nn(e)}vt(){this.cn._n()}}class Lt{constructor(){this.cn=new Vl,this.ascending=new Sl(this.cn),this.descending=new Pl(this.cn)}seed(e){this.cn.seed(e)}ln(e){return e===0?this.ascending:this.descending}un(){return this.cn.un()}reset(){this.cn.reset()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Be{constructor(e,t,n,r){this.hn=e,this.Pn=t,this.Tn=n,this.In=r}En(){const e=this.In.length,t=e===0||this.In[e-1]===255?e+1:e,n=new Uint8Array(t);return n.set(this.In,0),t!==e?n.set([0],this.In.length):++n[n.length-1],new Be(this.hn,this.Pn,this.Tn,n)}Rn(e,t,n){return{indexId:this.hn,uid:e,arrayValue:kn(this.Tn),directionalValue:kn(this.In),orderedDocumentKey:kn(t),documentKey:n.path.toArray()}}An(e,t,n){const r=this.Rn(e,t,n);return[r.indexId,r.uid,r.arrayValue,r.directionalValue,r.orderedDocumentKey,r.documentKey]}}function we(s,e){let t=s.hn-e.hn;return t!==0?t:(t=Vi(s.Tn,e.Tn),t!==0?t:(t=Vi(s.In,e.In),t!==0?t:p.comparator(s.Pn,e.Pn)))}function Vi(s,e){for(let t=0;t<s.length&&t<e.length;++t){const n=s[t]-e[t];if(n!==0)return n}return s.length-e.length}function kn(s){return lo()?(function(t){let n="";for(let r=0;r<t.length;r++)n+=String.fromCharCode(t[r]);return n})(s):s}function Si(s){return typeof s!="string"?s:(function(t){const n=new Uint8Array(t.length);for(let r=0;r<t.length;r++)n[r]=t.charCodeAt(r);return n})(s)}class Pi{constructor(e){this.Vn=new D(((t,n)=>B.comparator(t.field,n.field))),this.collectionId=e.collectionGroup!=null?e.collectionGroup:e.path.lastSegment(),this.dn=e.orderBy,this.mn=[];for(const t of e.filters){const n=t;n.isInequality()?this.Vn=this.Vn.add(n):this.mn.push(n)}}get fn(){return this.Vn.size>1}gn(e){if(T(e.collectionGroup===this.collectionId,49279),this.fn)return!1;const t=Dr(e);if(t!==void 0&&!this.pn(t))return!1;const n=ke(e);let r=new Set,i=0,o=0;for(;i<n.length&&this.pn(n[i]);++i)r=r.add(n[i].fieldPath.canonicalString());if(i===n.length)return!0;if(this.Vn.size>0){const a=this.Vn.getIterator().getNext();if(!r.has(a.field.canonicalString())){const u=n[i];if(!this.yn(a,u)||!this.wn(this.dn[o++],u))return!1}++i}for(;i<n.length;++i){const a=n[i];if(o>=this.dn.length||!this.wn(this.dn[o++],a))return!1}return!0}Sn(){if(this.fn)return null;let e=new D(B.comparator);const t=[];for(const n of this.mn)if(!n.field.isKeyField())if(n.op==="array-contains"||n.op==="array-contains-any")t.push(new Pn(n.field,2));else{if(e.has(n.field))continue;e=e.add(n.field),t.push(new Pn(n.field,0))}for(const n of this.dn)n.field.isKeyField()||e.has(n.field)||(e=e.add(n.field),t.push(new Pn(n.field,n.dir==="asc"?0:1)));return new Ln(Ln.UNKNOWN_ID,this.collectionId,t,nn.empty())}pn(e){for(const t of this.mn)if(this.yn(t,e))return!0;return!1}yn(e,t){if(e===void 0||!e.field.isEqual(t.fieldPath))return!1;const n=e.op==="array-contains"||e.op==="array-contains-any";return t.kind===2===n}wn(e,t){return!!e.field.isEqual(t.fieldPath)&&(t.kind===0&&e.dir==="asc"||t.kind===1&&e.dir==="desc")}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Aa(s){if(T(s instanceof P||s instanceof C,20012),s instanceof P){if(s instanceof Qo){const t=s.value.arrayValue?.values?.map((n=>P.create(s.field,"==",n)))||[];return C.create(t,"or")}return s}const e=s.filters.map((t=>Aa(t)));return C.create(e,s.op)}function bl(s){if(s.getFilters().length===0)return[];const e=Wr(Aa(s));return T(wa(e),7391),jr(e)||Qr(e)?[e]:e.getFilters()}function jr(s){return s instanceof P}function Qr(s){return s instanceof C&&_s(s)}function wa(s){return jr(s)||Qr(s)||(function(t){if(t instanceof C&&Lr(t)){for(const n of t.getFilters())if(!jr(n)&&!Qr(n))return!1;return!0}return!1})(s)}function Wr(s){if(T(s instanceof P||s instanceof C,34018),s instanceof P)return s;if(s.filters.length===1)return Wr(s.filters[0]);const e=s.filters.map((n=>Wr(n)));let t=C.create(e,s.op);return t=Yn(t),wa(t)?t:(T(t instanceof C,64498),T(Vt(t),40251),T(t.filters.length>1,57927),t.filters.reduce(((n,r)=>Rs(n,r))))}function Rs(s,e){let t;return T(s instanceof P||s instanceof C,38388),T(e instanceof P||e instanceof C,25473),t=s instanceof P?e instanceof P?(function(r,i){return C.create([r,i],"and")})(s,e):bi(s,e):e instanceof P?bi(e,s):(function(r,i){if(T(r.filters.length>0&&i.filters.length>0,48005),Vt(r)&&Vt(i))return Go(r,i.getFilters());const o=Lr(r)?r:i,a=Lr(r)?i:r,u=o.filters.map((c=>Rs(c,a)));return C.create(u,"or")})(s,e),Yn(t)}function bi(s,e){if(Vt(e))return Go(e,s.getFilters());{const t=e.filters.map((n=>Rs(s,n)));return C.create(t,"or")}}function Yn(s){if(T(s instanceof P||s instanceof C,11850),s instanceof P)return s;const e=s.getFilters();if(e.length===1)return Yn(e[0]);if(zo(s))return s;const t=e.map((r=>Yn(r))),n=[];return t.forEach((r=>{r instanceof P?n.push(r):r instanceof C&&(r.op===s.op?n.push(...r.filters):n.push(r))})),n.length===1?n[0]:C.create(n,s.op)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class xl{constructor(){this.bn=new vs}addToCollectionParentIndex(e,t){return this.bn.add(t),d.resolve()}getCollectionParents(e,t){return d.resolve(this.bn.getEntries(t))}addFieldIndex(e,t){return d.resolve()}deleteFieldIndex(e,t){return d.resolve()}deleteAllFieldIndexes(e){return d.resolve()}createTargetIndexes(e,t){return d.resolve()}getDocumentsMatchingTarget(e,t){return d.resolve(null)}getIndexType(e,t){return d.resolve(0)}getFieldIndexes(e,t){return d.resolve([])}getNextCollectionGroupToUpdate(e){return d.resolve(null)}getMinOffset(e,t){return d.resolve(ie.min())}getMinOffsetFromCollectionGroup(e,t){return d.resolve(ie.min())}updateCollectionGroup(e,t,n){return d.resolve()}updateIndexEntries(e,t){return d.resolve()}}class vs{constructor(){this.index={}}add(e){const t=e.lastSegment(),n=e.popLast(),r=this.index[t]||new D(M.comparator),i=!r.has(n);return this.index[t]=r.add(n),i}has(e){const t=e.lastSegment(),n=e.popLast(),r=this.index[t];return r&&r.has(n)}getEntries(e){return(this.index[e]||new D(M.comparator)).toArray()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xi="IndexedDbIndexManager",wn=new Uint8Array(0);class Dl{constructor(e,t){this.databaseId=t,this.Dn=new vs,this.Cn=new Ce((n=>He(n)),((n,r)=>_n(n,r))),this.uid=e.uid||""}addToCollectionParentIndex(e,t){if(!this.Dn.has(t)){const n=t.lastSegment(),r=t.popLast();e.addOnCommittedListener((()=>{this.Dn.add(t)}));const i={collectionId:n,parent:ee(r)};return Di(e).put(i)}return d.resolve()}getCollectionParents(e,t){const n=[],r=IDBKeyRange.bound([t,""],[mo(t),""],!1,!0);return Di(e).J(r).next((i=>{for(const o of i){if(o.collectionId!==t)break;n.push(fe(o.parent))}return n}))}addFieldIndex(e,t){const n=Bt(e),r=(function(a){return{indexId:a.indexId,collectionGroup:a.collectionGroup,fields:a.fields.map((u=>[u.fieldPath.canonicalString(),u.kind]))}})(t);delete r.indexId;const i=n.add(r);if(t.indexState){const o=it(e);return i.next((a=>{o.put(Ai(a,this.uid,t.indexState.sequenceNumber,t.indexState.offset))}))}return i.next()}deleteFieldIndex(e,t){const n=Bt(e),r=it(e),i=st(e);return n.delete(t.indexId).next((()=>r.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0)))).next((()=>i.delete(IDBKeyRange.bound([t.indexId],[t.indexId+1],!1,!0))))}deleteAllFieldIndexes(e){const t=Bt(e),n=st(e),r=it(e);return t.X().next((()=>n.X())).next((()=>r.X()))}createTargetIndexes(e,t){return d.forEach(this.vn(t),(n=>this.getIndexType(e,n).next((r=>{if(r===0||r===1){const i=new Pi(n).Sn();if(i!=null)return this.addFieldIndex(e,i)}}))))}getDocumentsMatchingTarget(e,t){const n=st(e);let r=!0;const i=new Map;return d.forEach(this.vn(t),(o=>this.Fn(e,o).next((a=>{r&&(r=!!a),i.set(o,a)})))).next((()=>{if(r){let o=S();const a=[];return d.forEach(i,((u,c)=>{g(xi,`Using index ${(function(x){return`id=${x.indexId}|cg=${x.collectionGroup}|f=${x.fields.map((q=>`${q.fieldPath}:${q.kind}`)).join(",")}`})(u)} to execute ${He(t)}`);const l=(function(x,q){const j=Dr(q);if(j===void 0)return null;for(const z of jn(x,j.fieldPath))switch(z.op){case"array-contains-any":return z.value.arrayValue.values||[];case"array-contains":return[z.value]}return null})(c,u),h=(function(x,q){const j=new Map;for(const z of ke(q))for(const X of jn(x,z.fieldPath))switch(X.op){case"==":case"in":j.set(z.fieldPath.canonicalString(),X.value);break;case"not-in":case"!=":return j.set(z.fieldPath.canonicalString(),X.value),Array.from(j.values())}return null})(c,u),f=(function(x,q){const j=[];let z=!0;for(const X of ke(q)){const Mt=X.kind===0?ui(x,X.fieldPath,x.startAt):ci(x,X.fieldPath,x.startAt);j.push(Mt.value),z&&(z=Mt.inclusive)}return new vt(j,z)})(c,u),_=(function(x,q){const j=[];let z=!0;for(const X of ke(q)){const Mt=X.kind===0?ci(x,X.fieldPath,x.endAt):ui(x,X.fieldPath,x.endAt);j.push(Mt.value),z&&(z=Mt.inclusive)}return new vt(j,z)})(c,u),R=this.Mn(u,c,f),w=this.Mn(u,c,_),v=this.xn(u,c,h),L=this.On(u.indexId,l,R,f.inclusive,w,_.inclusive,v);return d.forEach(L,(N=>n.Z(N,t.limit).next((x=>{x.forEach((q=>{const j=p.fromSegments(q.documentKey);o.has(j)||(o=o.add(j),a.push(j))}))}))))})).next((()=>a))}return d.resolve(null)}))}vn(e){let t=this.Cn.get(e);return t||(e.filters.length===0?t=[e]:t=bl(C.create(e.filters,"and")).map((n=>Ur(e.path,e.collectionGroup,e.orderBy,n.getFilters(),e.limit,e.startAt,e.endAt))),this.Cn.set(e,t),t)}On(e,t,n,r,i,o,a){const u=(t!=null?t.length:1)*Math.max(n.length,i.length),c=u/(t!=null?t.length:1),l=[];for(let h=0;h<u;++h){const f=t?this.Nn(t[h/c]):wn,_=this.Bn(e,f,n[h%c],r),R=this.Ln(e,f,i[h%c],o),w=a.map((v=>this.Bn(e,f,v,!0)));l.push(...this.createRange(_,R,w))}return l}Bn(e,t,n,r){const i=new Be(e,p.empty(),t,n);return r?i:i.En()}Ln(e,t,n,r){const i=new Be(e,p.empty(),t,n);return r?i.En():i}Fn(e,t){const n=new Pi(t),r=t.collectionGroup!=null?t.collectionGroup:t.path.lastSegment();return this.getFieldIndexes(e,r).next((i=>{let o=null;for(const a of i)n.gn(a)&&(!o||a.fields.length>o.fields.length)&&(o=a);return o}))}getIndexType(e,t){let n=2;const r=this.vn(t);return d.forEach(r,(i=>this.Fn(e,i).next((o=>{o?n!==0&&o.fields.length<(function(u){let c=new D(B.comparator),l=!1;for(const h of u.filters)for(const f of h.getFlattenedFilters())f.field.isKeyField()||(f.op==="array-contains"||f.op==="array-contains-any"?l=!0:c=c.add(f.field));for(const h of u.orderBy)h.field.isKeyField()||(c=c.add(h.field));return c.size+(l?1:0)})(i)&&(n=1):n=0})))).next((()=>(function(o){return o.limit!==null})(t)&&r.length>1&&n===2?1:n))}kn(e,t){const n=new Lt;for(const r of ke(e)){const i=t.data.field(r.fieldPath);if(i==null)return null;const o=n.ln(r.kind);Le.Wt.Dt(i,o)}return n.un()}Nn(e){const t=new Lt;return Le.Wt.Dt(e,t.ln(0)),t.un()}Kn(e,t){const n=new Lt;return Le.Wt.Dt(ms(this.databaseId,t),n.ln((function(i){const o=ke(i);return o.length===0?0:o[o.length-1].kind})(e))),n.un()}xn(e,t,n){if(n===null)return[];let r=[];r.push(new Lt);let i=0;for(const o of ke(e)){const a=n[i++];for(const u of r)if(this.qn(t,o.fieldPath)&&ln(a))r=this.Un(r,o,a);else{const c=u.ln(o.kind);Le.Wt.Dt(a,c)}}return this.$n(r)}Mn(e,t,n){return this.xn(e,t,n.position)}$n(e){const t=[];for(let n=0;n<e.length;++n)t[n]=e[n].un();return t}Un(e,t,n){const r=[...e],i=[];for(const o of n.arrayValue.values||[])for(const a of r){const u=new Lt;u.seed(a.un()),Le.Wt.Dt(o,u.ln(t.kind)),i.push(u)}return i}qn(e,t){return!!e.filters.find((n=>n instanceof P&&n.field.isEqual(t)&&(n.op==="in"||n.op==="not-in")))}getFieldIndexes(e,t){const n=Bt(e),r=it(e);return(t?n.J(Nr,IDBKeyRange.bound(t,t)):n.J()).next((i=>{const o=[];return d.forEach(i,(a=>r.get([a.indexId,this.uid]).next((u=>{o.push((function(l,h){const f=h?new nn(h.sequenceNumber,new ie(Ye(h.readTime),new p(fe(h.documentKey)),h.largestBatchId)):nn.empty(),_=l.fields.map((([R,w])=>new Pn(B.fromServerFormat(R),w)));return new Ln(l.indexId,l.collectionGroup,_,f)})(a,u))})))).next((()=>o))}))}getNextCollectionGroupToUpdate(e){return this.getFieldIndexes(e).next((t=>t.length===0?null:(t.sort(((n,r)=>{const i=n.indexState.sequenceNumber-r.indexState.sequenceNumber;return i!==0?i:V(n.collectionGroup,r.collectionGroup)})),t[0].collectionGroup)))}updateCollectionGroup(e,t,n){const r=Bt(e),i=it(e);return this.Wn(e).next((o=>r.J(Nr,IDBKeyRange.bound(t,t)).next((a=>d.forEach(a,(u=>i.put(Ai(u.indexId,this.uid,o,n))))))))}updateIndexEntries(e,t){const n=new Map;return d.forEach(t,((r,i)=>{const o=n.get(r.collectionGroup);return(o?d.resolve(o):this.getFieldIndexes(e,r.collectionGroup)).next((a=>(n.set(r.collectionGroup,a),d.forEach(a,(u=>this.Qn(e,r,u).next((c=>{const l=this.Gn(i,u);return c.isEqual(l)?d.resolve():this.zn(e,i,u,c,l)})))))))}))}jn(e,t,n,r){return st(e).put(r.Rn(this.uid,this.Kn(n,t.key),t.key))}Jn(e,t,n,r){return st(e).delete(r.An(this.uid,this.Kn(n,t.key),t.key))}Qn(e,t,n){const r=st(e);let i=new D(we);return r.ee({index:Ro,range:IDBKeyRange.only([n.indexId,this.uid,kn(this.Kn(n,t))])},((o,a)=>{i=i.add(new Be(n.indexId,t,Si(a.arrayValue),Si(a.directionalValue)))})).next((()=>i))}Gn(e,t){let n=new D(we);const r=this.kn(t,e);if(r==null)return n;const i=Dr(t);if(i!=null){const o=e.data.field(i.fieldPath);if(ln(o))for(const a of o.arrayValue.values||[])n=n.add(new Be(t.indexId,e.key,this.Nn(a),r))}else n=n.add(new Be(t.indexId,e.key,wn,r));return n}zn(e,t,n,r,i){g(xi,"Updating index entries for document '%s'",t.key);const o=[];return(function(u,c,l,h,f){const _=u.getIterator(),R=c.getIterator();let w=nt(_),v=nt(R);for(;w||v;){let L=!1,N=!1;if(w&&v){const x=l(w,v);x<0?N=!0:x>0&&(L=!0)}else w!=null?N=!0:L=!0;L?(h(v),v=nt(R)):N?(f(w),w=nt(_)):(w=nt(_),v=nt(R))}})(r,i,we,(a=>{o.push(this.jn(e,t,n,a))}),(a=>{o.push(this.Jn(e,t,n,a))})),d.waitFor(o)}Wn(e){let t=1;return it(e).ee({index:wo,reverse:!0,range:IDBKeyRange.upperBound([this.uid,Number.MAX_SAFE_INTEGER])},((n,r,i)=>{i.done(),t=r.sequenceNumber+1})).next((()=>t))}createRange(e,t,n){n=n.sort(((o,a)=>we(o,a))).filter(((o,a,u)=>!a||we(o,u[a-1])!==0));const r=[];r.push(e);for(const o of n){const a=we(o,e),u=we(o,t);if(a===0)r[0]=e.En();else if(a>0&&u<0)r.push(o),r.push(o.En());else if(u>0)break}r.push(t);const i=[];for(let o=0;o<r.length;o+=2){if(this.Hn(r[o],r[o+1]))return[];const a=r[o].An(this.uid,wn,p.empty()),u=r[o+1].An(this.uid,wn,p.empty());i.push(IDBKeyRange.bound(a,u))}return i}Hn(e,t){return we(e,t)>0}getMinOffsetFromCollectionGroup(e,t){return this.getFieldIndexes(e,t).next(Ci)}getMinOffset(e,t){return d.mapArray(this.vn(t),(n=>this.Fn(e,n).next((r=>r||I(44426))))).next(Ci)}}function Di(s){return Q(s,an)}function st(s){return Q(s,Ht)}function Bt(s){return Q(s,cs)}function it(s){return Q(s,Wt)}function Ci(s){T(s.length!==0,28825);let e=s[0].indexState.offset,t=e.largestBatchId;for(let n=1;n<s.length;n++){const r=s[n].indexState.offset;os(r,e)<0&&(e=r),t<r.largestBatchId&&(t=r.largestBatchId)}return new ie(e.readTime,e.documentKey,t)}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ni={didRun:!1,sequenceNumbersCollected:0,targetsRemoved:0,documentsRemoved:0},Ra=41943040;class ne{static withCacheSize(e){return new ne(e,ne.DEFAULT_COLLECTION_PERCENTILE,ne.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT)}constructor(e,t,n){this.cacheSizeCollectionThreshold=e,this.percentileToCollect=t,this.maximumSequenceNumbersToCollect=n}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function va(s,e,t){const n=s.store(ce),r=s.store(yt),i=[],o=IDBKeyRange.only(t.batchId);let a=0;const u=n.ee({range:o},((l,h,f)=>(a++,f.delete())));i.push(u.next((()=>{T(a===1,47070,{batchId:t.batchId})})));const c=[];for(const l of t.mutations){const h=To(e,l.key.path,t.batchId);i.push(r.delete(h)),c.push(l.key)}return d.waitFor(i).next((()=>c))}function Xn(s){if(!s)return 0;let e;if(s.document)e=s.document;else if(s.unknownDocument)e=s.unknownDocument;else{if(!s.noDocument)throw I(14731);e=s.noDocument}return JSON.stringify(e).length}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */ne.DEFAULT_COLLECTION_PERCENTILE=10,ne.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT=1e3,ne.DEFAULT=new ne(Ra,ne.DEFAULT_COLLECTION_PERCENTILE,ne.DEFAULT_MAX_SEQUENCE_NUMBERS_TO_COLLECT),ne.DISABLED=new ne(-1,0,0);class _r{constructor(e,t,n,r){this.userId=e,this.serializer=t,this.indexManager=n,this.referenceDelegate=r,this.Zn={}}static wt(e,t,n,r){T(e.uid!=="",64387);const i=e.isAuthenticated()?e.uid:"";return new _r(i,t,n,r)}checkEmpty(e){let t=!0;const n=IDBKeyRange.bound([this.userId,Number.NEGATIVE_INFINITY],[this.userId,Number.POSITIVE_INFINITY]);return Re(e).ee({index:Ue,range:n},((r,i,o)=>{t=!1,o.done()})).next((()=>t))}addMutationBatch(e,t,n,r){const i=lt(e),o=Re(e);return o.add({}).next((a=>{T(typeof a=="number",49019);const u=new Ts(a,t,n,r),c=(function(_,R,w){const v=w.baseMutations.map((N=>Hn(_.yt,N))),L=w.mutations.map((N=>Hn(_.yt,N)));return{userId:R,batchId:w.batchId,localWriteTimeMs:w.localWriteTime.toMillis(),baseMutations:v,mutations:L}})(this.serializer,this.userId,u),l=[];let h=new D(((f,_)=>V(f.canonicalString(),_.canonicalString())));for(const f of r){const _=To(this.userId,f.key.path,a);h=h.add(f.key.path.popLast()),l.push(o.put(c)),l.push(i.put(_,tc))}return h.forEach((f=>{l.push(this.indexManager.addToCollectionParentIndex(e,f))})),e.addOnCommittedListener((()=>{this.Zn[a]=u.keys()})),d.waitFor(l).next((()=>u))}))}lookupMutationBatch(e,t){return Re(e).get(t).next((n=>n?(T(n.userId===this.userId,48,"Unexpected user for mutation batch",{userId:n.userId,batchId:t}),Fe(this.serializer,n)):null))}Xn(e,t){return this.Zn[t]?d.resolve(this.Zn[t]):this.lookupMutationBatch(e,t).next((n=>{if(n){const r=n.keys();return this.Zn[t]=r,r}return null}))}getNextMutationBatchAfterBatchId(e,t){const n=t+1,r=IDBKeyRange.lowerBound([this.userId,n]);let i=null;return Re(e).ee({index:Ue,range:r},((o,a,u)=>{a.userId===this.userId&&(T(a.batchId>=n,47524,{Yn:n}),i=Fe(this.serializer,a)),u.done()})).next((()=>i))}getHighestUnacknowledgedBatchId(e){const t=IDBKeyRange.upperBound([this.userId,Number.POSITIVE_INFINITY]);let n=ze;return Re(e).ee({index:Ue,range:t,reverse:!0},((r,i,o)=>{n=i.batchId,o.done()})).next((()=>n))}getAllMutationBatches(e){const t=IDBKeyRange.bound([this.userId,ze],[this.userId,Number.POSITIVE_INFINITY]);return Re(e).J(Ue,t).next((n=>n.map((r=>Fe(this.serializer,r)))))}getAllMutationBatchesAffectingDocumentKey(e,t){const n=bn(this.userId,t.path),r=IDBKeyRange.lowerBound(n),i=[];return lt(e).ee({range:r},((o,a,u)=>{const[c,l,h]=o,f=fe(l);if(c===this.userId&&t.path.isEqual(f))return Re(e).get(h).next((_=>{if(!_)throw I(61480,{er:o,batchId:h});T(_.userId===this.userId,10503,"Unexpected user for mutation batch",{userId:_.userId,batchId:h}),i.push(Fe(this.serializer,_))}));u.done()})).next((()=>i))}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new D(V);const r=[];return t.forEach((i=>{const o=bn(this.userId,i.path),a=IDBKeyRange.lowerBound(o),u=lt(e).ee({range:a},((c,l,h)=>{const[f,_,R]=c,w=fe(_);f===this.userId&&i.path.isEqual(w)?n=n.add(R):h.done()}));r.push(u)})),d.waitFor(r).next((()=>this.tr(e,n)))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,r=n.length+1,i=bn(this.userId,n),o=IDBKeyRange.lowerBound(i);let a=new D(V);return lt(e).ee({range:o},((u,c,l)=>{const[h,f,_]=u,R=fe(f);h===this.userId&&n.isPrefixOf(R)?R.length===r&&(a=a.add(_)):l.done()})).next((()=>this.tr(e,a)))}tr(e,t){const n=[],r=[];return t.forEach((i=>{r.push(Re(e).get(i).next((o=>{if(o===null)throw I(35274,{batchId:i});T(o.userId===this.userId,9748,"Unexpected user for mutation batch",{userId:o.userId,batchId:i}),n.push(Fe(this.serializer,o))})))})),d.waitFor(r).next((()=>n))}removeMutationBatch(e,t){return va(e.le,this.userId,t).next((n=>(e.addOnCommittedListener((()=>{this.nr(t.batchId)})),d.forEach(n,(r=>this.referenceDelegate.markPotentiallyOrphaned(e,r))))))}nr(e){delete this.Zn[e]}performConsistencyCheck(e){return this.checkEmpty(e).next((t=>{if(!t)return d.resolve();const n=IDBKeyRange.lowerBound((function(o){return[o]})(this.userId)),r=[];return lt(e).ee({range:n},((i,o,a)=>{if(i[0]===this.userId){const u=fe(i[1]);r.push(u)}else a.done()})).next((()=>{T(r.length===0,56720,{rr:r.map((i=>i.canonicalString()))})}))}))}containsKey(e,t){return Va(e,this.userId,t)}ir(e){return Sa(e).get(this.userId).next((t=>t||{userId:this.userId,lastAcknowledgedBatchId:ze,lastStreamToken:""}))}}function Va(s,e,t){const n=bn(e,t.path),r=n[1],i=IDBKeyRange.lowerBound(n);let o=!1;return lt(s).ee({range:i,Y:!0},((a,u,c)=>{const[l,h,f]=a;l===e&&h===r&&(o=!0),c.done()})).next((()=>o))}function Re(s){return Q(s,ce)}function lt(s){return Q(s,yt)}function Sa(s){return Q(s,sn)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ee{constructor(e){this.sr=e}next(){return this.sr+=2,this.sr}static _r(){return new Ee(0)}static ar(){return new Ee(-1)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Cl{constructor(e,t){this.referenceDelegate=e,this.serializer=t}allocateTargetId(e){return this.ur(e).next((t=>{const n=new Ee(t.highestTargetId);return t.highestTargetId=n.next(),this.cr(e,t).next((()=>t.highestTargetId))}))}getLastRemoteSnapshotVersion(e){return this.ur(e).next((t=>A.fromTimestamp(new O(t.lastRemoteSnapshotVersion.seconds,t.lastRemoteSnapshotVersion.nanoseconds))))}getHighestSequenceNumber(e){return this.ur(e).next((t=>t.highestListenSequenceNumber))}setTargetsMetadata(e,t,n){return this.ur(e).next((r=>(r.highestListenSequenceNumber=t,n&&(r.lastRemoteSnapshotVersion=n.toTimestamp()),t>r.highestListenSequenceNumber&&(r.highestListenSequenceNumber=t),this.cr(e,r))))}addTargetData(e,t){return this.lr(e,t).next((()=>this.ur(e).next((n=>(n.targetCount+=1,this.hr(t,n),this.cr(e,n))))))}updateTargetData(e,t){return this.lr(e,t)}removeTargetData(e,t){return this.removeMatchingKeysForTargetId(e,t.targetId).next((()=>ot(e).delete(t.targetId))).next((()=>this.ur(e))).next((n=>(T(n.targetCount>0,8065),n.targetCount-=1,this.cr(e,n))))}removeTargets(e,t,n){let r=0;const i=[];return ot(e).ee(((o,a)=>{const u=$t(a);u.sequenceNumber<=t&&n.get(u.targetId)===null&&(r++,i.push(this.removeTargetData(e,u)))})).next((()=>d.waitFor(i))).next((()=>r))}forEachTarget(e,t){return ot(e).ee(((n,r)=>{const i=$t(r);t(i)}))}ur(e){return ki(e).get(qn).next((t=>(T(t!==null,2888),t)))}cr(e,t){return ki(e).put(qn,t)}lr(e,t){return ot(e).put(Ta(this.serializer,t))}hr(e,t){let n=!1;return e.targetId>t.highestTargetId&&(t.highestTargetId=e.targetId,n=!0),e.sequenceNumber>t.highestListenSequenceNumber&&(t.highestListenSequenceNumber=e.sequenceNumber,n=!0),n}getTargetCount(e){return this.ur(e).next((t=>t.targetCount))}getTargetData(e,t){const n=He(t),r=IDBKeyRange.bound([n,Number.NEGATIVE_INFINITY],[n,Number.POSITIVE_INFINITY]);let i=null;return ot(e).ee({range:r,index:Ao},((o,a,u)=>{const c=$t(a);_n(t,c.target)&&(i=c,u.done())})).next((()=>i))}addMatchingKeys(e,t,n){const r=[],i=Ve(e);return t.forEach((o=>{const a=ee(o.path);r.push(i.put({targetId:n,path:a})),r.push(this.referenceDelegate.addReference(e,n,o))})),d.waitFor(r)}removeMatchingKeys(e,t,n){const r=Ve(e);return d.forEach(t,(i=>{const o=ee(i.path);return d.waitFor([r.delete([n,o]),this.referenceDelegate.removeReference(e,n,i)])}))}removeMatchingKeysForTargetId(e,t){const n=Ve(e),r=IDBKeyRange.bound([t],[t+1],!1,!0);return n.delete(r)}getMatchingKeysForTargetId(e,t){const n=IDBKeyRange.bound([t],[t+1],!1,!0),r=Ve(e);let i=S();return r.ee({range:n,Y:!0},((o,a,u)=>{const c=fe(o[1]),l=new p(c);i=i.add(l)})).next((()=>i))}containsKey(e,t){const n=ee(t.path),r=IDBKeyRange.bound([n],[mo(n)],!1,!0);let i=0;return Ve(e).ee({index:us,Y:!0,range:r},(([o,a],u,c)=>{o!==0&&(i++,c.done())})).next((()=>i>0))}At(e,t){return ot(e).get(t).next((n=>n?$t(n):null))}}function ot(s){return Q(s,It)}function ki(s){return Q(s,Ke)}function Ve(s){return Q(s,Tt)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Mi="LruGarbageCollector",Pa=1048576;function Oi([s,e],[t,n]){const r=V(s,t);return r===0?V(e,n):r}class Nl{constructor(e){this.Pr=e,this.buffer=new D(Oi),this.Tr=0}Ir(){return++this.Tr}Er(e){const t=[e,this.Ir()];if(this.buffer.size<this.Pr)this.buffer=this.buffer.add(t);else{const n=this.buffer.last();Oi(t,n)<0&&(this.buffer=this.buffer.delete(n).add(t))}}get maxValue(){return this.buffer.last()[0]}}class kl{constructor(e,t,n){this.garbageCollector=e,this.asyncQueue=t,this.localStore=n,this.Rr=null}start(){this.garbageCollector.params.cacheSizeCollectionThreshold!==-1&&this.Ar(6e4)}stop(){this.Rr&&(this.Rr.cancel(),this.Rr=null)}get started(){return this.Rr!==null}Ar(e){g(Mi,`Garbage collection scheduled in ${e}ms`),this.Rr=this.asyncQueue.enqueueAfterDelay("lru_garbage_collection",e,(async()=>{this.Rr=null;try{await this.localStore.collectGarbage(this.garbageCollector)}catch(t){Ze(t)?g(Mi,"Ignoring IndexedDB error during garbage collection: ",t):await Xe(t)}await this.Ar(3e5)}))}}class Ml{constructor(e,t){this.Vr=e,this.params=t}calculateTargetCount(e,t){return this.Vr.dr(e).next((n=>Math.floor(t/100*n)))}nthSequenceNumber(e,t){if(t===0)return d.resolve(re.ce);const n=new Nl(t);return this.Vr.forEachTarget(e,(r=>n.Er(r.sequenceNumber))).next((()=>this.Vr.mr(e,(r=>n.Er(r))))).next((()=>n.maxValue))}removeTargets(e,t,n){return this.Vr.removeTargets(e,t,n)}removeOrphanedDocuments(e,t){return this.Vr.removeOrphanedDocuments(e,t)}collect(e,t){return this.params.cacheSizeCollectionThreshold===-1?(g("LruGarbageCollector","Garbage collection skipped; disabled"),d.resolve(Ni)):this.getCacheSize(e).next((n=>n<this.params.cacheSizeCollectionThreshold?(g("LruGarbageCollector",`Garbage collection skipped; Cache size ${n} is lower than threshold ${this.params.cacheSizeCollectionThreshold}`),Ni):this.gr(e,t)))}getCacheSize(e){return this.Vr.getCacheSize(e)}gr(e,t){let n,r,i,o,a,u,c;const l=Date.now();return this.calculateTargetCount(e,this.params.percentileToCollect).next((h=>(h>this.params.maximumSequenceNumbersToCollect?(g("LruGarbageCollector",`Capping sequence numbers to collect down to the maximum of ${this.params.maximumSequenceNumbersToCollect} from ${h}`),r=this.params.maximumSequenceNumbersToCollect):r=h,o=Date.now(),this.nthSequenceNumber(e,r)))).next((h=>(n=h,a=Date.now(),this.removeTargets(e,n,t)))).next((h=>(i=h,u=Date.now(),this.removeOrphanedDocuments(e,n)))).next((h=>(c=Date.now(),at()<=ye.DEBUG&&g("LruGarbageCollector",`LRU Garbage Collection
	Counted targets in ${o-l}ms
	Determined least recently used ${r} in `+(a-o)+`ms
	Removed ${i} targets in `+(u-a)+`ms
	Removed ${h} documents in `+(c-u)+`ms
Total Duration: ${c-l}ms`),d.resolve({didRun:!0,sequenceNumbersCollected:r,targetsRemoved:i,documentsRemoved:h}))))}}function Ol(s,e){return new Ml(s,e)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Fl{constructor(e,t){this.db=e,this.garbageCollector=Ol(this,t)}dr(e){const t=this.pr(e);return this.db.getTargetCache().getTargetCount(e).next((n=>t.next((r=>n+r))))}pr(e){let t=0;return this.mr(e,(n=>{t++})).next((()=>t))}forEachTarget(e,t){return this.db.getTargetCache().forEachTarget(e,t)}mr(e,t){return this.yr(e,((n,r)=>t(r)))}addReference(e,t,n){return Rn(e,n)}removeReference(e,t,n){return Rn(e,n)}removeTargets(e,t,n){return this.db.getTargetCache().removeTargets(e,t,n)}markPotentiallyOrphaned(e,t){return Rn(e,t)}wr(e,t){return(function(r,i){let o=!1;return Sa(r).te((a=>Va(r,a,i).next((u=>(u&&(o=!0),d.resolve(!u)))))).next((()=>o))})(e,t)}removeOrphanedDocuments(e,t){const n=this.db.getRemoteDocumentCache().newChangeBuffer(),r=[];let i=0;return this.yr(e,((o,a)=>{if(a<=t){const u=this.wr(e,o).next((c=>{if(!c)return i++,n.getEntry(e,o).next((()=>(n.removeEntry(o,A.min()),Ve(e).delete((function(h){return[0,ee(h.path)]})(o)))))}));r.push(u)}})).next((()=>d.waitFor(r))).next((()=>n.apply(e))).next((()=>i))}removeTarget(e,t){const n=t.withSequenceNumber(e.currentSequenceNumber);return this.db.getTargetCache().updateTargetData(e,n)}updateLimboDocument(e,t){return Rn(e,t)}yr(e,t){const n=Ve(e);let r,i=re.ce;return n.ee({index:us},(([o,a],{path:u,sequenceNumber:c})=>{o===0?(i!==re.ce&&t(new p(fe(r)),i),i=c,r=u):i=re.ce})).next((()=>{i!==re.ce&&t(new p(fe(r)),i)}))}getCacheSize(e){return this.db.getRemoteDocumentCache().getSize(e)}}function Rn(s,e){return Ve(s).put((function(n,r){return{targetId:0,path:ee(n.path),sequenceNumber:r}})(e,s.currentSequenceNumber))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ba{constructor(){this.changes=new Ce((e=>e.toString()),((e,t)=>e.isEqual(t))),this.changesApplied=!1}addEntry(e){this.assertNotApplied(),this.changes.set(e.key,e)}removeEntry(e,t){this.assertNotApplied(),this.changes.set(e,F.newInvalidDocument(e).setReadTime(t))}getEntry(e,t){this.assertNotApplied();const n=this.changes.get(t);return n!==void 0?d.resolve(n):this.getFromCache(e,t)}getEntries(e,t){return this.getAllFromCache(e,t)}apply(e){return this.assertNotApplied(),this.changesApplied=!0,this.applyChanges(e)}assertNotApplied(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ll{constructor(e){this.serializer=e}setIndexManager(e){this.indexManager=e}addEntry(e,t,n){return Ne(e).put(n)}removeEntry(e,t,n){return Ne(e).delete((function(i,o){const a=i.path.toArray();return[a.slice(0,a.length-2),a[a.length-2],Jn(o),a[a.length-1]]})(t,n))}updateMetadata(e,t){return this.getMetadata(e).next((n=>(n.byteSize+=t,this.Sr(e,n))))}getEntry(e,t){let n=F.newInvalidDocument(t);return Ne(e).ee({index:xn,range:IDBKeyRange.only(Ut(t))},((r,i)=>{n=this.br(t,i)})).next((()=>n))}Dr(e,t){let n={size:0,document:F.newInvalidDocument(t)};return Ne(e).ee({index:xn,range:IDBKeyRange.only(Ut(t))},((r,i)=>{n={document:this.br(t,i),size:Xn(i)}})).next((()=>n))}getEntries(e,t){let n=ae();return this.Cr(e,t,((r,i)=>{const o=this.br(r,i);n=n.insert(r,o)})).next((()=>n))}vr(e,t){let n=ae(),r=new k(p.comparator);return this.Cr(e,t,((i,o)=>{const a=this.br(i,o);n=n.insert(i,a),r=r.insert(i,Xn(o))})).next((()=>({documents:n,Fr:r})))}Cr(e,t,n){if(t.isEmpty())return d.resolve();let r=new D(Bi);t.forEach((u=>r=r.add(u)));const i=IDBKeyRange.bound(Ut(r.first()),Ut(r.last())),o=r.getIterator();let a=o.getNext();return Ne(e).ee({index:xn,range:i},((u,c,l)=>{const h=p.fromSegments([...c.prefixPath,c.collectionGroup,c.documentId]);for(;a&&Bi(a,h)<0;)n(a,null),a=o.getNext();a&&a.isEqual(h)&&(n(a,c),a=o.hasNext()?o.getNext():null),a?l.j(Ut(a)):l.done()})).next((()=>{for(;a;)n(a,null),a=o.hasNext()?o.getNext():null}))}getDocumentsMatchingQuery(e,t,n,r,i){const o=t.path,a=[o.popLast().toArray(),o.lastSegment(),Jn(n.readTime),n.documentKey.path.isEmpty()?"":n.documentKey.path.lastSegment()],u=[o.popLast().toArray(),o.lastSegment(),[Number.MAX_SAFE_INTEGER,Number.MAX_SAFE_INTEGER],""];return Ne(e).J(IDBKeyRange.bound(a,u,!0)).next((c=>{i?.incrementDocumentReadCount(c.length);let l=ae();for(const h of c){const f=this.br(p.fromSegments(h.prefixPath.concat(h.collectionGroup,h.documentId)),h);f.isFoundDocument()&&(gn(t,f)||r.has(f.key))&&(l=l.insert(f.key,f))}return l}))}getAllFromCollectionGroup(e,t,n,r){let i=ae();const o=Li(t,n),a=Li(t,ie.max());return Ne(e).ee({index:Eo,range:IDBKeyRange.bound(o,a,!0)},((u,c,l)=>{const h=this.br(p.fromSegments(c.prefixPath.concat(c.collectionGroup,c.documentId)),c);i=i.insert(h.key,h),i.size===r&&l.done()})).next((()=>i))}newChangeBuffer(e){return new Bl(this,!!e&&e.trackRemovals)}getSize(e){return this.getMetadata(e).next((t=>t.byteSize))}getMetadata(e){return Fi(e).get(Cr).next((t=>(T(!!t,20021),t)))}Sr(e,t){return Fi(e).put(Cr,t)}br(e,t){if(t){const n=Al(this.serializer,t);if(!(n.isNoDocument()&&n.version.isEqual(A.min())))return n}return F.newInvalidDocument(e)}}function xa(s){return new Ll(s)}class Bl extends ba{constructor(e,t){super(),this.Mr=e,this.trackRemovals=t,this.Or=new Ce((n=>n.toString()),((n,r)=>n.isEqual(r)))}applyChanges(e){const t=[];let n=0,r=new D(((i,o)=>V(i.canonicalString(),o.canonicalString())));return this.changes.forEach(((i,o)=>{const a=this.Or.get(i);if(t.push(this.Mr.removeEntry(e,i,a.readTime)),o.isValidDocument()){const u=Ti(this.Mr.serializer,o);r=r.add(i.path.popLast());const c=Xn(u);n+=c-a.size,t.push(this.Mr.addEntry(e,i,u))}else if(n-=a.size,this.trackRemovals){const u=Ti(this.Mr.serializer,o.convertToNoDocument(A.min()));t.push(this.Mr.addEntry(e,i,u))}})),r.forEach((i=>{t.push(this.Mr.indexManager.addToCollectionParentIndex(e,i))})),t.push(this.Mr.updateMetadata(e,n)),d.waitFor(t)}getFromCache(e,t){return this.Mr.Dr(e,t).next((n=>(this.Or.set(t,{size:n.size,readTime:n.document.readTime}),n.document)))}getAllFromCache(e,t){return this.Mr.vr(e,t).next((({documents:n,Fr:r})=>(r.forEach(((i,o)=>{this.Or.set(i,{size:o,readTime:n.get(i).readTime})})),n)))}}function Fi(s){return Q(s,on)}function Ne(s){return Q(s,Un)}function Ut(s){const e=s.path.toArray();return[e.slice(0,e.length-2),e[e.length-2],e[e.length-1]]}function Li(s,e){const t=e.documentKey.path.toArray();return[s,Jn(e.readTime),t.slice(0,t.length-2),t.length>0?t[t.length-1]:""]}function Bi(s,e){const t=s.path.toArray(),n=e.path.toArray();let r=0;for(let i=0;i<t.length-2&&i<n.length-2;++i)if(r=V(t[i],n[i]),r)return r;return r=V(t.length,n.length),r||(r=V(t[t.length-2],n[n.length-2]),r||V(t[t.length-1],n[n.length-1]))}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ul{constructor(e,t){this.overlayedDocument=e,this.mutatedFields=t}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Da{constructor(e,t,n,r){this.remoteDocumentCache=e,this.mutationQueue=t,this.documentOverlayCache=n,this.indexManager=r}getDocument(e,t){let n=null;return this.documentOverlayCache.getOverlay(e,t).next((r=>(n=r,this.remoteDocumentCache.getEntry(e,t)))).next((r=>(n!==null&&Zt(n.mutation,r,Te.empty(),O.now()),r)))}getDocuments(e,t){return this.remoteDocumentCache.getEntries(e,t).next((n=>this.getLocalViewOfDocuments(e,n,S()).next((()=>n))))}getLocalViewOfDocuments(e,t,n=S()){const r=me();return this.populateOverlays(e,r,t).next((()=>this.computeViews(e,t,r,n).next((i=>{let o=Kt();return i.forEach(((a,u)=>{o=o.insert(a,u.overlayedDocument)})),o}))))}getOverlayedDocuments(e,t){const n=me();return this.populateOverlays(e,n,t).next((()=>this.computeViews(e,t,n,S())))}populateOverlays(e,t,n){const r=[];return n.forEach((i=>{t.has(i)||r.push(i)})),this.documentOverlayCache.getOverlays(e,r).next((i=>{i.forEach(((o,a)=>{t.set(o,a)}))}))}computeViews(e,t,n,r){let i=ae();const o=Xt(),a=(function(){return Xt()})();return t.forEach(((u,c)=>{const l=n.get(c.key);r.has(c.key)&&(l===void 0||l.mutation instanceof xt)?i=i.insert(c.key,c):l!==void 0?(o.set(c.key,l.mutation.getFieldMask()),Zt(l.mutation,c,l.mutation.getFieldMask(),O.now())):o.set(c.key,Te.empty())})),this.recalculateAndSaveOverlays(e,i).next((u=>(u.forEach(((c,l)=>o.set(c,l))),t.forEach(((c,l)=>a.set(c,new Ul(l,o.get(c)??null)))),a)))}recalculateAndSaveOverlays(e,t){const n=Xt();let r=new k(((o,a)=>o-a)),i=S();return this.mutationQueue.getAllMutationBatchesAffectingDocumentKeys(e,t).next((o=>{for(const a of o)a.keys().forEach((u=>{const c=t.get(u);if(c===null)return;let l=n.get(u)||Te.empty();l=a.applyToLocalView(c,l),n.set(u,l);const h=(r.get(a.batchId)||S()).add(u);r=r.insert(a.batchId,h)}))})).next((()=>{const o=[],a=r.getReverseIterator();for(;a.hasNext();){const u=a.getNext(),c=u.key,l=u.value,h=Zo();l.forEach((f=>{if(!i.has(f)){const _=ra(t.get(f),n.get(f));_!==null&&h.set(f,_),i=i.add(f)}})),o.push(this.documentOverlayCache.saveOverlays(e,c,h))}return d.waitFor(o)})).next((()=>n))}recalculateAndSaveOverlaysForDocumentKeys(e,t){return this.remoteDocumentCache.getEntries(e,t).next((n=>this.recalculateAndSaveOverlays(e,n)))}getDocumentsMatchingQuery(e,t,n,r){return Lc(t)?this.getDocumentsMatchingDocumentQuery(e,t.path):Bc(t)?this.getDocumentsMatchingCollectionGroupQuery(e,t,n,r):this.getDocumentsMatchingCollectionQuery(e,t,n,r)}getNextDocuments(e,t,n,r){return this.remoteDocumentCache.getAllFromCollectionGroup(e,t,n,r).next((i=>{const o=r-i.size>0?this.documentOverlayCache.getOverlaysForCollectionGroup(e,t,n.largestBatchId,r-i.size):d.resolve(me());let a=pt,u=i;return o.next((c=>d.forEach(c,((l,h)=>(a<h.largestBatchId&&(a=h.largestBatchId),i.get(l)?d.resolve():this.remoteDocumentCache.getEntry(e,l).next((f=>{u=u.insert(l,f)}))))).next((()=>this.populateOverlays(e,c,i))).next((()=>this.computeViews(e,u,c,S()))).next((l=>({batchId:a,changes:Kc(l)})))))}))}getDocumentsMatchingDocumentQuery(e,t){return this.getDocument(e,new p(t)).next((n=>{let r=Kt();return n.isFoundDocument()&&(r=r.insert(n.key,n)),r}))}getDocumentsMatchingCollectionGroupQuery(e,t,n,r){const i=t.collectionGroup;let o=Kt();return this.indexManager.getCollectionParents(e,i).next((a=>d.forEach(a,(u=>{const c=(function(h,f){return new hr(f,null,h.explicitOrderBy.slice(),h.filters.slice(),h.limit,h.limitType,h.startAt,h.endAt)})(t,u.child(i));return this.getDocumentsMatchingCollectionQuery(e,c,n,r).next((l=>{l.forEach(((h,f)=>{o=o.insert(h,f)}))}))})).next((()=>o))))}getDocumentsMatchingCollectionQuery(e,t,n,r){let i;return this.documentOverlayCache.getOverlaysForCollection(e,t.path,n.largestBatchId).next((o=>(i=o,this.remoteDocumentCache.getDocumentsMatchingQuery(e,t,n,i,r)))).next((o=>{i.forEach(((u,c)=>{const l=c.getKey();o.get(l)===null&&(o=o.insert(l,F.newInvalidDocument(l)))}));let a=Kt();return o.forEach(((u,c)=>{const l=i.get(u);l!==void 0&&Zt(l.mutation,c,Te.empty(),O.now()),gn(t,c)&&(a=a.insert(u,c))})),a}))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ql{constructor(e){this.serializer=e,this.Nr=new Map,this.Br=new Map}getBundleMetadata(e,t){return d.resolve(this.Nr.get(t))}saveBundleMetadata(e,t){return this.Nr.set(t.id,(function(r){return{id:r.id,version:r.version,createTime:te(r.createTime)}})(t)),d.resolve()}getNamedQuery(e,t){return d.resolve(this.Br.get(t))}saveNamedQuery(e,t){return this.Br.set(t.name,(function(r){return{name:r.name,query:Ea(r.bundledQuery),readTime:te(r.readTime)}})(t)),d.resolve()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class zl{constructor(){this.overlays=new k(p.comparator),this.Lr=new Map}getOverlay(e,t){return d.resolve(this.overlays.get(t))}getOverlays(e,t){const n=me();return d.forEach(t,(r=>this.getOverlay(e,r).next((i=>{i!==null&&n.set(r,i)})))).next((()=>n))}saveOverlays(e,t,n){return n.forEach(((r,i)=>{this.St(e,t,i)})),d.resolve()}removeOverlaysForBatchId(e,t,n){const r=this.Lr.get(n);return r!==void 0&&(r.forEach((i=>this.overlays=this.overlays.remove(i))),this.Lr.delete(n)),d.resolve()}getOverlaysForCollection(e,t,n){const r=me(),i=t.length+1,o=new p(t.child("")),a=this.overlays.getIteratorFrom(o);for(;a.hasNext();){const u=a.getNext().value,c=u.getKey();if(!t.isPrefixOf(c.path))break;c.path.length===i&&u.largestBatchId>n&&r.set(u.getKey(),u)}return d.resolve(r)}getOverlaysForCollectionGroup(e,t,n,r){let i=new k(((c,l)=>c-l));const o=this.overlays.getIterator();for(;o.hasNext();){const c=o.getNext().value;if(c.getKey().getCollectionGroup()===t&&c.largestBatchId>n){let l=i.get(c.largestBatchId);l===null&&(l=me(),i=i.insert(c.largestBatchId,l)),l.set(c.getKey(),c)}}const a=me(),u=i.getIterator();for(;u.hasNext()&&(u.getNext().value.forEach(((c,l)=>a.set(c,l))),!(a.size()>=r)););return d.resolve(a)}St(e,t,n){const r=this.overlays.get(n.key);if(r!==null){const o=this.Lr.get(r.largestBatchId).delete(n.key);this.Lr.set(r.largestBatchId,o)}this.overlays=this.overlays.insert(n.key,new As(t,n));let i=this.Lr.get(t);i===void 0&&(i=S(),this.Lr.set(t,i)),this.Lr.set(t,i.add(n.key))}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Kl{constructor(){this.sessionToken=U.EMPTY_BYTE_STRING}getSessionToken(e){return d.resolve(this.sessionToken)}setSessionToken(e,t){return this.sessionToken=t,d.resolve()}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Vs{constructor(){this.kr=new D(W.Kr),this.qr=new D(W.Ur)}isEmpty(){return this.kr.isEmpty()}addReference(e,t){const n=new W(e,t);this.kr=this.kr.add(n),this.qr=this.qr.add(n)}$r(e,t){e.forEach((n=>this.addReference(n,t)))}removeReference(e,t){this.Wr(new W(e,t))}Qr(e,t){e.forEach((n=>this.removeReference(n,t)))}Gr(e){const t=new p(new M([])),n=new W(t,e),r=new W(t,e+1),i=[];return this.qr.forEachInRange([n,r],(o=>{this.Wr(o),i.push(o.key)})),i}zr(){this.kr.forEach((e=>this.Wr(e)))}Wr(e){this.kr=this.kr.delete(e),this.qr=this.qr.delete(e)}jr(e){const t=new p(new M([])),n=new W(t,e),r=new W(t,e+1);let i=S();return this.qr.forEachInRange([n,r],(o=>{i=i.add(o.key)})),i}containsKey(e){const t=new W(e,0),n=this.kr.firstAfterOrEqual(t);return n!==null&&e.isEqual(n.key)}}class W{constructor(e,t){this.key=e,this.Jr=t}static Kr(e,t){return p.comparator(e.key,t.key)||V(e.Jr,t.Jr)}static Ur(e,t){return V(e.Jr,t.Jr)||p.comparator(e.key,t.key)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Gl{constructor(e,t){this.indexManager=e,this.referenceDelegate=t,this.mutationQueue=[],this.Yn=1,this.Hr=new D(W.Kr)}checkEmpty(e){return d.resolve(this.mutationQueue.length===0)}addMutationBatch(e,t,n,r){const i=this.Yn;this.Yn++,this.mutationQueue.length>0&&this.mutationQueue[this.mutationQueue.length-1];const o=new Ts(i,t,n,r);this.mutationQueue.push(o);for(const a of r)this.Hr=this.Hr.add(new W(a.key,i)),this.indexManager.addToCollectionParentIndex(e,a.key.path.popLast());return d.resolve(o)}lookupMutationBatch(e,t){return d.resolve(this.Zr(t))}getNextMutationBatchAfterBatchId(e,t){const n=t+1,r=this.Xr(n),i=r<0?0:r;return d.resolve(this.mutationQueue.length>i?this.mutationQueue[i]:null)}getHighestUnacknowledgedBatchId(){return d.resolve(this.mutationQueue.length===0?ze:this.Yn-1)}getAllMutationBatches(e){return d.resolve(this.mutationQueue.slice())}getAllMutationBatchesAffectingDocumentKey(e,t){const n=new W(t,0),r=new W(t,Number.POSITIVE_INFINITY),i=[];return this.Hr.forEachInRange([n,r],(o=>{const a=this.Zr(o.Jr);i.push(a)})),d.resolve(i)}getAllMutationBatchesAffectingDocumentKeys(e,t){let n=new D(V);return t.forEach((r=>{const i=new W(r,0),o=new W(r,Number.POSITIVE_INFINITY);this.Hr.forEachInRange([i,o],(a=>{n=n.add(a.Jr)}))})),d.resolve(this.Yr(n))}getAllMutationBatchesAffectingQuery(e,t){const n=t.path,r=n.length+1;let i=n;p.isDocumentKey(i)||(i=i.child(""));const o=new W(new p(i),0);let a=new D(V);return this.Hr.forEachWhile((u=>{const c=u.key.path;return!!n.isPrefixOf(c)&&(c.length===r&&(a=a.add(u.Jr)),!0)}),o),d.resolve(this.Yr(a))}Yr(e){const t=[];return e.forEach((n=>{const r=this.Zr(n);r!==null&&t.push(r)})),t}removeMutationBatch(e,t){T(this.ei(t.batchId,"removed")===0,55003),this.mutationQueue.shift();let n=this.Hr;return d.forEach(t.mutations,(r=>{const i=new W(r.key,t.batchId);return n=n.delete(i),this.referenceDelegate.markPotentiallyOrphaned(e,r.key)})).next((()=>{this.Hr=n}))}nr(e){}containsKey(e,t){const n=new W(t,0),r=this.Hr.firstAfterOrEqual(n);return d.resolve(t.isEqual(r&&r.key))}performConsistencyCheck(e){return this.mutationQueue.length,d.resolve()}ei(e,t){return this.Xr(e)}Xr(e){return this.mutationQueue.length===0?0:e-this.mutationQueue[0].batchId}Zr(e){const t=this.Xr(e);return t<0||t>=this.mutationQueue.length?null:this.mutationQueue[t]}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $l{constructor(e){this.ti=e,this.docs=(function(){return new k(p.comparator)})(),this.size=0}setIndexManager(e){this.indexManager=e}addEntry(e,t){const n=t.key,r=this.docs.get(n),i=r?r.size:0,o=this.ti(t);return this.docs=this.docs.insert(n,{document:t.mutableCopy(),size:o}),this.size+=o-i,this.indexManager.addToCollectionParentIndex(e,n.path.popLast())}removeEntry(e){const t=this.docs.get(e);t&&(this.docs=this.docs.remove(e),this.size-=t.size)}getEntry(e,t){const n=this.docs.get(t);return d.resolve(n?n.document.mutableCopy():F.newInvalidDocument(t))}getEntries(e,t){let n=ae();return t.forEach((r=>{const i=this.docs.get(r);n=n.insert(r,i?i.document.mutableCopy():F.newInvalidDocument(r))})),d.resolve(n)}getDocumentsMatchingQuery(e,t,n,r){let i=ae();const o=t.path,a=new p(o.child("__id-9223372036854775808__")),u=this.docs.getIteratorFrom(a);for(;u.hasNext();){const{key:c,value:{document:l}}=u.getNext();if(!o.isPrefixOf(c.path))break;c.path.length>o.length+1||os(go(l),n)<=0||(r.has(l.key)||gn(t,l))&&(i=i.insert(l.key,l.mutableCopy()))}return d.resolve(i)}getAllFromCollectionGroup(e,t,n,r){I(9500)}ni(e,t){return d.forEach(this.docs,(n=>t(n)))}newChangeBuffer(e){return new jl(this)}getSize(e){return d.resolve(this.size)}}class jl extends ba{constructor(e){super(),this.Mr=e}applyChanges(e){const t=[];return this.changes.forEach(((n,r)=>{r.isValidDocument()?t.push(this.Mr.addEntry(e,r)):this.Mr.removeEntry(n)})),d.waitFor(t)}getFromCache(e,t){return this.Mr.getEntry(e,t)}getAllFromCache(e,t){return this.Mr.getEntries(e,t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ql{constructor(e){this.persistence=e,this.ri=new Ce((t=>He(t)),_n),this.lastRemoteSnapshotVersion=A.min(),this.highestTargetId=0,this.ii=0,this.si=new Vs,this.targetCount=0,this.oi=Ee._r()}forEachTarget(e,t){return this.ri.forEach(((n,r)=>t(r))),d.resolve()}getLastRemoteSnapshotVersion(e){return d.resolve(this.lastRemoteSnapshotVersion)}getHighestSequenceNumber(e){return d.resolve(this.ii)}allocateTargetId(e){return this.highestTargetId=this.oi.next(),d.resolve(this.highestTargetId)}setTargetsMetadata(e,t,n){return n&&(this.lastRemoteSnapshotVersion=n),t>this.ii&&(this.ii=t),d.resolve()}lr(e){this.ri.set(e.target,e);const t=e.targetId;t>this.highestTargetId&&(this.oi=new Ee(t),this.highestTargetId=t),e.sequenceNumber>this.ii&&(this.ii=e.sequenceNumber)}addTargetData(e,t){return this.lr(t),this.targetCount+=1,d.resolve()}updateTargetData(e,t){return this.lr(t),d.resolve()}removeTargetData(e,t){return this.ri.delete(t.target),this.si.Gr(t.targetId),this.targetCount-=1,d.resolve()}removeTargets(e,t,n){let r=0;const i=[];return this.ri.forEach(((o,a)=>{a.sequenceNumber<=t&&n.get(a.targetId)===null&&(this.ri.delete(o),i.push(this.removeMatchingKeysForTargetId(e,a.targetId)),r++)})),d.waitFor(i).next((()=>r))}getTargetCount(e){return d.resolve(this.targetCount)}getTargetData(e,t){const n=this.ri.get(t)||null;return d.resolve(n)}addMatchingKeys(e,t,n){return this.si.$r(t,n),d.resolve()}removeMatchingKeys(e,t,n){this.si.Qr(t,n);const r=this.persistence.referenceDelegate,i=[];return r&&t.forEach((o=>{i.push(r.markPotentiallyOrphaned(e,o))})),d.waitFor(i)}removeMatchingKeysForTargetId(e,t){return this.si.Gr(t),d.resolve()}getMatchingKeysForTargetId(e,t){const n=this.si.jr(t);return d.resolve(n)}containsKey(e,t){return d.resolve(this.si.containsKey(t))}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ca{constructor(e,t){this._i={},this.overlays={},this.ai=new re(0),this.ui=!1,this.ui=!0,this.ci=new Kl,this.referenceDelegate=e(this),this.li=new Ql(this),this.indexManager=new xl,this.remoteDocumentCache=(function(r){return new $l(r)})((n=>this.referenceDelegate.hi(n))),this.serializer=new Ia(t),this.Pi=new ql(this.serializer)}start(){return Promise.resolve()}shutdown(){return this.ui=!1,Promise.resolve()}get started(){return this.ui}setDatabaseDeletedListener(){}setNetworkEnabled(){}getIndexManager(e){return this.indexManager}getDocumentOverlayCache(e){let t=this.overlays[e.toKey()];return t||(t=new zl,this.overlays[e.toKey()]=t),t}getMutationQueue(e,t){let n=this._i[e.toKey()];return n||(n=new Gl(t,this.referenceDelegate),this._i[e.toKey()]=n),n}getGlobalsCache(){return this.ci}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getBundleCache(){return this.Pi}runTransaction(e,t,n){g("MemoryPersistence","Starting transaction:",e);const r=new Wl(this.ai.next());return this.referenceDelegate.Ti(),n(r).next((i=>this.referenceDelegate.Ii(r).next((()=>i)))).toPromise().then((i=>(r.raiseOnCommittedEvent(),i)))}Ei(e,t){return d.or(Object.values(this._i).map((n=>()=>n.containsKey(e,t))))}}class Wl extends yo{constructor(e){super(),this.currentSequenceNumber=e}}class gr{constructor(e){this.persistence=e,this.Ri=new Vs,this.Ai=null}static Vi(e){return new gr(e)}get di(){if(this.Ai)return this.Ai;throw I(60996)}addReference(e,t,n){return this.Ri.addReference(n,t),this.di.delete(n.toString()),d.resolve()}removeReference(e,t,n){return this.Ri.removeReference(n,t),this.di.add(n.toString()),d.resolve()}markPotentiallyOrphaned(e,t){return this.di.add(t.toString()),d.resolve()}removeTarget(e,t){this.Ri.Gr(t.targetId).forEach((r=>this.di.add(r.toString())));const n=this.persistence.getTargetCache();return n.getMatchingKeysForTargetId(e,t.targetId).next((r=>{r.forEach((i=>this.di.add(i.toString())))})).next((()=>n.removeTargetData(e,t)))}Ti(){this.Ai=new Set}Ii(e){const t=this.persistence.getRemoteDocumentCache().newChangeBuffer();return d.forEach(this.di,(n=>{const r=p.fromPath(n);return this.mi(e,r).next((i=>{i||t.removeEntry(r,A.min())}))})).next((()=>(this.Ai=null,t.apply(e))))}updateLimboDocument(e,t){return this.mi(e,t).next((n=>{n?this.di.delete(t.toString()):this.di.add(t.toString())}))}hi(e){return 0}mi(e,t){return d.or([()=>d.resolve(this.Ri.containsKey(t)),()=>this.persistence.getTargetCache().containsKey(e,t),()=>this.persistence.Ei(e,t)])}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Hl{constructor(e){this.serializer=e}k(e,t,n,r){const i=new ir("createOrUpgrade",t);n<1&&r>=1&&((function(u){u.createObjectStore(mn)})(e),(function(u){u.createObjectStore(sn,{keyPath:ec}),u.createObjectStore(ce,{keyPath:Js,autoIncrement:!0}).createIndex(Ue,Ys,{unique:!0}),u.createObjectStore(yt)})(e),Ui(e),(function(u){u.createObjectStore(Me)})(e));let o=d.resolve();return n<3&&r>=3&&(n!==0&&((function(u){u.deleteObjectStore(Tt),u.deleteObjectStore(It),u.deleteObjectStore(Ke)})(e),Ui(e)),o=o.next((()=>(function(u){const c=u.store(Ke),l={highestTargetId:0,highestListenSequenceNumber:0,lastRemoteSnapshotVersion:A.min().toTimestamp(),targetCount:0};return c.put(qn,l)})(i)))),n<4&&r>=4&&(n!==0&&(o=o.next((()=>(function(u,c){return c.store(ce).J().next((h=>{u.deleteObjectStore(ce),u.createObjectStore(ce,{keyPath:Js,autoIncrement:!0}).createIndex(Ue,Ys,{unique:!0});const f=c.store(ce),_=h.map((R=>f.put(R)));return d.waitFor(_)}))})(e,i)))),o=o.next((()=>{(function(u){u.createObjectStore(Et,{keyPath:cc})})(e)}))),n<5&&r>=5&&(o=o.next((()=>this.gi(i)))),n<6&&r>=6&&(o=o.next((()=>((function(u){u.createObjectStore(on)})(e),this.pi(i))))),n<7&&r>=7&&(o=o.next((()=>this.yi(i)))),n<8&&r>=8&&(o=o.next((()=>this.wi(e,i)))),n<9&&r>=9&&(o=o.next((()=>{(function(u){u.objectStoreNames.contains("remoteDocumentChanges")&&u.deleteObjectStore("remoteDocumentChanges")})(e)}))),n<10&&r>=10&&(o=o.next((()=>this.Si(i)))),n<11&&r>=11&&(o=o.next((()=>{(function(u){u.createObjectStore(ar,{keyPath:lc})})(e),(function(u){u.createObjectStore(ur,{keyPath:hc})})(e)}))),n<12&&r>=12&&(o=o.next((()=>{(function(u){const c=u.createObjectStore(cr,{keyPath:yc});c.createIndex(kr,Ic,{unique:!1}),c.createIndex(vo,Tc,{unique:!1})})(e)}))),n<13&&r>=13&&(o=o.next((()=>(function(u){const c=u.createObjectStore(Un,{keyPath:nc});c.createIndex(xn,rc),c.createIndex(Eo,sc)})(e))).next((()=>this.bi(e,i))).next((()=>e.deleteObjectStore(Me)))),n<14&&r>=14&&(o=o.next((()=>this.Di(e,i)))),n<15&&r>=15&&(o=o.next((()=>(function(u){u.createObjectStore(cs,{keyPath:dc,autoIncrement:!0}).createIndex(Nr,fc,{unique:!1}),u.createObjectStore(Wt,{keyPath:mc}).createIndex(wo,_c,{unique:!1}),u.createObjectStore(Ht,{keyPath:gc}).createIndex(Ro,pc,{unique:!1})})(e)))),n<16&&r>=16&&(o=o.next((()=>{t.objectStore(Wt).clear()})).next((()=>{t.objectStore(Ht).clear()}))),n<17&&r>=17&&(o=o.next((()=>{(function(u){u.createObjectStore(ls,{keyPath:Ec})})(e)}))),n<18&&r>=18&&lo()&&(o=o.next((()=>{t.objectStore(Wt).clear()})).next((()=>{t.objectStore(Ht).clear()}))),o}pi(e){let t=0;return e.store(Me).ee(((n,r)=>{t+=Xn(r)})).next((()=>{const n={byteSize:t};return e.store(on).put(Cr,n)}))}gi(e){const t=e.store(sn),n=e.store(ce);return t.J().next((r=>d.forEach(r,(i=>{const o=IDBKeyRange.bound([i.userId,ze],[i.userId,i.lastAcknowledgedBatchId]);return n.J(Ue,o).next((a=>d.forEach(a,(u=>{T(u.userId===i.userId,18650,"Cannot process batch from unexpected user",{batchId:u.batchId});const c=Fe(this.serializer,u);return va(e,i.userId,c).next((()=>{}))}))))}))))}yi(e){const t=e.store(Tt),n=e.store(Me);return e.store(Ke).get(qn).next((r=>{const i=[];return n.ee(((o,a)=>{const u=new M(o),c=(function(h){return[0,ee(h)]})(u);i.push(t.get(c).next((l=>l?d.resolve():(h=>t.put({targetId:0,path:ee(h),sequenceNumber:r.highestListenSequenceNumber}))(u))))})).next((()=>d.waitFor(i)))}))}wi(e,t){e.createObjectStore(an,{keyPath:uc});const n=t.store(an),r=new vs,i=o=>{if(r.add(o)){const a=o.lastSegment(),u=o.popLast();return n.put({collectionId:a,parent:ee(u)})}};return t.store(Me).ee({Y:!0},((o,a)=>{const u=new M(o);return i(u.popLast())})).next((()=>t.store(yt).ee({Y:!0},(([o,a,u],c)=>{const l=fe(a);return i(l.popLast())}))))}Si(e){const t=e.store(It);return t.ee(((n,r)=>{const i=$t(r),o=Ta(this.serializer,i);return t.put(o)}))}bi(e,t){const n=t.store(Me),r=[];return n.ee(((i,o)=>{const a=t.store(Un),u=(function(h){return h.document?new p(M.fromString(h.document.name).popFirst(5)):h.noDocument?p.fromSegments(h.noDocument.path):h.unknownDocument?p.fromSegments(h.unknownDocument.path):I(36783)})(o).path.toArray(),c={prefixPath:u.slice(0,u.length-2),collectionGroup:u[u.length-2],documentId:u[u.length-1],readTime:o.readTime||[0,0],unknownDocument:o.unknownDocument,noDocument:o.noDocument,document:o.document,hasCommittedMutations:!!o.hasCommittedMutations};r.push(a.put(c))})).next((()=>d.waitFor(r)))}Di(e,t){const n=t.store(ce),r=xa(this.serializer),i=new Ca(gr.Vi,this.serializer.yt);return n.J().next((o=>{const a=new Map;return o.forEach((u=>{let c=a.get(u.userId)??S();Fe(this.serializer,u).keys().forEach((l=>c=c.add(l))),a.set(u.userId,c)})),d.forEach(a,((u,c)=>{const l=new J(c),h=mr.wt(this.serializer,l),f=i.getIndexManager(l),_=_r.wt(l,this.serializer,f,i.referenceDelegate);return new Da(r,_,h,f).recalculateAndSaveOverlaysForDocumentKeys(new Mr(t,re.ce),u).next()}))}))}}function Ui(s){s.createObjectStore(Tt,{keyPath:oc}).createIndex(us,ac,{unique:!0}),s.createObjectStore(It,{keyPath:"targetId"}).createIndex(Ao,ic,{unique:!0}),s.createObjectStore(Ke)}const ve="IndexedDbPersistence",Rr=18e5,vr=5e3,Vr="Failed to obtain exclusive access to the persistence layer. To allow shared access, multi-tab synchronization has to be enabled in all tabs. If you are using `experimentalForceOwningTab:true`, make sure that only one tab has persistence enabled at any given time.",Jl="main";class Ss{constructor(e,t,n,r,i,o,a,u,c,l,h=18){if(this.allowTabSynchronization=e,this.persistenceKey=t,this.clientId=n,this.Ci=i,this.window=o,this.document=a,this.Fi=c,this.Mi=l,this.xi=h,this.ai=null,this.ui=!1,this.isPrimary=!1,this.networkEnabled=!0,this.Oi=null,this.inForeground=!1,this.Ni=null,this.Bi=null,this.Li=Number.NEGATIVE_INFINITY,this.ki=f=>Promise.resolve(),!Ss.v())throw new y(m.UNIMPLEMENTED,"This platform is either missing IndexedDB or is known to have an incomplete implementation. Offline persistence has been disabled.");this.referenceDelegate=new Fl(this,r),this.Ki=t+Jl,this.serializer=new Ia(u),this.qi=new Pe(this.Ki,this.xi,new Hl(this.serializer)),this.ci=new Rl,this.li=new Cl(this.referenceDelegate,this.serializer),this.remoteDocumentCache=xa(this.serializer),this.Pi=new wl,this.window&&this.window.localStorage?this.Ui=this.window.localStorage:(this.Ui=null,l===!1&&H(ve,"LocalStorage is unavailable. As a result, persistence may not work reliably. In particular enablePersistence() could fail immediately after refreshing the page."))}start(){return this.$i().then((()=>{if(!this.isPrimary&&!this.allowTabSynchronization)throw new y(m.FAILED_PRECONDITION,Vr);return this.Wi(),this.Qi(),this.Gi(),this.runTransaction("getHighestListenSequenceNumber","readonly",(e=>this.li.getHighestSequenceNumber(e)))})).then((e=>{this.ai=new re(e,this.Fi)})).then((()=>{this.ui=!0})).catch((e=>(this.qi&&this.qi.close(),Promise.reject(e))))}zi(e){return this.ki=async t=>{if(this.started)return e(t)},e(this.isPrimary)}setDatabaseDeletedListener(e){this.qi.q((async t=>{t.newVersion===null&&await e()}))}setNetworkEnabled(e){this.networkEnabled!==e&&(this.networkEnabled=e,this.Ci.enqueueAndForget((async()=>{this.started&&await this.$i()})))}$i(){return this.runTransaction("updateClientMetadataAndTryBecomePrimary","readwrite",(e=>vn(e).put({clientId:this.clientId,updateTimeMs:Date.now(),networkEnabled:this.networkEnabled,inForeground:this.inForeground}).next((()=>{if(this.isPrimary)return this.ji(e).next((t=>{t||(this.isPrimary=!1,this.Ci.enqueueRetryable((()=>this.ki(!1))))}))})).next((()=>this.Ji(e))).next((t=>this.isPrimary&&!t?this.Hi(e).next((()=>!1)):!!t&&this.Zi(e).next((()=>!0)))))).catch((e=>{if(Ze(e))return g(ve,"Failed to extend owner lease: ",e),this.isPrimary;if(!this.allowTabSynchronization)throw e;return g(ve,"Releasing owner lease after error during lease refresh",e),!1})).then((e=>{this.isPrimary!==e&&this.Ci.enqueueRetryable((()=>this.ki(e))),this.isPrimary=e}))}ji(e){return qt(e).get(tt).next((t=>d.resolve(this.Xi(t))))}Yi(e){return vn(e).delete(this.clientId)}async es(){if(this.isPrimary&&!this.ts(this.Li,Rr)){this.Li=Date.now();const e=await this.runTransaction("maybeGarbageCollectMultiClientState","readwrite-primary",(t=>{const n=Q(t,Et);return n.J().next((r=>{const i=this.ns(r,Rr),o=r.filter((a=>i.indexOf(a)===-1));return d.forEach(o,(a=>n.delete(a.clientId))).next((()=>o))}))})).catch((()=>[]));if(this.Ui)for(const t of e)this.Ui.removeItem(this.rs(t.clientId))}}Gi(){this.Bi=this.Ci.enqueueAfterDelay("client_metadata_refresh",4e3,(()=>this.$i().then((()=>this.es())).then((()=>this.Gi()))))}Xi(e){return!!e&&e.ownerId===this.clientId}Ji(e){return this.Mi?d.resolve(!0):qt(e).get(tt).next((t=>{if(t!==null&&this.ts(t.leaseTimestampMs,vr)&&!this.ss(t.ownerId)){if(this.Xi(t)&&this.networkEnabled)return!0;if(!this.Xi(t)){if(!t.allowTabSynchronization)throw new y(m.FAILED_PRECONDITION,Vr);return!1}}return!(!this.networkEnabled||!this.inForeground)||vn(e).J().next((n=>this.ns(n,vr).find((r=>{if(this.clientId!==r.clientId){const i=!this.networkEnabled&&r.networkEnabled,o=!this.inForeground&&r.inForeground,a=this.networkEnabled===r.networkEnabled;if(i||o&&a)return!0}return!1}))===void 0))})).next((t=>(this.isPrimary!==t&&g(ve,`Client ${t?"is":"is not"} eligible for a primary lease.`),t)))}async shutdown(){this.ui=!1,this._s(),this.Bi&&(this.Bi.cancel(),this.Bi=null),this.us(),this.cs(),await this.qi.runTransaction("shutdown","readwrite",[mn,Et],(e=>{const t=new Mr(e,re.ce);return this.Hi(t).next((()=>this.Yi(t)))})),this.qi.close(),this.ls()}ns(e,t){return e.filter((n=>this.ts(n.updateTimeMs,t)&&!this.ss(n.clientId)))}hs(){return this.runTransaction("getActiveClients","readonly",(e=>vn(e).J().next((t=>this.ns(t,Rr).map((n=>n.clientId))))))}get started(){return this.ui}getGlobalsCache(){return this.ci}getMutationQueue(e,t){return _r.wt(e,this.serializer,t,this.referenceDelegate)}getTargetCache(){return this.li}getRemoteDocumentCache(){return this.remoteDocumentCache}getIndexManager(e){return new Dl(e,this.serializer.yt.databaseId)}getDocumentOverlayCache(e){return mr.wt(this.serializer,e)}getBundleCache(){return this.Pi}runTransaction(e,t,n){g(ve,"Starting transaction:",e);const r=t==="readonly"?"readonly":"readwrite",i=(function(u){return u===18?Rc:u===17?bo:u===16?wc:u===15?hs:u===14?Po:u===13?So:u===12?Ac:u===11?Vo:void I(60245)})(this.xi);let o;return this.qi.runTransaction(e,r,i,(a=>(o=new Mr(a,this.ai?this.ai.next():re.ce),t==="readwrite-primary"?this.ji(o).next((u=>!!u||this.Ji(o))).next((u=>{if(!u)throw H(`Failed to obtain primary lease for action '${e}'.`),this.isPrimary=!1,this.Ci.enqueueRetryable((()=>this.ki(!1))),new y(m.FAILED_PRECONDITION,po);return n(o)})).next((u=>this.Zi(o).next((()=>u)))):this.Ps(o).next((()=>n(o)))))).then((a=>(o.raiseOnCommittedEvent(),a)))}Ps(e){return qt(e).get(tt).next((t=>{if(t!==null&&this.ts(t.leaseTimestampMs,vr)&&!this.ss(t.ownerId)&&!this.Xi(t)&&!(this.Mi||this.allowTabSynchronization&&t.allowTabSynchronization))throw new y(m.FAILED_PRECONDITION,Vr)}))}Zi(e){const t={ownerId:this.clientId,allowTabSynchronization:this.allowTabSynchronization,leaseTimestampMs:Date.now()};return qt(e).put(tt,t)}static v(){return Pe.v()}Hi(e){const t=qt(e);return t.get(tt).next((n=>this.Xi(n)?(g(ve,"Releasing primary lease."),t.delete(tt)):d.resolve()))}ts(e,t){const n=Date.now();return!(e<n-t)&&(!(e>n)||(H(`Detected an update time that is in the future: ${e} > ${n}`),!1))}Wi(){this.document!==null&&typeof this.document.addEventListener=="function"&&(this.Ni=()=>{this.Ci.enqueueAndForget((()=>(this.inForeground=this.document.visibilityState==="visible",this.$i())))},this.document.addEventListener("visibilitychange",this.Ni),this.inForeground=this.document.visibilityState==="visible")}us(){this.Ni&&(this.document.removeEventListener("visibilitychange",this.Ni),this.Ni=null)}Qi(){typeof this.window?.addEventListener=="function"&&(this.Oi=()=>{this._s();const e=/(?:Version|Mobile)\/1[456]/;co()&&(navigator.appVersion.match(e)||navigator.userAgent.match(e))&&this.Ci.enterRestrictedMode(!0),this.Ci.enqueueAndForget((()=>this.shutdown()))},this.window.addEventListener("pagehide",this.Oi))}cs(){this.Oi&&(this.window.removeEventListener("pagehide",this.Oi),this.Oi=null)}ss(e){try{const t=this.Ui?.getItem(this.rs(e))!==null;return g(ve,`Client '${e}' ${t?"is":"is not"} zombied in LocalStorage`),t}catch(t){return H(ve,"Failed to get zombied client id.",t),!1}}_s(){if(this.Ui)try{this.Ui.setItem(this.rs(this.clientId),String(Date.now()))}catch(e){H("Failed to set zombie client id.",e)}}ls(){if(this.Ui)try{this.Ui.removeItem(this.rs(this.clientId))}catch{}}rs(e){return`firestore_zombie_${this.persistenceKey}_${e}`}}function qt(s){return Q(s,mn)}function vn(s){return Q(s,Et)}function Na(s,e){let t=s.projectId;return s.isDefaultDatabase||(t+="."+s.database),"firestore/"+e+"/"+t+"/"}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ps{constructor(e,t,n,r){this.targetId=e,this.fromCache=t,this.Ts=n,this.Is=r}static Es(e,t){let n=S(),r=S();for(const i of t.docChanges)switch(i.type){case 0:n=n.add(i.doc.key);break;case 1:r=r.add(i.doc.key)}return new Ps(e,t.fromCache,n,r)}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Yl{constructor(){this._documentReadCount=0}get documentReadCount(){return this._documentReadCount}incrementDocumentReadCount(e){this._documentReadCount+=e}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ka{constructor(){this.Rs=!1,this.As=!1,this.Vs=100,this.ds=(function(){return co()?8:Io(Fn())>0?6:4})()}initialize(e,t){this.fs=e,this.indexManager=t,this.Rs=!0}getDocumentsMatchingQuery(e,t,n,r){const i={result:null};return this.gs(e,t).next((o=>{i.result=o})).next((()=>{if(!i.result)return this.ps(e,t,r,n).next((o=>{i.result=o}))})).next((()=>{if(i.result)return;const o=new Yl;return this.ys(e,t,o).next((a=>{if(i.result=a,this.As)return this.ws(e,t,o,a.size)}))})).next((()=>i.result))}ws(e,t,n,r){return n.documentReadCount<this.Vs?(at()<=ye.DEBUG&&g("QueryEngine","SDK will not create cache indexes for query:",Ot(t),"since it only creates cache indexes for collection contains","more than or equal to",this.Vs,"documents"),d.resolve()):(at()<=ye.DEBUG&&g("QueryEngine","Query:",Ot(t),"scans",n.documentReadCount,"local documents and returns",r,"documents as results."),n.documentReadCount>this.ds*r?(at()<=ye.DEBUG&&g("QueryEngine","The SDK decides to create cache indexes for query:",Ot(t),"as using cache indexes may help improve performance."),this.indexManager.createTargetIndexes(e,ue(t))):d.resolve())}gs(e,t){if(li(t))return d.resolve(null);let n=ue(t);return this.indexManager.getIndexType(e,n).next((r=>r===0?null:(t.limit!==null&&r===1&&(t=qr(t,null,"F"),n=ue(t)),this.indexManager.getDocumentsMatchingTarget(e,n).next((i=>{const o=S(...i);return this.fs.getDocuments(e,o).next((a=>this.indexManager.getMinOffset(e,n).next((u=>{const c=this.Ss(t,a);return this.bs(t,c,o,u.readTime)?this.gs(e,qr(t,null,"F")):this.Ds(e,c,t,u)}))))})))))}ps(e,t,n,r){return li(t)||r.isEqual(A.min())?d.resolve(null):this.fs.getDocuments(e,n).next((i=>{const o=this.Ss(t,i);return this.bs(t,o,n,r)?d.resolve(null):(at()<=ye.DEBUG&&g("QueryEngine","Re-using previous result from %s to execute query: %s",r.toString(),Ot(t)),this.Ds(e,o,t,_o(r,pt)).next((a=>a)))}))}Ss(e,t){let n=new D(Yo(e));return t.forEach(((r,i)=>{gn(e,i)&&(n=n.add(i))})),n}bs(e,t,n,r){if(e.limit===null)return!1;if(n.size!==t.size)return!0;const i=e.limitType==="F"?t.last():t.first();return!!i&&(i.hasPendingWrites||i.version.compareTo(r)>0)}ys(e,t,n){return at()<=ye.DEBUG&&g("QueryEngine","Using full collection scan to execute query:",Ot(t)),this.fs.getDocumentsMatchingQuery(e,t,ie.min(),n)}Ds(e,t,n,r){return this.fs.getDocumentsMatchingQuery(e,n,r).next((i=>(t.forEach((o=>{i=i.insert(o.key,o)})),i)))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const bs="LocalStore",Xl=3e8;class Zl{constructor(e,t,n,r){this.persistence=e,this.Cs=t,this.serializer=r,this.vs=new k(V),this.Fs=new Ce((i=>He(i)),_n),this.Ms=new Map,this.xs=e.getRemoteDocumentCache(),this.li=e.getTargetCache(),this.Pi=e.getBundleCache(),this.Os(n)}Os(e){this.documentOverlayCache=this.persistence.getDocumentOverlayCache(e),this.indexManager=this.persistence.getIndexManager(e),this.mutationQueue=this.persistence.getMutationQueue(e,this.indexManager),this.localDocuments=new Da(this.xs,this.mutationQueue,this.documentOverlayCache,this.indexManager),this.xs.setIndexManager(this.indexManager),this.Cs.initialize(this.localDocuments,this.indexManager)}collectGarbage(e){return this.persistence.runTransaction("Collect garbage","readwrite-primary",(t=>e.collect(t,this.vs)))}}function Ma(s,e,t,n){return new Zl(s,e,t,n)}async function eh(s,e){const t=E(s);return await t.persistence.runTransaction("Handle user change","readonly",(n=>{let r;return t.mutationQueue.getAllMutationBatches(n).next((i=>(r=i,t.Os(e),t.mutationQueue.getAllMutationBatches(n)))).next((i=>{const o=[],a=[];let u=S();for(const c of r){o.push(c.batchId);for(const l of c.mutations)u=u.add(l.key)}for(const c of i){a.push(c.batchId);for(const l of c.mutations)u=u.add(l.key)}return t.localDocuments.getDocuments(n,u).next((c=>({Ns:c,removedBatchIds:o,addedBatchIds:a})))}))}))}function th(s,e){const t=E(s);return t.persistence.runTransaction("Acknowledge batch","readwrite-primary",(n=>{const r=e.batch.keys(),i=t.xs.newChangeBuffer({trackRemovals:!0});return(function(a,u,c,l){const h=c.batch,f=h.keys();let _=d.resolve();return f.forEach((R=>{_=_.next((()=>l.getEntry(u,R))).next((w=>{const v=c.docVersions.get(R);T(v!==null,48541),w.version.compareTo(v)<0&&(h.applyToRemoteDocument(w,c),w.isValidDocument()&&(w.setReadTime(c.commitVersion),l.addEntry(w)))}))})),_.next((()=>a.mutationQueue.removeMutationBatch(u,h)))})(t,n,e,i).next((()=>i.apply(n))).next((()=>t.mutationQueue.performConsistencyCheck(n))).next((()=>t.documentOverlayCache.removeOverlaysForBatchId(n,r,e.batch.batchId))).next((()=>t.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(n,(function(a){let u=S();for(let c=0;c<a.mutationResults.length;++c)a.mutationResults[c].transformResults.length>0&&(u=u.add(a.batch.mutations[c].key));return u})(e)))).next((()=>t.localDocuments.getDocuments(n,r)))}))}function Oa(s){const e=E(s);return e.persistence.runTransaction("Get last remote snapshot version","readonly",(t=>e.li.getLastRemoteSnapshotVersion(t)))}function nh(s,e){const t=E(s),n=e.snapshotVersion;let r=t.vs;return t.persistence.runTransaction("Apply remote event","readwrite-primary",(i=>{const o=t.xs.newChangeBuffer({trackRemovals:!0});r=t.vs;const a=[];e.targetChanges.forEach(((l,h)=>{const f=r.get(h);if(!f)return;a.push(t.li.removeMatchingKeys(i,l.removedDocuments,h).next((()=>t.li.addMatchingKeys(i,l.addedDocuments,h))));let _=f.withSequenceNumber(i.currentSequenceNumber);e.targetMismatches.get(h)!==null?_=_.withResumeToken(U.EMPTY_BYTE_STRING,A.min()).withLastLimboFreeSnapshotVersion(A.min()):l.resumeToken.approximateByteSize()>0&&(_=_.withResumeToken(l.resumeToken,n)),r=r.insert(h,_),(function(w,v,L){return w.resumeToken.approximateByteSize()===0||v.snapshotVersion.toMicroseconds()-w.snapshotVersion.toMicroseconds()>=Xl?!0:L.addedDocuments.size+L.modifiedDocuments.size+L.removedDocuments.size>0})(f,_,l)&&a.push(t.li.updateTargetData(i,_))}));let u=ae(),c=S();if(e.documentUpdates.forEach((l=>{e.resolvedLimboDocuments.has(l)&&a.push(t.persistence.referenceDelegate.updateLimboDocument(i,l))})),a.push(rh(i,o,e.documentUpdates).next((l=>{u=l.Bs,c=l.Ls}))),!n.isEqual(A.min())){const l=t.li.getLastRemoteSnapshotVersion(i).next((h=>t.li.setTargetsMetadata(i,i.currentSequenceNumber,n)));a.push(l)}return d.waitFor(a).next((()=>o.apply(i))).next((()=>t.localDocuments.getLocalViewOfDocuments(i,u,c))).next((()=>u))})).then((i=>(t.vs=r,i)))}function rh(s,e,t){let n=S(),r=S();return t.forEach((i=>n=n.add(i))),e.getEntries(s,n).next((i=>{let o=ae();return t.forEach(((a,u)=>{const c=i.get(a);u.isFoundDocument()!==c.isFoundDocument()&&(r=r.add(a)),u.isNoDocument()&&u.version.isEqual(A.min())?(e.removeEntry(a,u.readTime),o=o.insert(a,u)):!c.isValidDocument()||u.version.compareTo(c.version)>0||u.version.compareTo(c.version)===0&&c.hasPendingWrites?(e.addEntry(u),o=o.insert(a,u)):g(bs,"Ignoring outdated watch update for ",a,". Current version:",c.version," Watch version:",u.version)})),{Bs:o,Ls:r}}))}function sh(s,e){const t=E(s);return t.persistence.runTransaction("Get next mutation batch","readonly",(n=>(e===void 0&&(e=ze),t.mutationQueue.getNextMutationBatchAfterBatchId(n,e))))}function Hr(s,e){const t=E(s);return t.persistence.runTransaction("Allocate target","readwrite",(n=>{let r;return t.li.getTargetData(n,e).next((i=>i?(r=i,d.resolve(r)):t.li.allocateTargetId(n).next((o=>(r=new _e(e,o,"TargetPurposeListen",n.currentSequenceNumber),t.li.addTargetData(n,r).next((()=>r)))))))})).then((n=>{const r=t.vs.get(n.targetId);return(r===null||n.snapshotVersion.compareTo(r.snapshotVersion)>0)&&(t.vs=t.vs.insert(n.targetId,n),t.Fs.set(e,n.targetId)),n}))}async function pr(s,e,t){const n=E(s),r=n.vs.get(e),i=t?"readwrite":"readwrite-primary";try{t||await n.persistence.runTransaction("Release target",i,(o=>n.persistence.referenceDelegate.removeTarget(o,r)))}catch(o){if(!Ze(o))throw o;g(bs,`Failed to update sequence numbers for target ${e}: ${o}`)}n.vs=n.vs.remove(e),n.Fs.delete(r.target)}function Jr(s,e,t){const n=E(s);let r=A.min(),i=S();return n.persistence.runTransaction("Execute query","readwrite",(o=>(function(u,c,l){const h=E(u),f=h.Fs.get(l);return f!==void 0?d.resolve(h.vs.get(f)):h.li.getTargetData(c,l)})(n,o,ue(e)).next((a=>{if(a)return r=a.lastLimboFreeSnapshotVersion,n.li.getMatchingKeysForTargetId(o,a.targetId).next((u=>{i=u}))})).next((()=>n.Cs.getDocumentsMatchingQuery(o,e,t?r:A.min(),t?i:S()))).next((a=>(Ba(n,Jo(e),a),{documents:a,ks:i})))))}function Fa(s,e){const t=E(s),n=E(t.li),r=t.vs.get(e);return r?Promise.resolve(r.target):t.persistence.runTransaction("Get target data","readonly",(i=>n.At(i,e).next((o=>o?o.target:null))))}function La(s,e){const t=E(s),n=t.Ms.get(e)||A.min();return t.persistence.runTransaction("Get new document changes","readonly",(r=>t.xs.getAllFromCollectionGroup(r,e,_o(n,pt),Number.MAX_SAFE_INTEGER))).then((r=>(Ba(t,e,r),r)))}function Ba(s,e,t){let n=s.Ms.get(e)||A.min();t.forEach(((r,i)=>{i.readTime.compareTo(n)>0&&(n=i.readTime)})),s.Ms.set(e,n)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ua="firestore_clients";function qi(s,e){return`${Ua}_${s}_${e}`}const qa="firestore_mutations";function zi(s,e,t){let n=`${qa}_${s}_${t}`;return e.isAuthenticated()&&(n+=`_${e.uid}`),n}const za="firestore_targets";function Sr(s,e){return`${za}_${s}_${e}`}/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const de="SharedClientState";class Zn{constructor(e,t,n,r){this.user=e,this.batchId=t,this.state=n,this.error=r}static $s(e,t,n){const r=JSON.parse(n);let i,o=typeof r=="object"&&["pending","acknowledged","rejected"].indexOf(r.state)!==-1&&(r.error===void 0||typeof r.error=="object");return o&&r.error&&(o=typeof r.error.message=="string"&&typeof r.error.code=="string",o&&(i=new y(r.error.code,r.error.message))),o?new Zn(e,t,r.state,i):(H(de,`Failed to parse mutation state for ID '${t}': ${n}`),null)}Ws(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class en{constructor(e,t,n){this.targetId=e,this.state=t,this.error=n}static $s(e,t){const n=JSON.parse(t);let r,i=typeof n=="object"&&["not-current","current","rejected"].indexOf(n.state)!==-1&&(n.error===void 0||typeof n.error=="object");return i&&n.error&&(i=typeof n.error.message=="string"&&typeof n.error.code=="string",i&&(r=new y(n.error.code,n.error.message))),i?new en(e,n.state,r):(H(de,`Failed to parse target state for ID '${e}': ${t}`),null)}Ws(){const e={state:this.state,updateTimeMs:Date.now()};return this.error&&(e.error={code:this.error.code,message:this.error.message}),JSON.stringify(e)}}class er{constructor(e,t){this.clientId=e,this.activeTargetIds=t}static $s(e,t){const n=JSON.parse(t);let r=typeof n=="object"&&n.activeTargetIds instanceof Array,i=ys();for(let o=0;r&&o<n.activeTargetIds.length;++o)r=Xu(n.activeTargetIds[o]),i=i.add(n.activeTargetIds[o]);return r?new er(e,i):(H(de,`Failed to parse client data for instance '${e}': ${t}`),null)}}class xs{constructor(e,t){this.clientId=e,this.onlineState=t}static $s(e){const t=JSON.parse(e);return typeof t=="object"&&["Unknown","Online","Offline"].indexOf(t.onlineState)!==-1&&typeof t.clientId=="string"?new xs(t.clientId,t.onlineState):(H(de,`Failed to parse online state: ${e}`),null)}}class Yr{constructor(){this.activeTargetIds=ys()}Qs(e){this.activeTargetIds=this.activeTargetIds.add(e)}Gs(e){this.activeTargetIds=this.activeTargetIds.delete(e)}Ws(){const e={activeTargetIds:this.activeTargetIds.toArray(),updateTimeMs:Date.now()};return JSON.stringify(e)}}class Pr{constructor(e,t,n,r,i){this.window=e,this.Ci=t,this.persistenceKey=n,this.zs=r,this.syncEngine=null,this.onlineStateHandler=null,this.sequenceNumberHandler=null,this.js=this.Js.bind(this),this.Hs=new k(V),this.started=!1,this.Zs=[];const o=n.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");this.storage=this.window.localStorage,this.currentUser=i,this.Xs=qi(this.persistenceKey,this.zs),this.Ys=(function(u){return`firestore_sequence_number_${u}`})(this.persistenceKey),this.Hs=this.Hs.insert(this.zs,new Yr),this.eo=new RegExp(`^${Ua}_${o}_([^_]*)$`),this.no=new RegExp(`^${qa}_${o}_(\\d+)(?:_(.*))?$`),this.ro=new RegExp(`^${za}_${o}_(\\d+)$`),this.io=(function(u){return`firestore_online_state_${u}`})(this.persistenceKey),this.so=(function(u){return`firestore_bundle_loaded_v2_${u}`})(this.persistenceKey),this.window.addEventListener("storage",this.js)}static v(e){return!(!e||!e.localStorage)}async start(){const e=await this.syncEngine.hs();for(const n of e){if(n===this.zs)continue;const r=this.getItem(qi(this.persistenceKey,n));if(r){const i=er.$s(n,r);i&&(this.Hs=this.Hs.insert(i.clientId,i))}}this.oo();const t=this.storage.getItem(this.io);if(t){const n=this._o(t);n&&this.ao(n)}for(const n of this.Zs)this.Js(n);this.Zs=[],this.window.addEventListener("pagehide",(()=>this.shutdown())),this.started=!0}writeSequenceNumber(e){this.setItem(this.Ys,JSON.stringify(e))}getAllActiveQueryTargets(){return this.uo(this.Hs)}isActiveQueryTarget(e){let t=!1;return this.Hs.forEach(((n,r)=>{r.activeTargetIds.has(e)&&(t=!0)})),t}addPendingMutation(e){this.co(e,"pending")}updateMutationState(e,t,n){this.co(e,t,n),this.lo(e)}addLocalQueryTarget(e,t=!0){let n="not-current";if(this.isActiveQueryTarget(e)){const r=this.storage.getItem(Sr(this.persistenceKey,e));if(r){const i=en.$s(e,r);i&&(n=i.state)}}return t&&this.ho.Qs(e),this.oo(),n}removeLocalQueryTarget(e){this.ho.Gs(e),this.oo()}isLocalQueryTarget(e){return this.ho.activeTargetIds.has(e)}clearQueryState(e){this.removeItem(Sr(this.persistenceKey,e))}updateQueryState(e,t,n){this.Po(e,t,n)}handleUserChange(e,t,n){t.forEach((r=>{this.lo(r)})),this.currentUser=e,n.forEach((r=>{this.addPendingMutation(r)}))}setOnlineState(e){this.To(e)}notifyBundleLoaded(e){this.Io(e)}shutdown(){this.started&&(this.window.removeEventListener("storage",this.js),this.removeItem(this.Xs),this.started=!1)}getItem(e){const t=this.storage.getItem(e);return g(de,"READ",e,t),t}setItem(e,t){g(de,"SET",e,t),this.storage.setItem(e,t)}removeItem(e){g(de,"REMOVE",e),this.storage.removeItem(e)}Js(e){const t=e;if(t.storageArea===this.storage){if(g(de,"EVENT",t.key,t.newValue),t.key===this.Xs)return void H("Received WebStorage notification for local change. Another client might have garbage-collected our state");this.Ci.enqueueRetryable((async()=>{if(this.started){if(t.key!==null){if(this.eo.test(t.key)){if(t.newValue==null){const n=this.Eo(t.key);return this.Ro(n,null)}{const n=this.Ao(t.key,t.newValue);if(n)return this.Ro(n.clientId,n)}}else if(this.no.test(t.key)){if(t.newValue!==null){const n=this.Vo(t.key,t.newValue);if(n)return this.mo(n)}}else if(this.ro.test(t.key)){if(t.newValue!==null){const n=this.fo(t.key,t.newValue);if(n)return this.po(n)}}else if(t.key===this.io){if(t.newValue!==null){const n=this._o(t.newValue);if(n)return this.ao(n)}}else if(t.key===this.Ys){const n=(function(i){let o=re.ce;if(i!=null)try{const a=JSON.parse(i);T(typeof a=="number",30636,{yo:i}),o=a}catch(a){H(de,"Failed to read sequence number from WebStorage",a)}return o})(t.newValue);n!==re.ce&&this.sequenceNumberHandler(n)}else if(t.key===this.so){const n=this.wo(t.newValue);await Promise.all(n.map((r=>this.syncEngine.So(r))))}}}else this.Zs.push(t)}))}}get ho(){return this.Hs.get(this.zs)}oo(){this.setItem(this.Xs,this.ho.Ws())}co(e,t,n){const r=new Zn(this.currentUser,e,t,n),i=zi(this.persistenceKey,this.currentUser,e);this.setItem(i,r.Ws())}lo(e){const t=zi(this.persistenceKey,this.currentUser,e);this.removeItem(t)}To(e){const t={clientId:this.zs,onlineState:e};this.storage.setItem(this.io,JSON.stringify(t))}Po(e,t,n){const r=Sr(this.persistenceKey,e),i=new en(e,t,n);this.setItem(r,i.Ws())}Io(e){const t=JSON.stringify(Array.from(e));this.setItem(this.so,t)}Eo(e){const t=this.eo.exec(e);return t?t[1]:null}Ao(e,t){const n=this.Eo(e);return er.$s(n,t)}Vo(e,t){const n=this.no.exec(e),r=Number(n[1]),i=n[2]!==void 0?n[2]:null;return Zn.$s(new J(i),r,t)}fo(e,t){const n=this.ro.exec(e),r=Number(n[1]);return en.$s(r,t)}_o(e){return xs.$s(e)}wo(e){return JSON.parse(e)}async mo(e){if(e.user.uid===this.currentUser.uid)return this.syncEngine.bo(e.batchId,e.state,e.error);g(de,`Ignoring mutation for non-active user ${e.user.uid}`)}po(e){return this.syncEngine.Do(e.targetId,e.state,e.error)}Ro(e,t){const n=t?this.Hs.insert(e,t):this.Hs.remove(e),r=this.uo(this.Hs),i=this.uo(n),o=[],a=[];return i.forEach((u=>{r.has(u)||o.push(u)})),r.forEach((u=>{i.has(u)||a.push(u)})),this.syncEngine.Co(o,a).then((()=>{this.Hs=n}))}ao(e){this.Hs.get(e.clientId)&&this.onlineStateHandler(e.onlineState)}uo(e){let t=ys();return e.forEach(((n,r)=>{t=t.unionWith(r.activeTargetIds)})),t}}class Ka{constructor(){this.vo=new Yr,this.Fo={},this.onlineStateHandler=null,this.sequenceNumberHandler=null}addPendingMutation(e){}updateMutationState(e,t,n){}addLocalQueryTarget(e,t=!0){return t&&this.vo.Qs(e),this.Fo[e]||"not-current"}updateQueryState(e,t,n){this.Fo[e]=t}removeLocalQueryTarget(e){this.vo.Gs(e)}isLocalQueryTarget(e){return this.vo.activeTargetIds.has(e)}clearQueryState(e){delete this.Fo[e]}getAllActiveQueryTargets(){return this.vo.activeTargetIds}isActiveQueryTarget(e){return this.vo.activeTargetIds.has(e)}start(){return this.vo=new Yr,Promise.resolve()}handleUserChange(e,t,n){}setOnlineState(e){}shutdown(){}writeSequenceNumber(e){}notifyBundleLoaded(e){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ih{Mo(e){}shutdown(){}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ki="ConnectivityMonitor";class Gi{constructor(){this.xo=()=>this.Oo(),this.No=()=>this.Bo(),this.Lo=[],this.ko()}Mo(e){this.Lo.push(e)}shutdown(){window.removeEventListener("online",this.xo),window.removeEventListener("offline",this.No)}ko(){window.addEventListener("online",this.xo),window.addEventListener("offline",this.No)}Oo(){g(Ki,"Network connectivity changed: AVAILABLE");for(const e of this.Lo)e(0)}Bo(){g(Ki,"Network connectivity changed: UNAVAILABLE");for(const e of this.Lo)e(1)}static v(){return typeof window<"u"&&window.addEventListener!==void 0&&window.removeEventListener!==void 0}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let Vn=null;function Xr(){return Vn===null?Vn=(function(){return 268435456+Math.round(2147483648*Math.random())})():Vn++,"0x"+Vn.toString(16)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const br="RestConnection",oh={BatchGetDocuments:"batchGet",Commit:"commit",RunQuery:"runQuery",RunAggregationQuery:"runAggregationQuery",ExecutePipeline:"executePipeline"};class ah{get Ko(){return!1}constructor(e){this.databaseInfo=e,this.databaseId=e.databaseId;const t=e.ssl?"https":"http",n=encodeURIComponent(this.databaseId.projectId),r=encodeURIComponent(this.databaseId.database);this.qo=t+"://"+e.host,this.Uo=`projects/${n}/databases/${r}`,this.$o=this.databaseId.database===un?`project_id=${n}`:`project_id=${n}&database_id=${r}`}Wo(e,t,n,r,i){const o=Xr(),a=this.Qo(e,t.toUriEncodedString());g(br,`Sending RPC '${e}' ${o}:`,a,n);const u={"google-cloud-resource-prefix":this.Uo,"x-goog-request-params":this.$o};this.Go(u,r,i);const{host:c}=new URL(a),l=ss(c);return this.zo(e,a,u,n,l).then((h=>(g(br,`Received RPC '${e}' ${o}: `,h),h)),(h=>{throw _t(br,`RPC '${e}' ${o} failed with error: `,h,"url: ",a,"request:",n),h}))}jo(e,t,n,r,i,o){return this.Wo(e,t,n,r,i)}Go(e,t,n){e["X-Goog-Api-Client"]=(function(){return"gl-js/ fire/"+bt})(),e["Content-Type"]="text/plain",this.databaseInfo.appId&&(e["X-Firebase-GMPID"]=this.databaseInfo.appId),t&&t.headers.forEach(((r,i)=>e[i]=r)),n&&n.headers.forEach(((r,i)=>e[i]=r))}Qo(e,t){const n=oh[e];let r=`${this.qo}/v1/${t}:${n}`;return this.databaseInfo.apiKey&&(r=`${r}?key=${encodeURIComponent(this.databaseInfo.apiKey)}`),r}terminate(){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class uh{constructor(e){this.Jo=e.Jo,this.Ho=e.Ho}Zo(e){this.Xo=e}Yo(e){this.e_=e}t_(e){this.n_=e}onMessage(e){this.r_=e}close(){this.Ho()}send(e){this.Jo(e)}i_(){this.Xo()}s_(){this.e_()}o_(e){this.n_(e)}__(e){this.r_(e)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Z="WebChannelConnection",zt=(s,e,t)=>{s.listen(e,(n=>{try{t(n)}catch(r){setTimeout((()=>{throw r}),0)}}))};class dt extends ah{constructor(e){super(e),this.a_=[],this.forceLongPolling=e.forceLongPolling,this.autoDetectLongPolling=e.autoDetectLongPolling,this.useFetchStreams=e.useFetchStreams,this.longPollingOptions=e.longPollingOptions}static u_(){if(!dt.c_){const e=Iu();zt(e,Tu.STAT_EVENT,(t=>{t.stat===zs.PROXY?g(Z,"STAT_EVENT: detected buffering proxy"):t.stat===zs.NOPROXY&&g(Z,"STAT_EVENT: detected no buffering proxy")})),dt.c_=!0}}zo(e,t,n,r,i){const o=Xr();return new Promise(((a,u)=>{const c=new Eu;c.setWithCredentials(!0),c.listenOnce(Au.COMPLETE,(()=>{try{switch(c.getLastErrorCode()){case Tr.NO_ERROR:const h=c.getResponseJson();g(Z,`XHR for RPC '${e}' ${o} received:`,JSON.stringify(h)),a(h);break;case Tr.TIMEOUT:g(Z,`RPC '${e}' ${o} timed out`),u(new y(m.DEADLINE_EXCEEDED,"Request time out"));break;case Tr.HTTP_ERROR:const f=c.getStatus();if(g(Z,`RPC '${e}' ${o} failed with status:`,f,"response text:",c.getResponseText()),f>0){let _=c.getResponseJson();Array.isArray(_)&&(_=_[0]);const R=_?.error;if(R&&R.status&&R.message){const w=(function(L){const N=L.toLowerCase().replace(/_/g,"-");return Object.values(m).indexOf(N)>=0?N:m.UNKNOWN})(R.status);u(new y(w,R.message))}else u(new y(m.UNKNOWN,"Server responded with status "+c.getStatus()))}else u(new y(m.UNAVAILABLE,"Connection failed."));break;default:I(9055,{l_:e,streamId:o,h_:c.getLastErrorCode(),P_:c.getLastError()})}}finally{g(Z,`RPC '${e}' ${o} completed.`)}}));const l=JSON.stringify(r);g(Z,`RPC '${e}' ${o} sending request:`,r),c.send(t,"POST",l,n,15)}))}T_(e,t,n){const r=Xr(),i=[this.qo,"/","google.firestore.v1.Firestore","/",e,"/channel"],o=this.createWebChannelTransport(),a={httpSessionIdParam:"gsessionid",initMessageHeaders:{},messageUrlParams:{database:`projects/${this.databaseId.projectId}/databases/${this.databaseId.database}`},sendRawJson:!0,supportsCrossDomainXhr:!0,internalChannelParams:{forwardChannelRequestTimeoutMs:6e5},forceLongPolling:this.forceLongPolling,detectBufferingProxy:this.autoDetectLongPolling},u=this.longPollingOptions.timeoutSeconds;u!==void 0&&(a.longPollingTimeout=Math.round(1e3*u)),this.useFetchStreams&&(a.useFetchStreams=!0),this.Go(a.initMessageHeaders,t,n),a.encodeInitMessageHeaders=!0;const c=i.join("");g(Z,`Creating RPC '${e}' stream ${r}: ${c}`,a);const l=o.createWebChannel(c,a);this.I_(l);let h=!1,f=!1;const _=new uh({Jo:R=>{f?g(Z,`Not sending because RPC '${e}' stream ${r} is closed:`,R):(h||(g(Z,`Opening RPC '${e}' stream ${r} transport.`),l.open(),h=!0),g(Z,`RPC '${e}' stream ${r} sending:`,R),l.send(R))},Ho:()=>l.close()});return zt(l,Tn.EventType.OPEN,(()=>{f||(g(Z,`RPC '${e}' stream ${r} transport opened.`),_.i_())})),zt(l,Tn.EventType.CLOSE,(()=>{f||(f=!0,g(Z,`RPC '${e}' stream ${r} transport closed`),_.o_(),this.E_(l))})),zt(l,Tn.EventType.ERROR,(R=>{f||(f=!0,_t(Z,`RPC '${e}' stream ${r} transport errored. Name:`,R.name,"Message:",R.message),_.o_(new y(m.UNAVAILABLE,"The operation could not be completed")))})),zt(l,Tn.EventType.MESSAGE,(R=>{if(!f){const w=R.data[0];T(!!w,16349);const v=w,L=v?.error||v[0]?.error;if(L){g(Z,`RPC '${e}' stream ${r} received error:`,L);const N=L.status;let x=(function(z){const X=K[z];if(X!==void 0)return oa(X)})(N),q=L.message;N==="NOT_FOUND"&&q.includes("database")&&q.includes("does not exist")&&q.includes(this.databaseId.database)&&_t(`Database '${this.databaseId.database}' not found. Please check your project configuration.`),x===void 0&&(x=m.INTERNAL,q="Unknown error status: "+N+" with message "+L.message),f=!0,_.o_(new y(x,q)),l.close()}else g(Z,`RPC '${e}' stream ${r} received:`,w),_.__(w)}})),dt.u_(),setTimeout((()=>{_.s_()}),0),_}terminate(){this.a_.forEach((e=>e.close())),this.a_=[]}I_(e){this.a_.push(e)}E_(e){this.a_=this.a_.filter((t=>t===e))}Go(e,t,n){super.Go(e,t,n),this.databaseInfo.apiKey&&(e["x-goog-api-key"]=this.databaseInfo.apiKey)}createWebChannelTransport(){return wu()}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function ch(s){return new dt(s)}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ga(){return typeof window<"u"?window:null}function Mn(){return typeof document<"u"?document:null}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $a(s){return new ll(s,!0)}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */dt.c_=!1;class ja{constructor(e,t,n=1e3,r=1.5,i=6e4){this.Ci=e,this.timerId=t,this.R_=n,this.A_=r,this.V_=i,this.d_=0,this.m_=null,this.f_=Date.now(),this.reset()}reset(){this.d_=0}g_(){this.d_=this.V_}p_(e){this.cancel();const t=Math.floor(this.d_+this.y_()),n=Math.max(0,Date.now()-this.f_),r=Math.max(0,t-n);r>0&&g("ExponentialBackoff",`Backing off for ${r} ms (base delay: ${this.d_} ms, delay with jitter: ${t} ms, last attempt: ${n} ms ago)`),this.m_=this.Ci.enqueueAfterDelay(this.timerId,r,(()=>(this.f_=Date.now(),e()))),this.d_*=this.A_,this.d_<this.R_&&(this.d_=this.R_),this.d_>this.V_&&(this.d_=this.V_)}w_(){this.m_!==null&&(this.m_.skipDelay(),this.m_=null)}cancel(){this.m_!==null&&(this.m_.cancel(),this.m_=null)}y_(){return(Math.random()-.5)*this.d_}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const $i="PersistentStream";class Qa{constructor(e,t,n,r,i,o,a,u){this.Ci=e,this.S_=n,this.b_=r,this.connection=i,this.authCredentialsProvider=o,this.appCheckCredentialsProvider=a,this.listener=u,this.state=0,this.D_=0,this.C_=null,this.v_=null,this.stream=null,this.F_=0,this.M_=new ja(e,t)}x_(){return this.state===1||this.state===5||this.O_()}O_(){return this.state===2||this.state===3}start(){this.F_=0,this.state!==4?this.auth():this.N_()}async stop(){this.x_()&&await this.close(0)}B_(){this.state=0,this.M_.reset()}L_(){this.O_()&&this.C_===null&&(this.C_=this.Ci.enqueueAfterDelay(this.S_,6e4,(()=>this.k_())))}K_(e){this.q_(),this.stream.send(e)}async k_(){if(this.O_())return this.close(0)}q_(){this.C_&&(this.C_.cancel(),this.C_=null)}U_(){this.v_&&(this.v_.cancel(),this.v_=null)}async close(e,t){this.q_(),this.U_(),this.M_.cancel(),this.D_++,e!==4?this.M_.reset():t&&t.code===m.RESOURCE_EXHAUSTED?(H(t.toString()),H("Using maximum backoff delay to prevent overloading the backend."),this.M_.g_()):t&&t.code===m.UNAUTHENTICATED&&this.state!==3&&(this.authCredentialsProvider.invalidateToken(),this.appCheckCredentialsProvider.invalidateToken()),this.stream!==null&&(this.W_(),this.stream.close(),this.stream=null),this.state=e,await this.listener.t_(t)}W_(){}auth(){this.state=1;const e=this.Q_(this.D_),t=this.D_;Promise.all([this.authCredentialsProvider.getToken(),this.appCheckCredentialsProvider.getToken()]).then((([n,r])=>{this.D_===t&&this.G_(n,r)}),(n=>{e((()=>{const r=new y(m.UNKNOWN,"Fetching auth token failed: "+n.message);return this.z_(r)}))}))}G_(e,t){const n=this.Q_(this.D_);this.stream=this.j_(e,t),this.stream.Zo((()=>{n((()=>this.listener.Zo()))})),this.stream.Yo((()=>{n((()=>(this.state=2,this.v_=this.Ci.enqueueAfterDelay(this.b_,1e4,(()=>(this.O_()&&(this.state=3),Promise.resolve()))),this.listener.Yo())))})),this.stream.t_((r=>{n((()=>this.z_(r)))})),this.stream.onMessage((r=>{n((()=>++this.F_==1?this.J_(r):this.onNext(r)))}))}N_(){this.state=5,this.M_.p_((async()=>{this.state=0,this.start()}))}z_(e){return g($i,`close with error: ${e}`),this.stream=null,this.close(4,e)}Q_(e){return t=>{this.Ci.enqueueAndForget((()=>this.D_===e?t():(g($i,"stream callback skipped by getCloseGuardedDispatcher."),Promise.resolve())))}}}class lh extends Qa{constructor(e,t,n,r,i,o){super(e,"listen_stream_connection_backoff","listen_stream_idle","health_check_timeout",t,n,r,o),this.serializer=i}j_(e,t){return this.connection.T_("Listen",e,t)}J_(e){return this.onNext(e)}onNext(e){this.M_.reset();const t=ml(this.serializer,e),n=(function(i){if(!("targetChange"in i))return A.min();const o=i.targetChange;return o.targetIds&&o.targetIds.length?A.min():o.readTime?te(o.readTime):A.min()})(e);return this.listener.H_(t,n)}Z_(e){const t={};t.database=Gr(this.serializer),t.addTarget=(function(i,o){let a;const u=o.target;if(a=$n(u)?{documents:ma(i,u)}:{query:_a(i,u).ft},a.targetId=o.targetId,o.resumeToken.approximateByteSize()>0){a.resumeToken=hl(i,o.resumeToken);const c=zr(i,o.expectedCount);c!==null&&(a.expectedCount=c)}else if(o.snapshotVersion.compareTo(A.min())>0){a.readTime=Qn(i,o.snapshotVersion.toTimestamp());const c=zr(i,o.expectedCount);c!==null&&(a.expectedCount=c)}return a})(this.serializer,e);const n=gl(this.serializer,e);n&&(t.labels=n),this.K_(t)}X_(e){const t={};t.database=Gr(this.serializer),t.removeTarget=e,this.K_(t)}}class hh extends Qa{constructor(e,t,n,r,i,o){super(e,"write_stream_connection_backoff","write_stream_idle","health_check_timeout",t,n,r,o),this.serializer=i}get Y_(){return this.F_>0}start(){this.lastStreamToken=void 0,super.start()}W_(){this.Y_&&this.ea([])}j_(e,t){return this.connection.T_("Write",e,t)}J_(e){return T(!!e.streamToken,31322),this.lastStreamToken=e.streamToken,T(!e.writeResults||e.writeResults.length===0,55816),this.listener.ta()}onNext(e){T(!!e.streamToken,12678),this.lastStreamToken=e.streamToken,this.M_.reset();const t=_l(e.writeResults,e.commitTime),n=te(e.commitTime);return this.listener.na(n,t)}ra(){const e={};e.database=Gr(this.serializer),this.K_(e)}ea(e){const t={streamToken:this.lastStreamToken,writes:e.map((n=>Hn(this.serializer,n)))};this.K_(t)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class dh{}class fh extends dh{constructor(e,t,n,r){super(),this.authCredentials=e,this.appCheckCredentials=t,this.connection=n,this.serializer=r,this.ia=!1}sa(){if(this.ia)throw new y(m.FAILED_PRECONDITION,"The client has already been terminated.")}Wo(e,t,n,r){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([i,o])=>this.connection.Wo(e,Kr(t,n),r,i,o))).catch((i=>{throw i.name==="FirebaseError"?(i.code===m.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),i):new y(m.UNKNOWN,i.toString())}))}jo(e,t,n,r,i){return this.sa(),Promise.all([this.authCredentials.getToken(),this.appCheckCredentials.getToken()]).then((([o,a])=>this.connection.jo(e,Kr(t,n),r,o,a,i))).catch((o=>{throw o.name==="FirebaseError"?(o.code===m.UNAUTHENTICATED&&(this.authCredentials.invalidateToken(),this.appCheckCredentials.invalidateToken()),o):new y(m.UNKNOWN,o.toString())}))}terminate(){this.ia=!0,this.connection.terminate()}}function mh(s,e,t,n){return new fh(s,e,t,n)}class _h{constructor(e,t){this.asyncQueue=e,this.onlineStateHandler=t,this.state="Unknown",this.oa=0,this._a=null,this.aa=!0}ua(){this.oa===0&&(this.ca("Unknown"),this._a=this.asyncQueue.enqueueAfterDelay("online_state_timeout",1e4,(()=>(this._a=null,this.la("Backend didn't respond within 10 seconds."),this.ca("Offline"),Promise.resolve()))))}ha(e){this.state==="Online"?this.ca("Unknown"):(this.oa++,this.oa>=1&&(this.Pa(),this.la(`Connection failed 1 times. Most recent error: ${e.toString()}`),this.ca("Offline")))}set(e){this.Pa(),this.oa=0,e==="Online"&&(this.aa=!1),this.ca(e)}ca(e){e!==this.state&&(this.state=e,this.onlineStateHandler(e))}la(e){const t=`Could not reach Cloud Firestore backend. ${e}
This typically indicates that your device does not have a healthy Internet connection at the moment. The client will operate in offline mode until it is able to successfully connect to the backend.`;this.aa?(H(t),this.aa=!1):g("OnlineStateTracker",t)}Pa(){this._a!==null&&(this._a.cancel(),this._a=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Ae="RemoteStore";class gh{constructor(e,t,n,r,i){this.localStore=e,this.datastore=t,this.asyncQueue=n,this.remoteSyncer={},this.Ta=[],this.Ia=new Map,this.Ea=new Map,this.Ra=new Map,this.Aa=new Ee(1e3),this.Va=new Ee(1001),this.da=new Set,this.ma=[],this.fa=i,this.fa.Mo((o=>{n.enqueueAndForget((async()=>{Ct(this)&&(g(Ae,"Restarting streams for network reachability change."),await(async function(u){const c=E(u);c.da.add(4),await yr(c),c.ga.set("Unknown"),c.da.delete(4),await Ds(c)})(this))}))})),this.ga=new _h(n,r)}}async function Ds(s){if(Ct(s))for(const e of s.ma)await e(!0)}async function yr(s){for(const e of s.ma)await e(!1)}function Zr(s,e){return s.Ea.get(e)||void 0}function Cs(s,e){const t=E(s),n=Zr(t,e.targetId);if(n!==void 0&&t.Ia.has(n))return;const r=(function(a,u){const c=Zr(a,u);c!==void 0&&a.Ra.delete(c);const l=(function(f,_){return _%2!=0?f.Va.next():f.Aa.next()})(a,u);return a.Ea.set(u,l),a.Ra.set(l,u),l})(t,e.targetId);g(Ae,"remoteStoreListen mapping SDK target ID to remote",e.targetId,r);const i=new _e(e.target,r,e.purpose,e.sequenceNumber,e.snapshotVersion,e.lastLimboFreeSnapshotVersion,e.resumeToken);t.Ia.set(r,i),Ms(t)?ks(t):Nt(t).O_()&&Ns(t,i)}function tr(s,e){const t=E(s),n=Nt(t),r=Zr(t,e);g(Ae,"remoteStoreUnlisten removing mapping of SDK target ID to remote",e,r),t.Ia.delete(r),t.Ea.delete(e),t.Ra.delete(r),n.O_()&&Wa(t,r),t.Ia.size===0&&(n.O_()?n.L_():Ct(t)&&t.ga.set("Unknown"))}function Ns(s,e){if(s.pa.$e(e.targetId),e.resumeToken.approximateByteSize()>0||e.snapshotVersion.compareTo(A.min())>0){const t=s.Ra.get(e.targetId);if(t===void 0)return void g(Ae,"SDK target ID not found for remote ID: "+e.targetId);const n=s.remoteSyncer.getRemoteKeysForTarget(t).size;e=e.withExpectedCount(n)}Nt(s).Z_(e)}function Wa(s,e){s.pa.$e(e),Nt(s).X_(e)}function ks(s){s.pa=new ol({getRemoteKeysForTarget:e=>{const t=s.Ra.get(e);return t!==void 0?s.remoteSyncer.getRemoteKeysForTarget(t):S()},At:e=>s.Ia.get(e)||null,ht:()=>s.datastore.serializer.databaseId}),Nt(s).start(),s.ga.ua()}function Ms(s){return Ct(s)&&!Nt(s).x_()&&s.Ia.size>0}function Ct(s){return E(s).da.size===0}function Ha(s){s.pa=void 0}async function ph(s){s.ga.set("Online")}async function yh(s){s.Ia.forEach(((e,t)=>{Ns(s,e)}))}async function Ih(s,e){Ha(s),Ms(s)?(s.ga.ha(e),ks(s)):s.ga.set("Unknown")}async function Th(s,e,t){if(s.ga.set("Online"),e instanceof ua&&e.state===2&&e.cause)try{await(async function(r,i){const o=i.cause;for(const a of i.targetIds){if(r.Ia.has(a)){const u=r.Ra.get(a);u!==void 0&&(await r.remoteSyncer.rejectListen(u,o),r.Ea.delete(u),r.Ra.delete(a)),r.Ia.delete(a)}r.pa.removeTarget(a)}})(s,e)}catch(n){g(Ae,"Failed to remove targets %s: %s ",e.targetIds.join(","),n),await nr(s,n)}else if(e instanceof Nn?s.pa.Xe(e):e instanceof aa?s.pa.st(e):s.pa.tt(e),!t.isEqual(A.min()))try{const n=await Oa(s.localStore);t.compareTo(n)>=0&&await(function(i,o){const a=i.pa.Tt(o);a.targetChanges.forEach(((c,l)=>{if(c.resumeToken.approximateByteSize()>0){const h=i.Ia.get(l);h&&i.Ia.set(l,h.withResumeToken(c.resumeToken,o))}})),a.targetMismatches.forEach(((c,l)=>{const h=i.Ia.get(c);if(!h)return;i.Ia.set(c,h.withResumeToken(U.EMPTY_BYTE_STRING,h.snapshotVersion)),Wa(i,c);const f=new _e(h.target,c,l,h.sequenceNumber);Ns(i,f)}));const u=(function(l,h){const f=new Map;h.targetChanges.forEach(((R,w)=>{const v=l.Ra.get(w);v!==void 0&&f.set(v,R)}));let _=new k(V);return h.targetMismatches.forEach(((R,w)=>{const v=l.Ra.get(R);v!==void 0&&(_=_.insert(v,w))})),new Dt(h.snapshotVersion,f,_,h.documentUpdates,h.resolvedLimboDocuments)})(i,a);return i.remoteSyncer.applyRemoteEvent(u)})(s,t)}catch(n){g(Ae,"Failed to raise snapshot:",n),await nr(s,n)}}async function nr(s,e,t){if(!Ze(e))throw e;s.da.add(1),await yr(s),s.ga.set("Offline"),t||(t=()=>Oa(s.localStore)),s.asyncQueue.enqueueRetryable((async()=>{g(Ae,"Retrying IndexedDB access"),await t(),s.da.delete(1),await Ds(s)}))}function Ja(s,e){return e().catch((t=>nr(s,t,e)))}async function In(s){const e=E(s),t=De(e);let n=e.Ta.length>0?e.Ta[e.Ta.length-1].batchId:ze;for(;Eh(e);)try{const r=await sh(e.localStore,n);if(r===null){e.Ta.length===0&&t.L_();break}n=r.batchId,Ah(e,r)}catch(r){await nr(e,r)}Ya(e)&&Xa(e)}function Eh(s){return Ct(s)&&s.Ta.length<10}function Ah(s,e){s.Ta.push(e);const t=De(s);t.O_()&&t.Y_&&t.ea(e.mutations)}function Ya(s){return Ct(s)&&!De(s).x_()&&s.Ta.length>0}function Xa(s){De(s).start()}async function wh(s){De(s).ra()}async function Rh(s){const e=De(s);for(const t of s.Ta)e.ea(t.mutations)}async function vh(s,e,t){const n=s.Ta.shift(),r=Es.from(n,e,t);await Ja(s,(()=>s.remoteSyncer.applySuccessfulWrite(r))),await In(s)}async function Vh(s,e){e&&De(s).Y_&&await(async function(n,r){if((function(o){return rl(o)&&o!==m.ABORTED})(r.code)){const i=n.Ta.shift();De(n).B_(),await Ja(n,(()=>n.remoteSyncer.rejectFailedWrite(i.batchId,r))),await In(n)}})(s,e),Ya(s)&&Xa(s)}async function es(s,e){const t=E(s);e?(t.da.delete(2),await Ds(t)):e||(t.da.add(2),await yr(t),t.ga.set("Unknown"))}function Nt(s){return s.ya||(s.ya=(function(t,n,r){const i=E(t);return i.sa(),new lh(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)})(s.datastore,s.asyncQueue,{Zo:ph.bind(null,s),Yo:yh.bind(null,s),t_:Ih.bind(null,s),H_:Th.bind(null,s)}),s.ma.push((async e=>{e?(s.ya.B_(),Ms(s)?ks(s):s.ga.set("Unknown")):(await s.ya.stop(),Ha(s))}))),s.ya}function De(s){return s.wa||(s.wa=(function(t,n,r){const i=E(t);return i.sa(),new hh(n,i.connection,i.authCredentials,i.appCheckCredentials,i.serializer,r)})(s.datastore,s.asyncQueue,{Zo:()=>Promise.resolve(),Yo:wh.bind(null,s),t_:Vh.bind(null,s),ta:Rh.bind(null,s),na:vh.bind(null,s)}),s.ma.push((async e=>{e?(s.wa.B_(),await In(s)):(await s.wa.stop(),s.Ta.length>0&&(g(Ae,`Stopping write stream with ${s.Ta.length} pending writes`),s.Ta=[]))}))),s.wa}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Os{constructor(e,t,n,r,i){this.asyncQueue=e,this.timerId=t,this.targetTimeMs=n,this.op=r,this.removalCallback=i,this.deferred=new ht,this.then=this.deferred.promise.then.bind(this.deferred.promise),this.deferred.promise.catch((o=>{}))}get promise(){return this.deferred.promise}static createAndSchedule(e,t,n,r,i){const o=Date.now()+n,a=new Os(e,t,o,r,i);return a.start(n),a}start(e){this.timerHandle=setTimeout((()=>this.handleDelayElapsed()),e)}skipDelay(){return this.handleDelayElapsed()}cancel(e){this.timerHandle!==null&&(this.clearTimeout(),this.deferred.reject(new y(m.CANCELLED,"Operation cancelled"+(e?": "+e:""))))}handleDelayElapsed(){this.asyncQueue.enqueueAndForget((()=>this.timerHandle!==null?(this.clearTimeout(),this.op().then((e=>this.deferred.resolve(e)))):Promise.resolve()))}clearTimeout(){this.timerHandle!==null&&(this.removalCallback(this),clearTimeout(this.timerHandle),this.timerHandle=null)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ft{static emptySet(e){return new ft(e.comparator)}constructor(e){this.comparator=e?(t,n)=>e(t,n)||p.comparator(t.key,n.key):(t,n)=>p.comparator(t.key,n.key),this.keyedMap=Kt(),this.sortedSet=new k(this.comparator)}has(e){return this.keyedMap.get(e)!=null}get(e){return this.keyedMap.get(e)}first(){return this.sortedSet.minKey()}last(){return this.sortedSet.maxKey()}isEmpty(){return this.sortedSet.isEmpty()}indexOf(e){const t=this.keyedMap.get(e);return t?this.sortedSet.indexOf(t):-1}get size(){return this.sortedSet.size}forEach(e){this.sortedSet.inorderTraversal(((t,n)=>(e(t),!1)))}add(e){const t=this.delete(e.key);return t.copy(t.keyedMap.insert(e.key,e),t.sortedSet.insert(e,null))}delete(e){const t=this.get(e);return t?this.copy(this.keyedMap.remove(e),this.sortedSet.remove(t)):this}isEqual(e){if(!(e instanceof ft)||this.size!==e.size)return!1;const t=this.sortedSet.getIterator(),n=e.sortedSet.getIterator();for(;t.hasNext();){const r=t.getNext().key,i=n.getNext().key;if(!r.isEqual(i))return!1}return!0}toString(){const e=[];return this.forEach((t=>{e.push(t.toString())})),e.length===0?"DocumentSet ()":`DocumentSet (
  `+e.join(`  
`)+`
)`}copy(e,t){const n=new ft;return n.comparator=this.comparator,n.keyedMap=e,n.sortedSet=t,n}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ji{constructor(){this.Sa=new k(p.comparator)}track(e){const t=e.doc.key,n=this.Sa.get(t);n?e.type!==0&&n.type===3?this.Sa=this.Sa.insert(t,e):e.type===3&&n.type!==1?this.Sa=this.Sa.insert(t,{type:n.type,doc:e.doc}):e.type===2&&n.type===2?this.Sa=this.Sa.insert(t,{type:2,doc:e.doc}):e.type===2&&n.type===0?this.Sa=this.Sa.insert(t,{type:0,doc:e.doc}):e.type===1&&n.type===0?this.Sa=this.Sa.remove(t):e.type===1&&n.type===2?this.Sa=this.Sa.insert(t,{type:1,doc:n.doc}):e.type===0&&n.type===1?this.Sa=this.Sa.insert(t,{type:2,doc:e.doc}):I(63341,{Vt:e,ba:n}):this.Sa=this.Sa.insert(t,e)}Da(){const e=[];return this.Sa.inorderTraversal(((t,n)=>{e.push(n)})),e}}class rr{constructor(e,t,n,r,i,o,a,u,c){this.query=e,this.docs=t,this.oldDocs=n,this.docChanges=r,this.mutatedKeys=i,this.fromCache=o,this.syncStateChanged=a,this.excludesMetadataChanges=u,this.hasCachedResults=c}static fromInitialDocuments(e,t,n,r,i){const o=[];return t.forEach((a=>{o.push({type:0,doc:a})})),new rr(e,t,ft.emptySet(t),o,n,r,!0,!1,i)}get hasPendingWrites(){return!this.mutatedKeys.isEmpty()}isEqual(e){if(!(this.fromCache===e.fromCache&&this.hasCachedResults===e.hasCachedResults&&this.syncStateChanged===e.syncStateChanged&&this.mutatedKeys.isEqual(e.mutatedKeys)&&ps(this.query,e.query)&&this.docs.isEqual(e.docs)&&this.oldDocs.isEqual(e.oldDocs)))return!1;const t=this.docChanges,n=e.docChanges;if(t.length!==n.length)return!1;for(let r=0;r<t.length;r++)if(t[r].type!==n[r].type||!t[r].doc.isEqual(n[r].doc))return!1;return!0}}class Sh{constructor(){this.queries=Qi(),this.onlineState="Unknown",this.xa=new Set}terminate(){(function(t,n){const r=E(t),i=r.queries;r.queries=Qi(),i.forEach(((o,a)=>{for(const u of a.va)u.onError(n)}))})(this,new y(m.ABORTED,"Firestore shutting down"))}}function Qi(){return new Ce((s=>Ho(s)),ps)}function Ph(s,e){const t=E(s);let n=!1;for(const r of e){const i=r.query,o=t.queries.get(i);if(o){for(const a of o.va)a.Na(r)&&(n=!0);o.Ca=r}}n&&Za(t)}function bh(s,e,t){const n=E(s),r=n.queries.get(e);if(r)for(const i of r.va)i.onError(t);n.queries.delete(e)}function Za(s){s.xa.forEach((e=>{e.next()}))}var Wi,Hi;(Hi=Wi||(Wi={})).Ba="default",Hi.Cache="cache";/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eu{constructor(e){this.key=e}}class tu{constructor(e){this.key=e}}class xh{constructor(e,t){this.query=e,this.tu=t,this.nu=null,this.hasCachedResults=!1,this.current=!1,this.ru=S(),this.mutatedKeys=S(),this.iu=Yo(e),this.su=new ft(this.iu)}get ou(){return this.tu}_u(e,t){const n=t?t.au:new ji,r=t?t.su:this.su;let i=t?t.mutatedKeys:this.mutatedKeys,o=r,a=!1;const u=this.query.limitType==="F"&&r.size===this.query.limit?r.last():null,c=this.query.limitType==="L"&&r.size===this.query.limit?r.first():null;if(e.inorderTraversal(((l,h)=>{const f=r.get(l),_=gn(this.query,h)?h:null,R=!!f&&this.mutatedKeys.has(f.key),w=!!_&&(_.hasLocalMutations||this.mutatedKeys.has(_.key)&&_.hasCommittedMutations);let v=!1;f&&_?f.data.isEqual(_.data)?R!==w&&(n.track({type:3,doc:_}),v=!0):this.uu(f,_)||(n.track({type:2,doc:_}),v=!0,(u&&this.iu(_,u)>0||c&&this.iu(_,c)<0)&&(a=!0)):!f&&_?(n.track({type:0,doc:_}),v=!0):f&&!_&&(n.track({type:1,doc:f}),v=!0,(u||c)&&(a=!0)),v&&(_?(o=o.add(_),i=w?i.add(l):i.delete(l)):(o=o.delete(l),i=i.delete(l)))})),this.query.limit!==null)for(;o.size>this.query.limit;){const l=this.query.limitType==="F"?o.last():o.first();o=o.delete(l.key),i=i.delete(l.key),n.track({type:1,doc:l})}return{su:o,au:n,bs:a,mutatedKeys:i}}uu(e,t){return e.hasLocalMutations&&t.hasCommittedMutations&&!t.hasLocalMutations}applyChanges(e,t,n,r){const i=this.su;this.su=e.su,this.mutatedKeys=e.mutatedKeys;const o=e.au.Da();o.sort(((l,h)=>(function(_,R){const w=v=>{switch(v){case 0:return 1;case 2:case 3:return 2;case 1:return 0;default:return I(20277,{Vt:v})}};return w(_)-w(R)})(l.type,h.type)||this.iu(l.doc,h.doc))),this.cu(n),r=r??!1;const a=t&&!r?this.lu():[],u=this.ru.size===0&&this.current&&!r?1:0,c=u!==this.nu;return this.nu=u,o.length!==0||c?{snapshot:new rr(this.query,e.su,i,o,e.mutatedKeys,u===0,c,!1,!!n&&n.resumeToken.approximateByteSize()>0),hu:a}:{hu:a}}Oa(e){return this.current&&e==="Offline"?(this.current=!1,this.applyChanges({su:this.su,au:new ji,mutatedKeys:this.mutatedKeys,bs:!1},!1)):{hu:[]}}Pu(e){return!this.tu.has(e)&&!!this.su.has(e)&&!this.su.get(e).hasLocalMutations}cu(e){e&&(e.addedDocuments.forEach((t=>this.tu=this.tu.add(t))),e.modifiedDocuments.forEach((t=>{})),e.removedDocuments.forEach((t=>this.tu=this.tu.delete(t))),this.current=e.current)}lu(){if(!this.current)return[];const e=this.ru;this.ru=S(),this.su.forEach((n=>{this.Pu(n.key)&&(this.ru=this.ru.add(n.key))}));const t=[];return e.forEach((n=>{this.ru.has(n)||t.push(new tu(n))})),this.ru.forEach((n=>{e.has(n)||t.push(new eu(n))})),t}Tu(e){this.tu=e.ks,this.ru=S();const t=this._u(e.documents);return this.applyChanges(t,!0)}Iu(){return rr.fromInitialDocuments(this.query,this.su,this.mutatedKeys,this.nu===0,this.hasCachedResults)}}const kt="SyncEngine";class Dh{constructor(e,t,n){this.query=e,this.targetId=t,this.view=n}}class Ch{constructor(e){this.key=e,this.Eu=!1}}class Nh{constructor(e,t,n,r,i,o){this.localStore=e,this.remoteStore=t,this.eventManager=n,this.sharedClientState=r,this.currentUser=i,this.maxConcurrentLimboResolutions=o,this.Ru={},this.Au=new Ce((a=>Ho(a)),ps),this.Vu=new Map,this.du=new Set,this.mu=new k(p.comparator),this.fu=new Map,this.gu=new Vs,this.pu={},this.yu=new Map,this.wu=Ee.ar(),this.onlineState="Unknown",this.Su=void 0}get isPrimaryClient(){return this.Su===!0}}async function nu(s,e,t,n,r){s.bu=(h,f,_)=>(async function(w,v,L,N){let x=v.view._u(L);x.bs&&(x=await Jr(w.localStore,v.query,!1).then((({documents:X})=>v.view._u(X,x))));const q=N&&N.targetChanges.get(v.targetId),j=N&&N.targetMismatches.get(v.targetId)!=null,z=v.view.applyChanges(x,w.isPrimaryClient,q,j);return ts(w,v.targetId,z.hu),z.snapshot})(s,h,f,_);const i=await Jr(s.localStore,e,!0),o=new xh(e,i.ks),a=o._u(i.documents),u=yn.createSynthesizedTargetChangeForCurrentChange(t,n,r),c=o.applyChanges(a,s.isPrimaryClient,u);ts(s,t,c.hu);const l=new Dh(e,t,o);return s.Au.set(e,l),s.Vu.has(t)?s.Vu.get(t).push(e):s.Vu.set(t,[e]),c.snapshot}async function ru(s,e){const t=E(s);try{const n=await nh(t.localStore,e);e.targetChanges.forEach(((r,i)=>{const o=t.fu.get(i);o&&(T(r.addedDocuments.size+r.modifiedDocuments.size+r.removedDocuments.size<=1,22616),r.addedDocuments.size>0?o.Eu=!0:r.modifiedDocuments.size>0?T(o.Eu,14607):r.removedDocuments.size>0&&(T(o.Eu,42227),o.Eu=!1))})),await et(t,n,e)}catch(n){await Xe(n)}}function Ji(s,e,t){const n=E(s);if(n.isPrimaryClient&&t===0||!n.isPrimaryClient&&t===1){const r=[];n.Au.forEach(((i,o)=>{const a=o.view.Oa(e);a.snapshot&&r.push(a.snapshot)})),(function(o,a){const u=E(o);u.onlineState=a;let c=!1;u.queries.forEach(((l,h)=>{for(const f of h.va)f.Oa(a)&&(c=!0)})),c&&Za(u)})(n.eventManager,e),r.length&&n.Ru.H_(r),n.onlineState=e,n.isPrimaryClient&&n.sharedClientState.setOnlineState(e)}}async function kh(s,e,t){const n=E(s);n.sharedClientState.updateQueryState(e,"rejected",t);const r=n.fu.get(e),i=r&&r.key;if(i){let o=new k(p.comparator);o=o.insert(i,F.newNoDocument(i,A.min()));const a=S().add(i),u=new Dt(A.min(),new Map,new k(V),o,a);await ru(n,u),n.mu=n.mu.remove(i),n.fu.delete(e),Bs(n)}else await pr(n.localStore,e,!1).then((()=>Ir(n,e,t))).catch(Xe)}async function Mh(s,e){const t=E(s),n=e.batch.batchId;try{const r=await th(t.localStore,e);Ls(t,n,null),Fs(t,n),t.sharedClientState.updateMutationState(n,"acknowledged"),await et(t,r)}catch(r){await Xe(r)}}async function Oh(s,e,t){const n=E(s);try{const r=await(function(o,a){const u=E(o);return u.persistence.runTransaction("Reject batch","readwrite-primary",(c=>{let l;return u.mutationQueue.lookupMutationBatch(c,a).next((h=>(T(h!==null,37113),l=h.keys(),u.mutationQueue.removeMutationBatch(c,h)))).next((()=>u.mutationQueue.performConsistencyCheck(c))).next((()=>u.documentOverlayCache.removeOverlaysForBatchId(c,l,a))).next((()=>u.localDocuments.recalculateAndSaveOverlaysForDocumentKeys(c,l))).next((()=>u.localDocuments.getDocuments(c,l)))}))})(n.localStore,e);Ls(n,e,t),Fs(n,e),n.sharedClientState.updateMutationState(e,"rejected",t),await et(n,r)}catch(r){await Xe(r)}}function Fs(s,e){(s.yu.get(e)||[]).forEach((t=>{t.resolve()})),s.yu.delete(e)}function Ls(s,e,t){const n=E(s);let r=n.pu[n.currentUser.toKey()];if(r){const i=r.get(e);i&&(t?i.reject(t):i.resolve(),r=r.remove(e)),n.pu[n.currentUser.toKey()]=r}}function Ir(s,e,t=null){s.sharedClientState.removeLocalQueryTarget(e);for(const n of s.Vu.get(e))s.Au.delete(n),t&&s.Ru.Du(n,t);s.Vu.delete(e),s.isPrimaryClient&&s.gu.Gr(e).forEach((n=>{s.gu.containsKey(n)||su(s,n)}))}function su(s,e){s.du.delete(e.path.canonicalString());const t=s.mu.get(e);t!==null&&(tr(s.remoteStore,t),s.mu=s.mu.remove(e),s.fu.delete(t),Bs(s))}function ts(s,e,t){for(const n of t)n instanceof eu?(s.gu.addReference(n.key,e),Fh(s,n)):n instanceof tu?(g(kt,"Document no longer in limbo: "+n.key),s.gu.removeReference(n.key,e),s.gu.containsKey(n.key)||su(s,n.key)):I(19791,{Cu:n})}function Fh(s,e){const t=e.key,n=t.path.canonicalString();s.mu.get(t)||s.du.has(n)||(g(kt,"New document in limbo: "+t),s.du.add(n),Bs(s))}function Bs(s){for(;s.du.size>0&&s.mu.size<s.maxConcurrentLimboResolutions;){const e=s.du.values().next().value;s.du.delete(e);const t=new p(M.fromString(e)),n=s.wu.next();s.fu.set(n,new Ch(t)),s.mu=s.mu.insert(t,n),Cs(s.remoteStore,new _e(ue(gs(t.path)),n,"TargetPurposeLimboResolution",re.ce))}}async function et(s,e,t){const n=E(s),r=[],i=[],o=[];n.Au.isEmpty()||(n.Au.forEach(((a,u)=>{o.push(n.bu(u,e,t).then((c=>{if((c||t)&&n.isPrimaryClient){const l=c?!c.fromCache:t?.targetChanges.get(u.targetId)?.current;n.sharedClientState.updateQueryState(u.targetId,l?"current":"not-current")}if(c){r.push(c);const l=Ps.Es(u.targetId,c);i.push(l)}})))})),await Promise.all(o),n.Ru.H_(r),await(async function(u,c){const l=E(u);try{await l.persistence.runTransaction("notifyLocalViewChanges","readwrite",(h=>d.forEach(c,(f=>d.forEach(f.Ts,(_=>l.persistence.referenceDelegate.addReference(h,f.targetId,_))).next((()=>d.forEach(f.Is,(_=>l.persistence.referenceDelegate.removeReference(h,f.targetId,_)))))))))}catch(h){if(!Ze(h))throw h;g(bs,"Failed to update sequence numbers: "+h)}for(const h of c){const f=h.targetId;if(!h.fromCache){const _=l.vs.get(f),R=_.snapshotVersion,w=_.withLastLimboFreeSnapshotVersion(R);l.vs=l.vs.insert(f,w)}}})(n.localStore,i))}async function Lh(s,e){const t=E(s);if(!t.currentUser.isEqual(e)){g(kt,"User change. New user:",e.toKey());const n=await eh(t.localStore,e);t.currentUser=e,(function(i,o){i.yu.forEach((a=>{a.forEach((u=>{u.reject(new y(m.CANCELLED,o))}))})),i.yu.clear()})(t,"'waitForPendingWrites' promise is rejected due to a user change."),t.sharedClientState.handleUserChange(e,n.removedBatchIds,n.addedBatchIds),await et(t,n.Ns)}}function Bh(s,e){const t=E(s),n=t.fu.get(e);if(n&&n.Eu)return S().add(n.key);{let r=S();const i=t.Vu.get(e);if(!i)return r;for(const o of i){const a=t.Au.get(o);r=r.unionWith(a.view.ou)}return r}}async function Uh(s,e){const t=E(s),n=await Jr(t.localStore,e.query,!0),r=e.view.Tu(n);return t.isPrimaryClient&&ts(t,e.targetId,r.hu),r}async function qh(s,e){const t=E(s);return La(t.localStore,e).then((n=>et(t,n)))}async function zh(s,e,t,n){const r=E(s),i=await(function(a,u){const c=E(a),l=E(c.mutationQueue);return c.persistence.runTransaction("Lookup mutation documents","readonly",(h=>l.Xn(h,u).next((f=>f?c.localDocuments.getDocuments(h,f):d.resolve(null)))))})(r.localStore,e);i!==null?(t==="pending"?await In(r.remoteStore):t==="acknowledged"||t==="rejected"?(Ls(r,e,n||null),Fs(r,e),(function(a,u){E(E(a).mutationQueue).nr(u)})(r.localStore,e)):I(6720,"Unknown batchState",{vu:t}),await et(r,i)):g(kt,"Cannot apply mutation batch with id: "+e)}async function Kh(s,e){const t=E(s);if(ou(t),au(t),e===!0&&t.Su!==!0){const n=t.sharedClientState.getAllActiveQueryTargets(),r=await Yi(t,n.toArray());t.Su=!0,await es(t.remoteStore,!0);for(const i of r)Cs(t.remoteStore,i)}else if(e===!1&&t.Su!==!1){const n=[];let r=Promise.resolve();t.Vu.forEach(((i,o)=>{t.sharedClientState.isLocalQueryTarget(o)?n.push(o):r=r.then((()=>(Ir(t,o),pr(t.localStore,o,!0)))),tr(t.remoteStore,o)})),await r,await Yi(t,n),(function(o){const a=E(o);a.fu.forEach(((u,c)=>{tr(a.remoteStore,c)})),a.gu.zr(),a.fu=new Map,a.mu=new k(p.comparator)})(t),t.Su=!1,await es(t.remoteStore,!1)}}async function Yi(s,e,t){const n=E(s),r=[],i=[];for(const o of e){let a;const u=n.Vu.get(o);if(u&&u.length!==0){a=await Hr(n.localStore,ue(u[0]));for(const c of u){const l=n.Au.get(c),h=await Uh(n,l);h.snapshot&&i.push(h.snapshot)}}else{const c=await Fa(n.localStore,o);a=await Hr(n.localStore,c),await nu(n,iu(c),o,!1,a.resumeToken)}r.push(a)}return n.Ru.H_(i),r}function iu(s){return Wo(s.path,s.collectionGroup,s.orderBy,s.filters,s.limit,"F",s.startAt,s.endAt)}function Gh(s){return(function(t){return E(E(t).persistence).hs()})(E(s).localStore)}async function $h(s,e,t,n){const r=E(s);if(r.Su)return void g(kt,"Ignoring unexpected query state notification.");const i=r.Vu.get(e);if(i&&i.length>0)switch(t){case"current":case"not-current":{const o=await La(r.localStore,Jo(i[0])),a=Dt.createSynthesizedRemoteEventForCurrentChange(e,t==="current",U.EMPTY_BYTE_STRING);await et(r,o,a);break}case"rejected":await pr(r.localStore,e,!0),Ir(r,e,n);break;default:I(64155,t)}}async function jh(s,e,t){const n=ou(s);if(n.Su){for(const r of e){if(n.Vu.has(r)&&n.sharedClientState.isActiveQueryTarget(r)){g(kt,"Adding an already active target "+r);continue}const i=await Fa(n.localStore,r),o=await Hr(n.localStore,i);await nu(n,iu(i),o.targetId,!1,o.resumeToken),Cs(n.remoteStore,o)}for(const r of t)n.Vu.has(r)&&await pr(n.localStore,r,!1).then((()=>{tr(n.remoteStore,r),Ir(n,r)})).catch(Xe)}}function ou(s){const e=E(s);return e.remoteStore.remoteSyncer.applyRemoteEvent=ru.bind(null,e),e.remoteStore.remoteSyncer.getRemoteKeysForTarget=Bh.bind(null,e),e.remoteStore.remoteSyncer.rejectListen=kh.bind(null,e),e.Ru.H_=Ph.bind(null,e.eventManager),e.Ru.Du=bh.bind(null,e.eventManager),e}function au(s){const e=E(s);return e.remoteStore.remoteSyncer.applySuccessfulWrite=Mh.bind(null,e),e.remoteStore.remoteSyncer.rejectFailedWrite=Oh.bind(null,e),e}class ns{constructor(){this.kind="memory",this.synchronizeTabs=!1}async initialize(e){this.serializer=$a(e.databaseInfo.databaseId),this.sharedClientState=this.Mu(e),this.persistence=this.xu(e),await this.persistence.start(),this.localStore=this.Ou(e),this.gcScheduler=this.Nu(e,this.localStore),this.indexBackfillerScheduler=this.Bu(e,this.localStore)}Nu(e,t){return null}Bu(e,t){return null}Ou(e){return Ma(this.persistence,new ka,e.initialUser,this.serializer)}xu(e){return new Ca(gr.Vi,this.serializer)}Mu(e){return new Ka}async terminate(){this.gcScheduler?.stop(),this.indexBackfillerScheduler?.stop(),this.sharedClientState.shutdown(),await this.persistence.shutdown()}}ns.provider={build:()=>new ns};class uu extends ns{constructor(e,t,n){super(),this.Lu=e,this.cacheSizeBytes=t,this.forceOwnership=n,this.kind="persistent",this.synchronizeTabs=!1}async initialize(e){await super.initialize(e),await this.Lu.initialize(this,e),await au(this.Lu.syncEngine),await In(this.Lu.remoteStore),await this.persistence.zi((()=>(this.gcScheduler&&!this.gcScheduler.started&&this.gcScheduler.start(),this.indexBackfillerScheduler&&!this.indexBackfillerScheduler.started&&this.indexBackfillerScheduler.start(),Promise.resolve())))}Ou(e){return Ma(this.persistence,new ka,e.initialUser,this.serializer)}Nu(e,t){const n=this.persistence.referenceDelegate.garbageCollector;return new kl(n,e.asyncQueue,t)}Bu(e,t){const n=new Yu(t,this.persistence);return new Ju(e.asyncQueue,n)}xu(e){const t=Na(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey),n=this.cacheSizeBytes!==void 0?ne.withCacheSize(this.cacheSizeBytes):ne.DEFAULT;return new Ss(this.synchronizeTabs,t,e.clientId,n,e.asyncQueue,Ga(),Mn(),this.serializer,this.sharedClientState,!!this.forceOwnership)}Mu(e){return new Ka}}class Qh extends uu{constructor(e,t){super(e,t,!1),this.Lu=e,this.cacheSizeBytes=t,this.synchronizeTabs=!0}async initialize(e){await super.initialize(e);const t=this.Lu.syncEngine;this.sharedClientState instanceof Pr&&(this.sharedClientState.syncEngine={bo:zh.bind(null,t),Do:$h.bind(null,t),Co:jh.bind(null,t),hs:Gh.bind(null,t),So:qh.bind(null,t)},await this.sharedClientState.start()),await this.persistence.zi((async n=>{await Kh(this.Lu.syncEngine,n),this.gcScheduler&&(n&&!this.gcScheduler.started?this.gcScheduler.start():n||this.gcScheduler.stop()),this.indexBackfillerScheduler&&(n&&!this.indexBackfillerScheduler.started?this.indexBackfillerScheduler.start():n||this.indexBackfillerScheduler.stop())}))}Mu(e){const t=Ga();if(!Pr.v(t))throw new y(m.UNIMPLEMENTED,"IndexedDB persistence is only available on platforms that support LocalStorage.");const n=Na(e.databaseInfo.databaseId,e.databaseInfo.persistenceKey);return new Pr(t,e.asyncQueue,n,e.clientId,e.initialUser)}}class sr{async initialize(e,t){this.localStore||(this.localStore=e.localStore,this.sharedClientState=e.sharedClientState,this.datastore=this.createDatastore(t),this.remoteStore=this.createRemoteStore(t),this.eventManager=this.createEventManager(t),this.syncEngine=this.createSyncEngine(t,!e.synchronizeTabs),this.sharedClientState.onlineStateHandler=n=>Ji(this.syncEngine,n,1),this.remoteStore.remoteSyncer.handleCredentialChange=Lh.bind(null,this.syncEngine),await es(this.remoteStore,this.syncEngine.isPrimaryClient))}createEventManager(e){return(function(){return new Sh})()}createDatastore(e){const t=$a(e.databaseInfo.databaseId),n=ch(e.databaseInfo);return mh(e.authCredentials,e.appCheckCredentials,n,t)}createRemoteStore(e){return(function(n,r,i,o,a){return new gh(n,r,i,o,a)})(this.localStore,this.datastore,e.asyncQueue,(t=>Ji(this.syncEngine,t,0)),(function(){return Gi.v()?new Gi:new ih})())}createSyncEngine(e,t){return(function(r,i,o,a,u,c,l){const h=new Nh(r,i,o,a,u,c);return l&&(h.Su=!0),h})(this.localStore,this.remoteStore,this.eventManager,this.sharedClientState,e.initialUser,e.maxConcurrentLimboResolutions,t)}async terminate(){await(async function(t){const n=E(t);g(Ae,"RemoteStore shutting down."),n.da.add(5),await yr(n),n.fa.shutdown(),n.ga.set("Unknown")})(this.remoteStore),this.datastore?.terminate(),this.eventManager?.terminate()}}sr.provider={build:()=>new sr};/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Wh(s){const e={};return s.timeoutSeconds!==void 0&&(e.timeoutSeconds=s.timeoutSeconds),e}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const Hh="ComponentProvider",Xi=new Map;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const cu="firestore.googleapis.com",Zi=!0;class eo{constructor(e){if(e.host===void 0){if(e.ssl!==void 0)throw new y(m.INVALID_ARGUMENT,"Can't provide ssl option if host option is not set");this.host=cu,this.ssl=Zi}else this.host=e.host,this.ssl=e.ssl??Zi;if(this.isUsingEmulator=e.emulatorOptions!==void 0,this.credentials=e.credentials,this.ignoreUndefinedProperties=!!e.ignoreUndefinedProperties,this.localCache=e.localCache,e.cacheSizeBytes===void 0)this.cacheSizeBytes=Ra;else{if(e.cacheSizeBytes!==-1&&e.cacheSizeBytes<Pa)throw new y(m.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");this.cacheSizeBytes=e.cacheSizeBytes}Gu("experimentalForceLongPolling",e.experimentalForceLongPolling,"experimentalAutoDetectLongPolling",e.experimentalAutoDetectLongPolling),this.experimentalForceLongPolling=!!e.experimentalForceLongPolling,this.experimentalForceLongPolling?this.experimentalAutoDetectLongPolling=!1:e.experimentalAutoDetectLongPolling===void 0?this.experimentalAutoDetectLongPolling=!0:this.experimentalAutoDetectLongPolling=!!e.experimentalAutoDetectLongPolling,this.experimentalLongPollingOptions=Wh(e.experimentalLongPollingOptions??{}),(function(n){if(n.timeoutSeconds!==void 0){if(isNaN(n.timeoutSeconds))throw new y(m.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (must not be NaN)`);if(n.timeoutSeconds<5)throw new y(m.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (minimum allowed value is 5)`);if(n.timeoutSeconds>30)throw new y(m.INVALID_ARGUMENT,`invalid long polling timeout: ${n.timeoutSeconds} (maximum allowed value is 30)`)}})(this.experimentalLongPollingOptions),this.useFetchStreams=!!e.useFetchStreams}isEqual(e){return this.host===e.host&&this.ssl===e.ssl&&this.credentials===e.credentials&&this.cacheSizeBytes===e.cacheSizeBytes&&this.experimentalForceLongPolling===e.experimentalForceLongPolling&&this.experimentalAutoDetectLongPolling===e.experimentalAutoDetectLongPolling&&(function(n,r){return n.timeoutSeconds===r.timeoutSeconds})(this.experimentalLongPollingOptions,e.experimentalLongPollingOptions)&&this.ignoreUndefinedProperties===e.ignoreUndefinedProperties&&this.useFetchStreams===e.useFetchStreams}}class lu{constructor(e,t,n,r){this._authCredentials=e,this._appCheckCredentials=t,this._databaseId=n,this._app=r,this.type="firestore-lite",this._persistenceKey="(lite)",this._settings=new eo({}),this._settingsFrozen=!1,this._emulatorOptions={},this._terminateTask="notTerminated"}get app(){if(!this._app)throw new y(m.FAILED_PRECONDITION,"Firestore was not initialized using the Firebase SDK. 'app' is not available");return this._app}get _initialized(){return this._settingsFrozen}get _terminated(){return this._terminateTask!=="notTerminated"}_setSettings(e){if(this._settingsFrozen)throw new y(m.FAILED_PRECONDITION,"Firestore has already been started and its settings can no longer be changed. You can only modify settings before calling any other methods on a Firestore object.");this._settings=new eo(e),this._emulatorOptions=e.emulatorOptions||{},e.credentials!==void 0&&(this._authCredentials=(function(n){if(!n)return new Nu;switch(n.type){case"firstParty":return new Fu(n.sessionIndex||"0",n.iamToken||null,n.authTokenFactory||null);case"provider":return n.client;default:throw new y(m.INVALID_ARGUMENT,"makeAuthCredentialsProvider failed due to invalid credential type")}})(e.credentials))}_getSettings(){return this._settings}_getEmulatorOptions(){return this._emulatorOptions}_freezeSettings(){return this._settingsFrozen=!0,this._settings}_delete(){return this._terminateTask==="notTerminated"&&(this._terminateTask=this._terminate()),this._terminateTask}async _restart(){this._terminateTask==="notTerminated"?await this._terminate():this._terminateTask="notTerminated"}toJSON(){return{app:this._app,databaseId:this._databaseId,settings:this._settings}}_terminate(){return(function(t){const n=Xi.get(t);n&&(g(Hh,"Removing Datastore"),Xi.delete(t),n.terminate())})(this),Promise.resolve()}}function Jh(s,e,t,n={}){s=Qu(s,lu);const r=ss(e),i=s._getSettings(),o={...i,emulatorOptions:s._getEmulatorOptions()},a=`${e}:${t}`;r&&uo(`https://${a}`),i.host!==cu&&i.host!==a&&_t("Host has been set in both settings() and connectFirestoreEmulator(), emulator host will be used.");const u={...i,host:a,ssl:r,emulatorOptions:n};if(!ao(u,o)&&(s._setSettings(u),n.mockUserToken)){let c,l;if(typeof n.mockUserToken=="string")c=n.mockUserToken,l=J.MOCK_USER;else{c=pu(n.mockUserToken,s._app?.options.projectId);const h=n.mockUserToken.sub||n.mockUserToken.user_id;if(!h)throw new y(m.INVALID_ARGUMENT,"mockUserToken must contain 'sub' or 'user_id' field!");l=new J(h)}s._authCredentials=new ku(new fo(c,l))}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Us{constructor(e,t,n){this.converter=t,this._query=n,this.type="query",this.firestore=e}withConverter(e){return new Us(this.firestore,e,this._query)}}class ge{constructor(e,t,n){this.converter=t,this._key=n,this.type="document",this.firestore=e}get _path(){return this._key.path}get id(){return this._key.path.lastSegment()}get path(){return this._key.path.canonicalString()}get parent(){return new qs(this.firestore,this.converter,this._key.path.popLast())}withConverter(e){return new ge(this.firestore,e,this._key)}toJSON(){return{type:ge._jsonSchemaVersion,referencePath:this._key.toString()}}static fromJSON(e,t,n){if(fn(t,ge._jsonSchema))return new ge(e,n||null,new p(M.fromString(t.referencePath)))}}ge._jsonSchemaVersion="firestore/documentReference/1.0",ge._jsonSchema={type:$("string",ge._jsonSchemaVersion),referencePath:$("string")};class qs extends Us{constructor(e,t,n){super(e,t,gs(n)),this._path=n,this.type="collection"}get id(){return this._query.path.lastSegment()}get path(){return this._query.path.canonicalString()}get parent(){const e=this._path.popLast();return e.isEmpty()?null:new ge(this.firestore,null,new p(e))}withConverter(e){return new qs(this.firestore,e,this._path)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const to="AsyncQueue";class no{constructor(e=Promise.resolve()){this.rc=[],this.sc=!1,this.oc=[],this._c=null,this.ac=!1,this.uc=!1,this.cc=[],this.M_=new ja(this,"async_queue_retry"),this.lc=()=>{const n=Mn();n&&g(to,"Visibility state changed to "+n.visibilityState),this.M_.w_()},this.hc=e;const t=Mn();t&&typeof t.addEventListener=="function"&&t.addEventListener("visibilitychange",this.lc)}get isShuttingDown(){return this.sc}enqueueAndForget(e){this.enqueue(e)}enqueueAndForgetEvenWhileRestricted(e){this.Pc(),this.Tc(e)}enterRestrictedMode(e){if(!this.sc){this.sc=!0,this.uc=e||!1;const t=Mn();t&&typeof t.removeEventListener=="function"&&t.removeEventListener("visibilitychange",this.lc)}}enqueue(e){if(this.Pc(),this.sc)return new Promise((()=>{}));const t=new ht;return this.Tc((()=>this.sc&&this.uc?Promise.resolve():(e().then(t.resolve,t.reject),t.promise))).then((()=>t.promise))}enqueueRetryable(e){this.enqueueAndForget((()=>(this.rc.push(e),this.Ic())))}async Ic(){if(this.rc.length!==0){try{await this.rc[0](),this.rc.shift(),this.M_.reset()}catch(e){if(!Ze(e))throw e;g(to,"Operation failed with retryable error: "+e)}this.rc.length>0&&this.M_.p_((()=>this.Ic()))}}Tc(e){const t=this.hc.then((()=>(this.ac=!0,e().catch((n=>{throw this._c=n,this.ac=!1,H("INTERNAL UNHANDLED ERROR: ",ro(n)),n})).then((n=>(this.ac=!1,n))))));return this.hc=t,t}enqueueAfterDelay(e,t,n){this.Pc(),this.cc.indexOf(e)>-1&&(t=0);const r=Os.createAndSchedule(this,e,t,n,(i=>this.Ec(i)));return this.oc.push(r),r}Pc(){this._c&&I(47125,{Rc:ro(this._c)})}verifyOperationInProgress(){}async Ac(){let e;do e=this.hc,await e;while(e!==this.hc)}Vc(e){for(const t of this.oc)if(t.timerId===e)return!0;return!1}dc(e){return this.Ac().then((()=>{this.oc.sort(((t,n)=>t.targetTimeMs-n.targetTimeMs));for(const t of this.oc)if(t.skipDelay(),e!=="all"&&t.timerId===e)break;return this.Ac()}))}mc(e){this.cc.push(e)}Ec(e){const t=this.oc.indexOf(e);this.oc.splice(t,1)}}function ro(s){let e=s.message||"";return s.stack&&(e=s.stack.includes(s.message)?s.stack:s.message+`
`+s.stack),e}class Yh extends lu{constructor(e,t,n,r){super(e,t,n,r),this.type="firestore",this._queue=new no,this._persistenceKey=r?.name||"[DEFAULT]"}async _terminate(){if(this._firestoreClient){const e=this._firestoreClient.terminate();this._queue=new no(e),this._firestoreClient=void 0,await e}}}function ud(s,e,t){t||(t=un);const n=oo(s,"firestore");if(n.isInitialized(t)){const r=n.getImmediate({identifier:t}),i=n.getOptions(t);if(ao(i,e))return r;throw new y(m.FAILED_PRECONDITION,"initializeFirestore() has already been called with different options. To avoid this error, call initializeFirestore() with the same options as when it was originally called, or call getFirestore() to return the already initialized instance.")}if(e.cacheSizeBytes!==void 0&&e.localCache!==void 0)throw new y(m.INVALID_ARGUMENT,"cache and cacheSizeBytes cannot be specified at the same time as cacheSizeBytes willbe deprecated. Instead, specify the cache size in the cache object");if(e.cacheSizeBytes!==void 0&&e.cacheSizeBytes!==-1&&e.cacheSizeBytes<Pa)throw new y(m.INVALID_ARGUMENT,"cacheSizeBytes must be at least 1048576");return e.host&&ss(e.host)&&uo(e.host),n.initialize({options:e,instanceIdentifier:t})}function cd(s,e){const t=typeof s=="object"?s:mu(),n=typeof s=="string"?s:un,r=oo(t,"firestore").getImmediate({identifier:n});if(!r._initialized){const i=_u("firestore");i&&Jh(r,...i)}return r}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Ie{constructor(e){this._byteString=e}static fromBase64String(e){try{return new Ie(U.fromBase64String(e))}catch(t){throw new y(m.INVALID_ARGUMENT,"Failed to construct data from Base64 string: "+t)}}static fromUint8Array(e){return new Ie(U.fromUint8Array(e))}toBase64(){return this._byteString.toBase64()}toUint8Array(){return this._byteString.toUint8Array()}toString(){return"Bytes(base64: "+this.toBase64()+")"}isEqual(e){return this._byteString.isEqual(e._byteString)}toJSON(){return{type:Ie._jsonSchemaVersion,bytes:this.toBase64()}}static fromJSON(e){if(fn(e,Ie._jsonSchema))return Ie.fromBase64String(e.bytes)}}Ie._jsonSchemaVersion="firestore/bytes/1.0",Ie._jsonSchema={type:$("string",Ie._jsonSchemaVersion),bytes:$("string")};/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class hu{constructor(...e){for(let t=0;t<e.length;++t)if(e[t].length===0)throw new y(m.INVALID_ARGUMENT,"Invalid field name at argument $(i + 1). Field names must not be empty.");this._internalPath=new B(e)}isEqual(e){return this._internalPath.isEqual(e._internalPath)}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class $e{constructor(e,t){if(!isFinite(e)||e<-90||e>90)throw new y(m.INVALID_ARGUMENT,"Latitude must be a number between -90 and 90, but was: "+e);if(!isFinite(t)||t<-180||t>180)throw new y(m.INVALID_ARGUMENT,"Longitude must be a number between -180 and 180, but was: "+t);this._lat=e,this._long=t}get latitude(){return this._lat}get longitude(){return this._long}isEqual(e){return this._lat===e._lat&&this._long===e._long}_compareTo(e){return V(this._lat,e._lat)||V(this._long,e._long)}toJSON(){return{latitude:this._lat,longitude:this._long,type:$e._jsonSchemaVersion}}static fromJSON(e){if(fn(e,$e._jsonSchema))return new $e(e.latitude,e.longitude)}}$e._jsonSchemaVersion="firestore/geoPoint/1.0",$e._jsonSchema={type:$("string",$e._jsonSchemaVersion),latitude:$("number"),longitude:$("number")};/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class je{constructor(e){this._values=(e||[]).map((t=>t))}toArray(){return this._values.map((e=>e))}isEqual(e){return(function(n,r){if(n.length!==r.length)return!1;for(let i=0;i<n.length;++i)if(n[i]!==r[i])return!1;return!0})(this._values,e._values)}toJSON(){return{type:je._jsonSchemaVersion,vectorValues:this._values}}static fromJSON(e){if(fn(e,je._jsonSchema)){if(Array.isArray(e.vectorValues)&&e.vectorValues.every((t=>typeof t=="number")))return new je(e.vectorValues);throw new y(m.INVALID_ARGUMENT,"Expected 'vectorValues' field to be a number array")}}}je._jsonSchemaVersion="firestore/vectorValue/1.0",je._jsonSchema={type:$("string",je._jsonSchemaVersion),vectorValues:$("object")};function du(s,e,t){if((e=Pu(e))instanceof hu)return e._internalPath;if(typeof e=="string")return Zh(s,e);throw rs("Field path arguments must be of type string or ",s)}const Xh=new RegExp("[~\\*/\\[\\]]");function Zh(s,e,t){if(e.search(Xh)>=0)throw rs(`Invalid field path (${e}). Paths must not contain '~', '*', '/', '[', or ']'`,s);try{return new hu(...e.split("."))._internalPath}catch{throw rs(`Invalid field path (${e}). Paths must not be empty, begin with '.', end with '.', or contain '..'`,s)}}function rs(s,e,t,n,r){let i=`Function ${e}() called with invalid data`;i+=". ";let o="";return new y(m.INVALID_ARGUMENT,i+s+o)}const so="@firebase/firestore",io="4.14.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class fu{constructor(e,t,n,r,i){this._firestore=e,this._userDataWriter=t,this._key=n,this._document=r,this._converter=i}get id(){return this._key.path.lastSegment()}get ref(){return new ge(this._firestore,this._converter,this._key)}exists(){return this._document!==null}data(){if(this._document){if(this._converter){const e=new ed(this._firestore,this._userDataWriter,this._key,this._document,null);return this._converter.fromFirestore(e)}return this._userDataWriter.convertValue(this._document.data.value)}}_fieldsProto(){return this._document?.data.clone().value.mapValue.fields??void 0}get(e){if(this._document){const t=this._document.data.field(du("DocumentSnapshot.get",e));if(t!==null)return this._userDataWriter.convertValue(t)}}}class ed extends fu{data(){return super.data()}}class td{constructor(e){let t;this.kind="persistent",e?.tabManager?(e.tabManager._initialize(e),t=e.tabManager):(t=sd(void 0),t._initialize(e)),this._onlineComponentProvider=t._onlineComponentProvider,this._offlineComponentProvider=t._offlineComponentProvider}toJSON(){return{kind:this.kind}}}function ld(s){return new td(s)}class nd{constructor(e){this.forceOwnership=e,this.kind="persistentSingleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=sr.provider,this._offlineComponentProvider={build:t=>new uu(t,e?.cacheSizeBytes,this.forceOwnership)}}}class rd{constructor(){this.kind="PersistentMultipleTab"}toJSON(){return{kind:this.kind}}_initialize(e){this._onlineComponentProvider=sr.provider,this._offlineComponentProvider={build:t=>new Qh(t,e?.cacheSizeBytes)}}}function sd(s){return new nd(s?.forceOwnership)}function hd(){return new rd}class Sn{constructor(e,t){this.hasPendingWrites=e,this.fromCache=t}isEqual(e){return this.hasPendingWrites===e.hasPendingWrites&&this.fromCache===e.fromCache}}class mt extends fu{constructor(e,t,n,r,i,o){super(e,t,n,r,o),this._firestore=e,this._firestoreImpl=e,this.metadata=i}exists(){return super.exists()}data(e={}){if(this._document){if(this._converter){const t=new On(this._firestore,this._userDataWriter,this._key,this._document,this.metadata,null);return this._converter.fromFirestore(t,e)}return this._userDataWriter.convertValue(this._document.data.value,e.serverTimestamps)}}get(e,t={}){if(this._document){const n=this._document.data.field(du("DocumentSnapshot.get",e));if(n!==null)return this._userDataWriter.convertValue(n,t.serverTimestamps)}}toJSON(){if(this.metadata.hasPendingWrites)throw new y(m.FAILED_PRECONDITION,"DocumentSnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e=this._document,t={};return t.type=mt._jsonSchemaVersion,t.bundle="",t.bundleSource="DocumentSnapshot",t.bundleName=this._key.toString(),!e||!e.isValidDocument()||!e.isFoundDocument()?t:(this._userDataWriter.convertObjectMap(e.data.value.mapValue.fields,"previous"),t.bundle=(this._firestore,this.ref.path,"NOT SUPPORTED"),t)}}mt._jsonSchemaVersion="firestore/documentSnapshot/1.0",mt._jsonSchema={type:$("string",mt._jsonSchemaVersion),bundleSource:$("string","DocumentSnapshot"),bundleName:$("string"),bundle:$("string")};class On extends mt{data(e={}){return super.data(e)}}class tn{constructor(e,t,n,r){this._firestore=e,this._userDataWriter=t,this._snapshot=r,this.metadata=new Sn(r.hasPendingWrites,r.fromCache),this.query=n}get docs(){const e=[];return this.forEach((t=>e.push(t))),e}get size(){return this._snapshot.docs.size}get empty(){return this.size===0}forEach(e,t){this._snapshot.docs.forEach((n=>{e.call(t,new On(this._firestore,this._userDataWriter,n.key,n,new Sn(this._snapshot.mutatedKeys.has(n.key),this._snapshot.fromCache),this.query.converter))}))}docChanges(e={}){const t=!!e.includeMetadataChanges;if(t&&this._snapshot.excludesMetadataChanges)throw new y(m.INVALID_ARGUMENT,"To include metadata changes with your document changes, you must also pass { includeMetadataChanges:true } to onSnapshot().");return this._cachedChanges&&this._cachedChangesIncludeMetadataChanges===t||(this._cachedChanges=(function(r,i){if(r._snapshot.oldDocs.isEmpty()){let o=0;return r._snapshot.docChanges.map((a=>{const u=new On(r._firestore,r._userDataWriter,a.doc.key,a.doc,new Sn(r._snapshot.mutatedKeys.has(a.doc.key),r._snapshot.fromCache),r.query.converter);return a.doc,{type:"added",doc:u,oldIndex:-1,newIndex:o++}}))}{let o=r._snapshot.oldDocs;return r._snapshot.docChanges.filter((a=>i||a.type!==3)).map((a=>{const u=new On(r._firestore,r._userDataWriter,a.doc.key,a.doc,new Sn(r._snapshot.mutatedKeys.has(a.doc.key),r._snapshot.fromCache),r.query.converter);let c=-1,l=-1;return a.type!==0&&(c=o.indexOf(a.doc.key),o=o.delete(a.doc.key)),a.type!==1&&(o=o.add(a.doc),l=o.indexOf(a.doc.key)),{type:id(a.type),doc:u,oldIndex:c,newIndex:l}}))}})(this,t),this._cachedChangesIncludeMetadataChanges=t),this._cachedChanges}toJSON(){if(this.metadata.hasPendingWrites)throw new y(m.FAILED_PRECONDITION,"QuerySnapshot.toJSON() attempted to serialize a document with pending writes. Await waitForPendingWrites() before invoking toJSON().");const e={};e.type=tn._jsonSchemaVersion,e.bundleSource="QuerySnapshot",e.bundleName=Uu.newId(),this._firestore._databaseId.database,this._firestore._databaseId.projectId;const t=[],n=[],r=[];return this.docs.forEach((i=>{i._document!==null&&(t.push(i._document),n.push(this._userDataWriter.convertObjectMap(i._document.data.value.mapValue.fields,"previous")),r.push(i.ref.path))})),e.bundle=(this._firestore,this.query._query,e.bundleName,"NOT SUPPORTED"),e}}function id(s){switch(s){case 0:return"added";case 2:case 3:return"modified";case 1:return"removed";default:return I(61501,{type:s})}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */tn._jsonSchemaVersion="firestore/querySnapshot/1.0",tn._jsonSchema={type:$("string",tn._jsonSchemaVersion),bundleSource:$("string","QuerySnapshot"),bundleName:$("string"),bundle:$("string")};(function(e,t=!0){Cu(Du),bu(new xu("firestore",((n,{instanceIdentifier:r,options:i})=>{const o=n.getProvider("app").getImmediate(),a=new Yh(new Mu(n.getProvider("auth-internal")),new Lu(o,n.getProvider("app-check-internal")),Sc(o,r),o);return i={useFetchStreams:t,...i},a._setSettings(i),a}),"PUBLIC").setMultipleInstances(!0)),Ks(so,io,e),Ks(so,io,"esm2020")})();export{hd as a,cd as g,ud as i,ld as p};
